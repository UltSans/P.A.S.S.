# PASS / Site-19 Route & Boundary Model

## Principle

Site-19 does not rely on one elevator stack and one hallway. Its routes are separate because the site moves fundamentally different things: cleared staff, controlled custody, freight, patients, maintenance teams, and people leaving during an emergency. No route exists merely to make the site seem complex.

## Door and gate language

| Boundary | What it does | Typical use |
|---|---|---|
| **Internal Door** | Separates rooms or offices within one already-authorized division. | Individual offices, treatment rooms, workrooms, local stores. |
| **Security Door** | Separates a defined work division from its local corridor; validates division authority. | Clinical department, records office, research suite, LCZ staff corridor. |
| **Light Gate** | Marks a planned transition between operating environments and checks purpose/assignment as well as clearance. | L2 Administration & Clinical Services → L3 Light Containment Operations. |
| **Heavy Gate** | Marks a high-consequence operational boundary; it is a barrier, checkpoint, and lockdown point. | L3 → L4 Heavy Containment Operations. |
| **Deep Isolation Gate** | A secondary restrictive boundary after the heavy gate, used only for the deepest isolated capability. | L4 main spine → Deep Isolation Division. |
| **Custody Gate** | Separates controlled human transfer from staff and freight movement. | Surface custody port → L3 Custody Processing. |
| **Freight Gate** | Separates inspected cargo movement from people routes. | Surface receiving → freight lift / L3 intake. |
| **Clinical Transfer Gate** | Allows protected patient movement while keeping clinical risk out of normal circulation. | L3/L4 stabilization point → L2 Clinical Services. |

The label is not a clearance level by itself. PASS reader clearance, an assigned division, a local work purpose, and any required special authorization all remain separate decisions.

## Vertical cores

| Core | Normal path | Why it exists | What it does not do |
|---|---|---|---|
| **Personnel Core** | L1 Personnel Entry → L2 staff arrival; L2 → L3 through the Light Gate; onward only under deeper assignment. | Makes Level 2 the normal institutional arrival point for cleared staff. | Does not carry custody transfers, uninspected cargo, or casual L4/L5 traffic. |
| **Custody Core** | L1 Custody Transfer Port → L3 Custody Processing & D-Class Division. | Prevents D-Class/control-transfer movement from crossing L2 offices, clinical public circulation, or staff screening. | Does not serve L2, the cafeteria, standard staff lifts, or general freight. |
| **Freight Core** | L1 Vehicle & Freight Transfer → L3 Materials Intake and L5 Heavy Storage. | Lets supplies, equipment, and sealed deliveries reach the work/storage levels without going through personnel areas. | Does not provide drivers or suppliers access to the underground facility. |
| **Heavy Access Core** | L3 Heavy Gate checkpoint → L4 HCZ Transition Control. | Turns movement into high-risk operations into a deliberate, accountable change of environment. | Does not operate as a shortcut between LCZ and L5. |
| **Deep Isolation Core** | L4 restricted approach → Deep Isolation Division. | Gives the deepest high-consequence function an independent final boundary and access route. | Does not accept ordinary L4 traffic or general maintenance movement. |
| **Clinical Transfer Core** | L2 Clinical Services ↔ L3/L4 stabilization interfaces. | Allows patient movement without taking potentially exposed personnel through staff corridors. | Does not replace the normal personnel core or general medical access. |
| **Service Core** | L1 infrastructure interface ↔ controlled service spines ↔ L5 utility reserve and defined level handoffs. | Lets maintenance, utilities, and controlled waste move without becoming a public corridor. | Does not let maintenance staff bypass operational authorization. |
| **Emergency Egress Network** | Lower levels → separated protected exits → sealed L1 egress points. | Provides a way out when normal lifts/checkpoints cannot be used. | Does not function as normal entry or a hidden routine shortcut. |

## Primary daily movement

| Movement | Starting point | Required path | Purpose |
|---|---|---|---|
| **Cleared office/clinical staff** | L1 Personnel Entry | Personnel Core → L2 | Daily site governance and clinical work. |
| **Assigned L3 personnel** | L2 | Light Gate → L3 Operations Control → assigned division | Daily containment/research/support shifts. |
| **Assigned L4 personnel** | L3 controlled approach | Heavy Gate → Heavy Access Core → L4 Transition Control | Deliberate high-risk work only. |
| **Custody transfer** | L1 Custody Port | Custody Gate → Custody Core → L3 Processing | Controlled intake, housing, staging, and escort. |
| **Freight delivery** | L1 Freight Transfer | Freight Gate → Freight Core → L3 Intake or L5 Storage | Supply, equipment, controlled material, and reserve stock. |
| **Patient transfer** | L3/L4 stabilization | Clinical Transfer Gate → Clinical Transfer Core → L2 Clinical Services | Protects the clinical department and avoids ordinary staff corridors. |
| **Maintenance work** | L1 or L5 service control | Service Core → assigned service spine | Infrastructure support under defined work order. |

## Why the L3 → L4 Heavy Gate matters

The L3-to-L4 Heavy Gate is the most important visible internal boundary in the map. It does not exist just because games show a gate. It tells the reader that staff have left the site’s daily containment-and-research environment and are entering a different operating condition: restricted movement, specialist assignment, decontamination capability, local response support, and compartmentalized service access.

The gate is therefore followed by **HCZ Transition Control**, not an open L4 corridor. People, cargo, clinical transfers, and response resources have different instructions from the moment they cross it.

## Route rules that make the site believable

1. **No level is a transit shortcut.** L2 cannot be bypassed to reach LCZ; L3 cannot be used to casually reach HCZ; L5 is not a hidden route between other levels.
2. **One lift family, one movement purpose.** A custody lift does not become a staff lift during a busy shift; a freight lift does not become a convenient emergency elevator.
3. **Clinical transfers are controlled, not improvised.** A patient does not cross a cafeteria, an office corridor, or a normal checkpoint to reach care.
4. **Every deeper boundary is harder to cross, not merely marked with a new label.** The physical layout, access verification, purpose check, and lockdown capability all increase together.
5. **Emergency exits reduce entrapment without reducing secrecy.** They surface within the restricted reservation and do not reveal a normal entrance to the public.
