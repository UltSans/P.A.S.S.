# PASS Incident Report — Approved Structure

**Status:** Approved design structure. Implementation has not begun.

## Purpose and placement

**Incident Report** is a general operational record for any event that affects a Foundation site, personnel, containment operation, information boundary, research activity, or facility system. It is not limited to an SCP and is not limited to containment breaches.

The Terminal will receive an **Incident Reports** destination. It opens the controlled report directory and offers the action **File Incident Report**. Database remains a reference/archive area rather than the place where an active report is initiated.

> An Incident Report records what happened and coordinates affected records. It does not disclose or grant access to a linked SCP, Personnel profile, Team, Project, or Entry that the active reader could not already access.

## General report classes

The class describes the kind of event, not the cause, threat level, SCP class, or personnel class. A Chaos Insurgency action, for example, is recorded under **External Hostile Activity** and described in the external-involvement field; it is not a special exception to the system.

| Report class | Use it when |
|---|---|
| Containment Breach | An anomaly leaves, compromises, or materially disrupts its approved containment condition. |
| Security Incident | Site security, credential, access-control, or unauthorized-entry controls are compromised without necessarily involving an SCP. |
| External Hostile Activity | An outside organization, hostile actor, or non-Foundation force affects the site or operation. |
| Exposure / Quarantine | Personnel or civilians may have been exposed to anomalous, biological, informational, or hazardous effects requiring evaluation or isolation. |
| Research / Testing Incident | A research, test, interview, or experimental process produces an unplanned operational outcome. |
| Facility / Systems Failure | Infrastructure, power, communications, environmental, transport, or containment-support systems fail or operate outside safe limits. |
| Information Security / Disclosure | Classified information, records, communications, or anomalous knowledge may have been exposed or mishandled. |
| Other Operational Incident | The event is real and reportable but does not fit the controlled classes above; a plain-language rationale is required. |

## Fixed report dossier

The report uses a fixed dossier, like SCP and Personnel files. Users can edit values and write the narrative inside each section but cannot rearrange the structure.

| Fixed section | Required content |
|---|---|
| Report identity | Local report ID, title, report class, severity, operational status, minimum reader clearance, known occurrence time, and site or sector reference. |
| Initial notification | Reporting personnel, discovery method, first-known condition, and concise time-stamped notification text. |
| Situation summary | A factual narrative of what is confirmed, what remains unconfirmed, and the immediate containment or operational condition. |
| External involvement | Optional actor, organization, environmental cause, or outside event. This is where Chaos Insurgency involvement is recorded when relevant. |
| Immediate measures | Measures already taken, such as isolation, lockdown, evacuation, medical evaluation, containment response, access restriction, or communications control. The first version records actions; it does not provide tactical instructions. |
| Impact assessment | Known personnel impact, site or asset impact, information exposure, and current containment/operational condition. |
| Linked records | Clearance-capped SCP, Personnel, Team, Project, and supporting Entry references. |
| Response and disposition | Response owner, optional Project follow-up, resolution summary, and a required closure rationale when the report is closed. |

## Severity and status

Severity communicates urgency and coordination needs. It is independent from a linked SCP’s PASS Risk Class.

| Field | Values | Rule |
|---|---|---|
| Severity | Advisory, Significant, Major, Critical | Selected from the known operational impact at the time of reporting; may be revised as facts improve. |
| Status | Draft, Active, Resolved, Closed | **Draft** is incomplete or awaiting verification. **Active** requires an ongoing response. **Resolved** means the immediate event is controlled. **Closed** requires a recorded closure rationale. |

The earlier proposed **Review** state is removed. A Project is **never required** to resolve or close a report. It is optional and only links a formally approved follow-up effort, such as remediation, investigation, recovery, or a longer containment program.

## Relationship rules

| Linked record | Role in an Incident Report |
|---|---|
| SCP | Affected anomaly, compromised containment condition, exposure source, relevant research subject, or recovered asset. |
| Personnel | Reporter, affected person, witness, response lead, accountable authority, or other involved staff. |
| D-Class Personnel | Linked exactly as other Personnel, without a special report class. Individual testing, exposure, injury, transfer, quarantine, or disposition documentation belongs in that person’s Personnel Entries. |
| Team | Immediate response unit, research group, security group, or specialist owner. |
| Project | Optional formal follow-up for remediation, investigation, recovery, or an ongoing operational program. |
| Existing Entry | Supporting evidence such as a containment log, interview, medical/quarantine document, testing document, or security record. |

An Incident Report is the authoritative event record. A separate Personnel Entry should be created only when an individual’s ongoing history needs documentation. PASS must not silently generate duplicate D-Class documents for every linked report.

## Clearance and authority rules

The existing PASS principle remains: **reader authority is separate from record visibility**.

| Rule | Approved behavior |
|---|---|
| Visibility | A reader must meet the report’s minimum clearance to open the report. |
| Report clearance | A report cannot be assigned below the highest clearance of any selected linked record. |
| Selectors | The report editor offers only records already readable by the active session. |
| Disclosure | Protected links never reveal a name, code, or metadata inside a lower-clearance report. |
| Authoring | The first implementation should require Level 3 authority to create or amend an Incident Report, and prevent creating a report above the active reader’s own clearance. |
| Personnel Entries | Existing Level 2 Entry authority remains sufficient for individual D-Class or personnel documentation when the reader can access that profile. |

## First implementation boundary

The first build should add local Incident Report persistence, safe migration, clearance-capped relationship selectors, a Terminal directory, a fixed report editor, and a read-only dossier with controlled status changes.

It deliberately excludes live alerts, automatic notifications, tactical response instructions, automatic D-Class entry generation, incident deletion, and a command dashboard. Those would be separate systems and should not be hidden inside the first report workflow.
