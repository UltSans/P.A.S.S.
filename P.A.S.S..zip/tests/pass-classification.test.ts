import { describe, expect, it } from "vitest";

import {
  CONTAINMENT_CLASSES,
  CONTAINMENT_CONFIGURATION_OPTIONS,
  CUSTODY_OPTIONS,
  LIFECYCLE_STATUS_OPTIONS,
  OPERATIONAL_ROLE_OPTIONS,
  RESPONSE_POSTURE_OPTIONS,
  TERMINAL_ESCALATION_OPTIONS,
} from "../lib/registry-types";

describe("PASS classification framework", () => {
  it("keeps Ticonderoga in containment while excluding terminal escalation labels", () => {
    expect(CONTAINMENT_CLASSES).toContain("Ticonderoga");
    expect(CONTAINMENT_CLASSES).not.toContain("Apollyon Condition");
    expect(CONTAINMENT_CLASSES).not.toContain("K-Class Scenario");
  });

  it("places specialist terms on their independent operational axes", () => {
    expect(CUSTODY_OPTIONS).toContain("External Custody — Argus");
    expect(OPERATIONAL_ROLE_OPTIONS).toContain("Thaumiel");
    expect(RESPONSE_POSTURE_OPTIONS).toContain("Tiamat");
    expect(CONTAINMENT_CONFIGURATION_OPTIONS).toContain("Hiemal");
  });

  it("preserves lifecycle and terminal escalation as different concepts", () => {
    expect(LIFECYCLE_STATUS_OPTIONS).toContain("Uncontained / Active Incident");
    expect(TERMINAL_ESCALATION_OPTIONS).toEqual([
      "None / Not Triggered",
      "Apollyon Condition",
      "K-Class Scenario",
      "Apollyon Condition + K-Class Scenario",
      "Not Listed — Specify",
    ]);
  });
});
