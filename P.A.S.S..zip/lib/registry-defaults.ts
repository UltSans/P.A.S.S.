import type { RegistryData } from "@/lib/registry-types";
import { createEmptyScpNamedClassificationOptions } from "./scp-named-options";

/** Creates a new local-first PASS registry with no bundled operational records. */
export function createEmptyRegistry(): RegistryData {
  return {
    scps: [],
    personnel: [],
    entryFolders: [],
    personnelEntries: [],
    scpEntries: [],
    typefaces: [],
    teams: [],
    projects: [],
    incidents: [],
    scpNamedClassificationOptions: createEmptyScpNamedClassificationOptions(),
  };
}
