import type { DocumentBlock } from "@/lib/registry-types";

type TypefaceEntry = { documentBlocks?: DocumentBlock[] };

export function typefaceUsage(entries: TypefaceEntry[]) {
  const counts = new Map<string, number>();
  entries.forEach((entry) => entry.documentBlocks?.forEach((block) => { if (block.typefaceId) counts.set(block.typefaceId, (counts.get(block.typefaceId) ?? 0) + 1); }));
  return counts;
}
