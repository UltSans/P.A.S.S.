# PASS / Site-19 — Research-Grounded Operating Proposal

## Purpose

This proposal treats **Site-19 as a functioning institution**, not a sequence of themed zones or a copied game map. It keeps the five fixed levels chosen for PASS, but assigns each one a clear operating environment, workforce, support system, entry boundaries, and reason for existing.

It is a **PASS-local facility configuration**. The SCP setting does not impose one universal Site-19 floor plan, and the game references do not become this app’s layout. The research instead supports three useful principles: major sites can house many low-risk anomalies with dedicated laboratories and anomalous-item storage; clearance remains need-to-know rather than universal access; and familiar door/gate terms can express different access boundaries when they are given an explicit local meaning. [1] [2] [3]

> **Design rule:** An element belongs at a location only when its work, users, material flow, failure consequences, and required support all make sense there.

This proposal does **not** change Facility Records, the PASS keycard model, or any SCP dossier. It is the model to review together before implementation.

---

## 1. The Site-19 operating idea

The proposed Site-19 is a large, high-security containment and research site operating beneath a controlled **industrial remediation and materials-services campus**. The cover explains a secure perimeter, heavy vehicles, regulated deliveries, engineering staff, laboratory work, restricted service areas, and a large underground technical footprint without requiring public access to the real installation.

The site is deliberately not arranged as “administration on one level, SCPs on another.” A real facility has overlapping systems: staff must be checked, briefed, fed, medically supported, equipped, recorded, and moved safely; assets must be supplied, observed, tested, transferred, isolated, or stored; security must restrict crossings without preventing legitimate work. The five levels separate **operating conditions**, not merely types of rooms.

| Level | Operating environment | Main site responsibility | What it must prevent |
|---|---|---|---|
| **L1 — Surface** | Public-facing cover and controlled outside boundary. | Screen people, vehicles, cargo, and information before they reach the real site. | Public, unscreened, or uncontrolled movement underground. |
| **L2 — Administration** | Low-anomaly-contact institutional core. | Lead the site, run records and personnel systems, provide broad medical care, brief staff, and supervise tightly controlled applied assets. | Routine office/clinical traffic drifting into containment operations. |
| **L3 — Light Containment Zone** | Daily operational core. | Sustain low-to-moderate containment, research, D-Class custody, material transfer, and long-shift staff needs. | Mixing normal staff service, D-Class movement, research, and containment circulation without boundaries. |
| **L4 — Heavy Containment Zone** | Low-traffic, high-consequence environment. | Isolate serious containment work, specialist research, decontamination, incident recovery, and Deep Isolation. | HCZ becoming an extension of LCZ or a shortcut between levels. |
| **L5 — Heavy Storage Zone** | Purpose-limited custody and infrastructure environment. | Preserve long-hold assets, physical evidence, protected systems, and rare-use contingency material. | Daily staff activity and uncontrolled retrieval. |

The official facilities reference describes Site-19 as a very large high-security site with hundreds of Safe and Euclid anomalies, dedicated laboratories, and storage for anomalous items that do not need individual containment procedures. That supports **clustered capacity and generic operating sectors**, rather than pretending every object has an individually mapped cell. [1]

---

## 2. PASS-local access language

The terms **light door**, **heavy door**, **light gate**, and **heavy gate** are retained because they are instantly legible to SCP readers. Their PASS meaning is original: they describe the seriousness of a physical and operational boundary, not copied gameplay mechanics. The game source uses light doors, heavy doors, checkpoints, and gates as distinct names; PASS adopts the names but not its timings, map, lock tiers, or escape design. [3]

| PASS boundary | What it physically separates | Typical use | Access standard |
|---|---|---|---|
| **Light Door** | Compatible rooms inside one staffed division. | Office suites, ordinary clinical rooms, staff support rooms, records workspaces. | Routine division entitlement; privacy or local duty requirement. |
| **Heavy Door** | A reinforced sector inside a controlled environment. | Anomalous-work annex, containment cluster, D-Class custody block, specialist laboratory. | Standing sector grant plus local assignment; movement can be logged. |
| **Checkpoint** | A monitored, repeated movement point where people and purpose are verified. | L1 arrival into secure staff circulation; L2 access hub; L3 duty control. | Active credential, route entitlement, and current work purpose. |
| **Light Gate** | A major transition from general internal work into a controlled operating environment. | L2 Administration → L3 LCZ. | Approved LCZ access category and current assignment; it is not opened merely by document clearance. |
| **Heavy Gate** | A major transition into high-consequence containment or protected infrastructure. | L3 HCZ Transition → L4 transfer elevator. | HCZ standing grant, destination authorization, and the correct route; ordinary L3 access is insufficient. |
| **Isolation Gate Pair** | A nested boundary around a deep-isolation sector or highly consequential asset. | L4 Deep Isolation, selected L5 contingency custody. | Explicit local authority and controlled entry/exit; PASS only records administrative status. |
| **Egress Gate** | An emergency-only compartment or surface egress boundary. | Evacuation route or protected surface exit. | Emergency posture, not routine convenience. |

### The real decision is not “what clearance number is on the card?”

The Foundation clearance reference states that clearance is the highest information level that may be granted, but access remains need-to-know and department-controlled. [2] The expanded-clearance resource similarly distinguishes global, division, and local scope. [4] PASS already has the pieces for this without discarding the user’s keycard system:

| Existing PASS dossier field | Facility meaning in this proposal |
|---|---|
| **Credential status** | Whether ordinary entry is possible at all. Suspended or restricted status can stop a route before other grants are considered. |
| **Departmental clearance** | Standing division-level authority: for example, work inside Clinical Services, LCZ Research, or L5 Deep Logistics. |
| **Access categories** | Routine physical sector grants, such as `L3 LCZ Duty Control`, `L3 Shift Services`, or `L2 Clinical Services`. |
| **Special permissions** | Local asset, chamber, project, or temporary exception: for example, `SCP-914 Applied Annex`, `SCP-500 Clinical Reserve`, or a named project laboratory. |
| **Restrictions** | Explicit denials or conditions that override ordinary grants: `escort required`, `no HCZ access`, `medical hold`, or `no armory access`. |
| **Personnel Entries** | The audit record that explains why a grant, restriction, reassignment, or medical hold changed. |

The future facility screen can therefore **describe** what a boundary requires without pretending that PASS currently simulates a live door. If the user later wants actual door decisions, the existing keycard review already recommends a narrow authorization layer with controlled zone names and an explicit order of precedence. That is a separate project, not a prerequisite for mapping the site.

---

## 3. Level 1 — Surface, Cover, and Controlled Entry

### Why this level exists

L1 is not simply a lobby. It is the controlled membrane between the public world and the concealed site. It should be capable of handling ordinary external activity while preventing an unscreened person, vehicle, delivery, or piece of information from reaching underground operations.

### L1 divisions

| Division | Work performed here | Why it belongs on L1 | Boundary relationships |
|---|---|---|---|
| **Cover Administration** | Runs the public industrial-remediation/materials-services identity, scheduled appointments, basic front-of-house work, contractor correspondence, and outward compliance records. | This work has the highest external visibility and should never require public access to the real site. | A Light Door separates cover offices from secure-arrival functions. |
| **Personnel Arrival Checkpoint** | Verifies expected staff and approved visitors, handles credential checks, personal-item control, escort handoff, and entry screening. | The first internal security decision happens before a person enters any site-working environment. | Checkpoint to L2 Staff Access; visitors do not independently proceed beyond it. |
| **Receiving and Vehicle Control** | Handles vehicle arrival, delivery screening, receiving records, and handoff of cleared freight. | Freight needs surface vehicle access but must not share staff circulation or L2 offices. | Heavy Door to Logistics Transfer; freight lift does not function as a personnel shortcut. |
| **Surface Security and Perimeter Operations** | Maintains perimeter monitoring, protected external entry points, coordination with the surface cover, and limited surface-incident management. | Security must be adjacent to the boundary it protects. | Separate controlled route from the personnel checkpoint and receiving. |
| **External Training and Transport Liaison** | Administers qualification records, approved travel, and staff assignment between Site-19 and a separate Foundation-controlled academy/range/secure training annex. | Your decision to keep security recruit drills out of the facility is sound; Site-19 only needs the administrative handoff. | Administrative access only; no internal drill floor or weapons-training sector. |

### L1 movement logic

An ordinary L2 office worker enters through Personnel Arrival and passes only to the L2 Staff Access hub. A delivery is screened at Vehicle Control and moves into the logistics system. A visitor remains on an escorted route. A cover-operation client never sees an operational lift. This makes the cover useful rather than theatrical: the public-facing campus can function plausibly while all meaningful site access is compartmentalized.

---

## 4. Level 2 — Administration, Clinical Services, and Controlled Applied Assets

### Why this level exists

L2 is Site-19’s institutional core. It is where the site can function as a real employer and research organization without making routine administrative work occur inside a containment zone. It supports staff, records, leadership, policy, medical care, and tightly justified anomalous applications.

It should not become one enormous generic office floor. Each division has different confidentiality, traffic, and safety needs.

### L2 divisions

| Division | Work performed here | Why it belongs on L2 | Boundary relationships |
|---|---|---|---|
| **Command and Site Coordination** | Holds the Site Director’s office, executive workrooms, protected meetings, departmental coordination, and an incident-coordination capability. | Leadership needs controlled site-wide information and proximity to personnel/records, not routine containment exposure. | Controlled Door; it coordinates incidents but is not an L4 tactical staging area. |
| **Personnel, Credentials, and Records** | Maintains personnel administration, site assignments, credential changes, document routing, redaction review, and PASS-style records operations. | These are site-wide services that need privacy, stable access, and separation from public L1 and containment traffic. | Controlled Doors; records access never equals physical sector access. |
| **Comprehensive Clinical Services** | Provides physical medicine, diagnostics, pharmacy control, rehabilitation, mental-health care, psychological assessment, counseling, and routine occupational health. | The primary general medical department should be available to the widest staff population before they enter L3/L4 work environments. | Clinical controlled doors and patient privacy zones. L3/L4 isolate and stabilize high-risk exposure before transfer. |
| **Briefing and Assignment Preparation** | Runs induction administration, pre-shift briefing, policy refreshers, supervised project briefings, and post-incident administrative debriefs for qualified personnel. | Staff must prepare for controlled work without turning an operational corridor into a meeting area. | Internal access boundary. It is not a security recruit-training or weapons-drill space. |
| **Security Administration** | Manages standing access categories, restrictions, guard assignment, security recordkeeping, and administrative coordination. | It works beside leadership and personnel functions but remains distinct from L1 perimeter security and L4 response support. | Controlled Door; no casual HCZ route. |
| **Applied Anomalous Systems Annex** | Supports scheduled, restricted anomalous applications with a defensible clinical, training-observation, materials, or engineering purpose. | Some controlled assets can be better supported near clinical/research oversight than in an LCZ cell ring, provided they are isolated from ordinary office traffic. | Heavy Door and material handoff point. The annex has no open connection from offices. |
| **Staff Access and Internal Communications** | Controls the secure handoff from L1, supports internal communications, manages routine office services, and routes approved staff toward LCZ. | A single internal hub prevents each L2 division and lower-level lift from becoming an unmonitored entry point. | Checkpoint from L1; Light Gate to approved L3 circulation. |

### The L2 anomalous-asset rule

L2 can contain specific SCP assets **only when the asset serves L2’s mission better than it serves LCZ or HCZ**. This is an exception by function, not a way to place interesting SCPs beside offices for atmosphere.

| Asset pattern | Defensible L2 placement | Reason | Condition |
|---|---|---|---|
| **Clinical reserve asset, including SCP-500** | Clinical Services pharmacy custody. | It is a medical resource requiring clinical authorization, inventory control, patient records, and restricted dispensing. | Not routine medicine; supply/use stays logged and purpose-specific. |
| **Applied engineering or observation asset, including SCP-914** | Applied Anomalous Systems Annex. | It can support scheduled engineering work, vetted junior-researcher observation, and controlled material evaluation under direct supervision. | The annex has a Heavy Door, dedicated material transfer, restricted timetable, and no office-corridor access. |
| **Low-impact service asset, including an anomalous beverage machine** | A supervised staff-services observation alcove or the annex, depending on what inputs and outputs it produces. | A controlled asset can support welfare or behavioural observation if its risks are low and well-defined. | Logged use and defined relocation criteria: it moves to L3 if it begins to require research handling or containment response. |

This keeps the user’s core idea: **SCPs can be placed wherever their true operational role fits.** It also prevents the map from becoming arbitrary. SCP-914 is not on L2 because it is famous; it is there only if its schedule, transfer method, supervision, and recovery needs are compatible with a controlled L2 annex.

---

## 5. Level 3 — Light Containment Zone and Daily Operational Core

### Why this level exists

L3 is Site-19’s largest daily working environment. It must sustain a large population of researchers, containment personnel, security, D-Class custodial staff, janitorial/service staff, maintenance workers, and approved support teams. It therefore needs more than containment suites: it needs duty control, custody, safe material movement, research support, food, hygiene, rest, and a clear physical break before HCZ.

### L3 divisions

| Division | Work performed here | Why it belongs on L3 | Boundary relationships |
|---|---|---|---|
| **LCZ Duty Control** | Confirms arriving staff assignments, manages recurring LCZ movement, oversees sector status, and coordinates normal-duty handoffs. | L3 must be a controlled operational environment rather than the continuation of an L2 hallway. | Light Gate from L2; internal Checkpoints toward individual divisions. |
| **Light Containment Clusters** | Holds Safe and appropriate Euclid assets, observation suites, routine containment support rooms, and controlled maintenance points. | These assets require regular work but not the HCZ isolation posture. | Heavy Doors to each cluster; no open public/staff service route through containment. |
| **Research, Interview, and Testing Division** | Provides scheduled laboratories, interview suites, analysis rooms, and supervised work related to LCZ-compatible assets. | Researchers need controlled access to relevant assets without traversing unrelated cells. | Heavy Door; approved test/custody routes only. |
| **D-Class Custody and Dispatch** | Manages arrival, medical/psychological screening, housing, welfare administration, holding, and escorted dispatch to authorized tests. | D-Class movement is its own custody/logistics system, never a casual set of corridors. | Separate Heavy Door and controlled transfer path; no free access to research or staff services. |
| **Material Intake and Transfer** | Receives cleared freight, prepares authorized research material, and directs controlled transfers to L3, L4, or L5 destinations. | Supplies and secured material must not travel through dining, offices, or general staff routes. | Logistics checkpoint; distinct freight and containment-transfer paths. |
| **Shift Services and Welfare** | Provides food service, sanitation, lockers, rest areas, uniform/service support, and welfare functions for long underground shifts. | L3 workers cannot safely or efficiently return to L2 for every basic need. | Buffered service spine. It is separate from cells, custody, material intake, and HCZ transfer. |
| **LCZ Clinical Response and Transfer** | Stabilizes routine injuries or exposure concerns before controlled transfer to Comprehensive Clinical Services or specialist L4 isolation. | A developing exposure cannot move unprepared through a cafeteria or office corridor. | Controlled clinical-transfer path; not a replacement for the L2 medical department. |
| **HCZ Transition** | Checks HCZ destination authority and provides the only ordinary staff transfer point to L4. | Heavy containment needs a hard, visible break from daily LCZ work. | Heavy Gate to L4 transfer lift; L3 authority does not automatically pass it. |

### The cafeteria and D-Class question

The cafeteria belongs on L3 because it supports long operational shifts. However, realism requires **separate service timing and controlled dining access**, not a shared unrestricted hall where all personnel classifications mix. The formal clearance/personnel reference treats Class A and Class B personnel as having restricted anomaly proximity and treats D-Class contact as tightly controlled. [2] The L3 service spine can therefore support researchers, guards, D-Class, and janitorial personnel without creating inappropriate general mixing.

---

## 6. Level 4 — Heavy Containment Zone and Specialist Isolation

### Why this level exists

L4 exists for work whose consequence, isolation requirement, or recovery need makes routine LCZ traffic unacceptable. It does not merely contain “more dangerous SCPs”; it has a different operating posture: fewer people, controlled destinations, hardened compartmentation, specialist clinical isolation, and response-support capacity.

### L4 divisions

| Division | Work performed here | Why it belongs on L4 | Boundary relationships |
|---|---|---|---|
| **HCZ Transfer and Access Control** | Receives authorized arrivals from L3, checks the approved L4 destination, and controls movement to HCZ divisions. | A lift should never open directly into a high-consequence containment cluster. | Heavy Gate from L3; internal route selection afterward. |
| **Heavy Containment Clusters** | Holds high-consequence containment assets and the support functions needed to maintain them. | The environment requires strong routine separation and reduced traffic. | Heavy Doors and sector-specific internal barriers. |
| **Specialist Research and Recovery** | Conducts restricted research, assessment, and controlled recovery work that cannot reasonably take place on L3. | It needs proximity to HCZ assets and response support. | Restricted internal Heavy Door; not a general laboratory wing. |
| **Decontamination and Clinical Isolation** | Provides controlled high-risk stabilization, decontamination, and isolated care before authorized onward transfer. | This prevents an exposure event from being routed into L2 clinical waiting/office circulation. | Heavy Door and clinical isolation route. |
| **Incident Response Support** | Stores protective equipment, supports incident coordination, and stages restricted recovery supplies. | It must be near HCZ but should not become an ordinary security office. | Restricted response route, separate from daily staff movement. |
| **Deep Isolation Sector — SCP-682** | Registers the separate deep-isolation asset as an L4 function with its own custody state. | The asset’s isolation requirement exceeds ordinary HCZ separation. | Dedicated route and Isolation Gate Pair. PASS will not show chamber plan, vulnerabilities, countermeasures, or response procedure. |

### Why the L3 Heavy Gate matters

The L3→L4 Heavy Gate is the most important facility boundary after surface entry. It says: the person is leaving the daily containment environment, has an approved L4 destination, and is entering an operating environment in which every crossing must be deliberate. This is where the user’s game-inspired visual language becomes meaningful without copying a game: a heavy gate protects a **change of operating condition**, not a particular hallway.

---

## 7. Level 5 — Heavy Storage, Protected Infrastructure, and Custodial Systems

### Why this level exists

L5 exists for what must remain stable, infrequently moved, compartmented, or deeply protected. It is not a generic basement and it is not an overflow containment zone. Its purpose is custody: long-hold assets, physical evidence, sensitive material, deep logistics, protected infrastructure, and very rare-use contingency functions.

### L5 divisions

| Division | Work performed here | Why it belongs on L5 | Boundary relationships |
|---|---|---|---|
| **Long-Hold Anomalous Storage** | Maintains packaged, inert, inactive, rare-use, or scheduled-retrieval assets. | The assets need stable custody and logged retrieval rather than daily research traffic. | Heavy Door and secure logistics access. |
| **Evidence and Physical Archive Custody** | Holds sealed evidence, redundant physical records, recovered material, and controlled samples. | Certain physical items should not be in a routine L2 records office or frequently used research store. | Controlled archive barrier; document visibility does not grant physical custody. |
| **Critical Infrastructure** | Hosts protected technical systems, monitored utilities, resilience systems, and necessary deep maintenance points. | Some infrastructure benefits from reduced traffic and deliberate access. | Maintenance-only routes, segregated from storage retrieval. |
| **Deep Logistics and Maintenance Control** | Manages scheduled retrieval, large-equipment movement, deep service access, and maintenance authorization. | L5 cannot depend on casual use of ordinary personnel circulation. | Purpose-bound logistics route; destination must be recorded. |
| **Omega Contingency Custody** | Records the governance state and existence of a highly restricted strategic contingency asset. | Such an asset must be removed from daily operations and ordinary storage. | Isolation Gate Pair and purpose-limited record. PASS must not display coordinates, activation logic, technical details, or procedures. |

### L5’s relationship to the rest of the site

L5 has no general public or routine staff route. A person goes there only for an approved storage retrieval, archive custody task, maintenance duty, or a strictly limited governance function. That is what makes the level feel real: it is not exciting because it is hidden; it is restricted because **its normal work should be rare, documented, and deliberate**.

---

## 8. Cross-level movement model

The map should show each route as a reasoned workflow, not a generic ladder of elevators.

| Person or material | Valid normal path | Why this is the correct route |
|---|---|---|
| **Administrative employee** | L1 Personnel Arrival → L2 Staff Access → assigned L2 division. | They have no standing reason to cross the L3 Light Gate. |
| **Research or containment shift worker** | L1 Personnel Arrival → L2 briefing/clinical care as needed → L2 Staff Access → L3 Light Gate → assigned L3 division. | LCZ access is tied to an actual duty and division grant. |
| **HCZ specialist** | L1/L2 approved route → L3 Light Gate → HCZ Transition → Heavy Gate → L4 Transfer and Access Control → named L4 destination. | HCZ requires a second, destination-specific boundary beyond LCZ access. |
| **D-Class** | Controlled custody handoff → L3 D-Class Custody and Dispatch → escorted approved test/containment route. | D-Class do not use general staff welfare, research, or personnel circulation as free movement. |
| **Routine patient** | Assigned level → controlled clinical route → L2 Comprehensive Clinical Services. | Broad normal care belongs at L2. |
| **High-risk exposure patient** | L3/L4 response point → controlled clinical isolation/stabilization → authorized onward transfer. | The patient does not move unprepared through L2 office/clinical waiting areas. |
| **Freight and supplies** | L1 Receiving → logistics handoff → L3 Material Intake or L5 Deep Logistics. | Freight does not pass through staff lifts, administration, or food services. |
| **Stored asset retrieval** | Approved request → L5 Deep Logistics and Maintenance Control → named custodial sector. | Retrieval remains purpose-specific and recorded. |
| **Emergency egress** | Nearest approved Emergency Barrier/Egress Gate → safe surface egress. | Emergency boundaries protect life and compartments; they are not daily shortcuts. |

---

## 9. The design questions to review together

The proposal resolves many parts of the map but deliberately leaves a few user decisions open. These should be discussed before the model becomes app data.

| Decision | Proposed answer | Why it needs your confirmation |
|---|---|---|
| **Surface cover** | Industrial remediation and materials-services campus. | It is realistic for freight, restricted access, laboratories, and a deep technical facility, but you may prefer another external identity. |
| **SCP-914 location** | L2 Applied Anomalous Systems Annex, behind a Heavy Door with scheduled material transfer. | It supports your junior-researcher/applied-work idea, but we should decide whether its daily operational burden is truly compatible with L2 or better held in L3. |
| **SCP-500 location** | L2 Clinical Services pharmacy custody. | This is a strong fit, but it assumes the user wants it treated as a clinical reserve rather than a research asset. |
| **Anomalous beverage machine** | Supervised L2 staff-services alcove or L3 service annex depending on its behaviour. | Its placement depends on what it produces and how it is used; the map should not decide this without its dossier. |
| **L3 dining** | One service division with separate controlled use windows/areas for staff groups and D-Class. | This preserves long-shift support while avoiding unrealistic unrestricted mixing. |
| **L5 relationship to L4** | No routine staff through-route; L5 is reached by scheduled deep logistics/maintenance and protected custody access. | This prevents HCZ and storage from becoming a generic connected “lower zone.” |

## 10. Recommendation for the next conversation

Do **not** implement yet. Review this proposal at the level of operating logic. The right next discussion is to challenge it—not to agree automatically. In particular, we should decide whether the L2 SCP-914 annex feels credible, whether the surface cover fits your version of Site-19, and whether any Level 3 or Level 4 division is missing a job that a real site needs.

Once those decisions are made, the app can be rebuilt from this model in one consistent structure rather than receiving another list of unconnected cards.

## References

[1] [SCP Wiki — Foundation Facilities](https://scp-wiki.wikidot.com/secure-facilities-locations)  
[2] [SCP Wiki — Security Clearance Levels](https://scp-wiki.wikidot.com/security-clearance-levels)  
[3] [SCP: Secret Laboratory Official Wiki — Door Mechanics](https://en.scpslgame.com/index.php?title=Door_Mechanics)  
[4] [SCP Wiki — Expanded Security Clearance Codes](https://scp-wiki.wikidot.com/expanded-security-clearance-codes)  
[5] [SCP Wiki — Lockdown Procedures](https://scp-wiki.wikidot.com/lockdown-procedures)

