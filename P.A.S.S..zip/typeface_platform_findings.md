# Typeface Platform Findings

The current Expo Font documentation states that runtime font loading through `loadAsync` is supported on Android, iOS, and web. A user-imported TTF or OTF can therefore render in principle; a default-font result is not an unavoidable web-preview limitation.

The current Expo DocumentPicker documentation states that FileSystem access is not always available immediately after selection unless `copyToCacheDirectory` is enabled. PASS already requests that option, but the imported asset must still be copied into a managed app location on Android before the stored URI is reused.

The remaining investigation must therefore verify the stored URI, runtime registration result, and the use of the selected font family inside document blocks rather than assuming that preview is incapable of displaying custom fonts.

Sources consulted on 2026-08-19:

- https://docs.expo.dev/versions/latest/sdk/font/
- https://docs.expo.dev/versions/latest/sdk/document-picker/
