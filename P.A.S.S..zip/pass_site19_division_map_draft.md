# PASS / Site-19 Division Map Draft

## Reading the map

This is a **facility-only** division map. It describes the permanent operating structure of Site-19, not the SCPs currently assigned to it. Each division has a neutral designation, a functional title, large internal zones, a normal population, and a reason for its boundary. Individual room lists and anomaly contents remain outside REF-05.

| Level | Level purpose | Division count |
|---|---|---:|
| L1 | Surface Operations | 6 |
| L2 | Administration & Clinical Services | 6 |
| L3 | Light Containment Operations | 7 |
| L4 | Heavy Containment Operations | 7 |
| L5 | Heavy Storage & Critical Custody | 6 |
| **Site total** | **Facility structure only** | **32** |

## L1 — Surface Operations

| Designation | Functional title | Purpose | Map-level zones | Boundary and route interfaces |
|---|---|---|---|---|
| `S19-L1-01` | Perimeter Security Division | Controls the restricted reservation, monitored approach, outer access road, and first response to an unexplained exterior event. | **A:** Approach surveillance; **B:** Controlled road corridor; **C:** Perimeter response support. | Begins at the outer reservation line; passes cleared movements to L1-02, L1-03, L1-04, or L1-05 only. |
| `S19-L1-02` | Personnel Access Division | Screens cleared staff, controls carried items, manages lockers and arrival checks, and sends authorised personnel to the personnel core. | **A:** Credential verification; **B:** Personal screening/lockers; **C:** Personnel-lift lobby. | Security gate after L1-01; personnel core descends to L2 only. |
| `S19-L1-03` | Vehicle & Freight Division | Receives service vehicles, inspected cargo, equipment, and controlled deliveries for handoff into the freight core. | **A:** Vehicle holding/inspection; **B:** Covered freight transfer; **C:** Freight-lift interface. | Freight gate after L1-01; connects only to the L3 materials and L5 logistics routes. |
| `S19-L1-04` | Custody Transfer Division | Handles controlled human transfer under discrete security conditions and sends it to L3 custody processing. | **A:** Secure vehicle port; **B:** Transfer holding; **C:** Custody-lift interface. | Separate custody gate after L1-01; no connection to L2 staff arrival or normal freight. |
| `S19-L1-05` | Air Operations Division | Supports authorised aircraft arrival, rapid deployment, controlled transfer, and emergency air evacuation. | **A:** Landing/apron zone; **B:** Secure handoff zone; **C:** Air-operations support. | Air perimeter control; handoff to protected personnel, clinical, or response routes only. |
| `S19-L1-06` | Surface Infrastructure & Egress Division | Maintains surface utilities, protected service interfaces, exterior maintenance access, and sealed emergency exits from below. | **A:** Utility interface; **B:** Surface service support; **C:** Egress control. | Restricted service boundary; accepts the emergency egress network but never functions as routine entry. |

## L2 — Administration & Clinical Services

| Designation | Functional title | Purpose | Map-level zones | Boundary and route interfaces |
|---|---|---|---|---|
| `S19-L2-01` | Site Command & Administration Division | Directs site operations, department administration, controlled briefings, schedules, and executive coordination. | **A:** Command suite; **B:** Department administration; **C:** Secure briefing/coordination. | Receives normal staff arrival from the L1 personnel core; no direct containment route. |
| `S19-L2-02` | Personnel, Credentials & Records Division | Manages assignment records, access administration, personnel processing, secure documentation, and internal identity control. | **A:** Personnel operations; **B:** Credential administration; **C:** Secure records custody. | Security-door boundary from the L2 staff core; interfaces with L2-01 and L2-06. |
| `S19-L2-03` | Clinical Services Division | Provides physical care, diagnostics, treatment, behavioural health, psychology, pharmacy, rehabilitation, and clinical isolation. | **A:** Acute/diagnostic care; **B:** Behavioural and psychological care; **C:** Pharmacy/clinical support; **D:** Clinical isolation. | Separate clinical boundary; receives controlled patients through L2-04, not ordinary operational corridors. |
| `S19-L2-04` | Clinical Transfer & Stabilization Division | Receives protected clinical transfers from deeper operations, stabilizes them, and hands patients into the full L2 clinical service system. | **A:** L3 transfer intake; **B:** L4 protected transfer interface; **C:** Decontamination/transfer support. | Clinical-transfer gate; connects L3/L4 transfer core to L2-03 without crossing administration. |
| `S19-L2-05` | Controlled Applied Anomalies Division | Holds the level’s small, separately secured support/research work cells for authorised anomalous processes. The map records the division, not its contents. | **A:** Applied-work cell group; **B:** Controlled output/interface zone; **C:** Annex control point. | Heavy security boundary from L2 staff core; isolated from general offices and main clinical circulation. |
| `S19-L2-06` | Personnel Readiness & Operations Control Division | Runs qualified-personnel briefings, procedure refreshers, assignment preparation, L2 communications, and transition control toward L3. | **A:** Briefing/qualification; **B:** L2 operations control; **C:** Light-Gate approach. | Light Gate to L3; it is the only normal staff transition from L2 to L3. |

## L3 — Light Containment Operations

| Designation | Functional title | Purpose | Map-level zones | Boundary and route interfaces |
|---|---|---|---|---|
| `S19-L3-01` | LCZ Entry & Operations Control Division | Receives assigned staff through the Light Gate, verifies local assignment, directs daily LCZ operations, and controls the approach to deeper access. | **A:** Light-Gate reception; **B:** LCZ control; **C:** Heavy-Gate approach. | Light Gate from L2-06; interfaces with all L3 divisions and the L4 heavy-access route. |
| `S19-L3-02` | Light Containment Division | Operates grouped lower-risk containment sectors and the internal service corridors needed to maintain them. | **A:** Containment cluster A; **B:** Containment cluster B; **C:** Containment service spine. | Security-door boundaries from L3-01; controlled service connection to L3-06. |
| `S19-L3-03` | Research, Analysis & Interview Division | Provides approved L3 research work, observation, interview, evidence examination, and report production near light containment operations. | **A:** Research work zone; **B:** Analysis/evidence zone; **C:** Interview/observation zone. | Controlled interface with L3-02 and L3-06; no direct custody housing route. |
| `S19-L3-04` | Custody Processing & D-Class Division | Receives, houses, supports, stages, and escorts controlled custody populations for approved operational tasks. | **A:** Custody intake; **B:** Housing/welfare; **C:** Staging/escort control. | Dedicated L1-04 custody core; buffered from L3-05 and no route through L2. |
| `S19-L3-05` | Shift Support Division | Supports long LCZ shifts through food service, sanitation, changing, rest, and local supply issue. | **A:** Meal service; **B:** Changing/rest; **C:** Sanitation/local issue. | General assigned-staff route from L3-01; buffered from L3-04 custody housing and L3-02 containment service spine. |
| `S19-L3-06` | Materials & Service Intake Division | Receives cleared freight, holds local materials, separates operational waste, and feeds controlled service delivery to L3 work divisions. | **A:** Freight-lift intake; **B:** Local stores; **C:** Waste/service handoff. | Dedicated freight core from L1-03; no normal personnel or custody entry. |
| `S19-L3-07` | LCZ Medical Stabilization Division | Provides immediate stabilization and protected movement to L2 Clinical Services for cases that cannot traverse normal corridors. | **A:** Immediate stabilization; **B:** Protected clinical handoff; **C:** Local response support. | Clinical-transfer gate to L2-04; not a substitute for L2’s full clinical division. |

## L4 — Heavy Containment Operations

| Designation | Functional title | Purpose | Map-level zones | Boundary and route interfaces |
|---|---|---|---|---|
| `S19-L4-01` | HCZ Transition Control Division | Receives deliberately authorised movement beyond the L3 Heavy Gate, verifies specialist assignment, and directs all L4 movement. | **A:** Heavy-Gate reception; **B:** Assignment/route control; **C:** Restricted-lift interface. | Heavy Gate from L3-01; no casual entry and no direct general freight route. |
| `S19-L4-02` | Heavy Containment Division | Runs high-risk containment sectors, their internal service spines, and compartmentalized access. | **A:** Heavy containment cluster A; **B:** Heavy containment cluster B; **C:** Restricted service spine. | Security barriers from L4-01; controlled service interface with L4-07. |
| `S19-L4-03` | Deep Isolation Division | Provides the site’s most isolated high-consequence containment capability. | **A:** Deep approach control; **B:** Isolation cluster; **C:** Restricted service support. | Deep Isolation Gate after L4-01; no through-route to other divisions. |
| `S19-L4-04` | Specialist Research & Observation Division | Supports high-risk specialist work, controlled observation, and analysis that cannot occur in L2 or L3. | **A:** Controlled observation; **B:** Specialist workrooms; **C:** Restricted analysis support. | Interface to L4-02/L4-03 by approved work route; not a general corridor. |
| `S19-L4-05` | Decontamination & Clinical Stabilization Division | Stabilizes personnel and prepares protected clinical transfer where ordinary L2 movement would be unsafe. | **A:** Decontamination; **B:** Stabilization; **C:** Protected clinical departure. | Clinical transfer core to L2-04; separated from ordinary L4 circulation. |
| `S19-L4-06` | Containment Response Support Division | Holds controlled response staging, local incident coordination, and restricted equipment support for L4 incidents. | **A:** Response staging; **B:** Local command support; **C:** Restricted equipment issue. | Reaches L4 work divisions without becoming a normal traffic route. |
| `S19-L4-07` | HCZ Service & Waste Control Division | Handles restricted maintenance, material handoff, and contained waste movement for L4. | **A:** Service interface; **B:** Restricted maintenance; **C:** Contained waste handoff. | Service-core connection; never shares the L4 personnel approach. |

## L5 — Heavy Storage & Critical Custody

| Designation | Functional title | Purpose | Map-level zones | Boundary and route interfaces |
|---|---|---|---|---|
| `S19-L5-01` | Heavy Storage Division | Holds long-term controlled storage, reserve supplies, and non-routine logistics under scheduled access. | **A:** Storage cluster A; **B:** Storage cluster B; **C:** Restricted loading/staging. | Freight/service core; not a staff transit route. |
| `S19-L5-02` | Restricted Item & Medical Custody Division | Holds scarce, high-authority, or medically sensitive assets awaiting controlled release. | **A:** Restricted custody; **B:** Medical custody; **C:** Controlled issue handoff. | Separate custody boundary from L5-01; connects to approved clinical/freight handoffs only. |
| `S19-L5-03` | Secure Archive & Evidence Custody Division | Protects restricted physical records, sealed evidence, historical holdings, and sensitive material not used in routine L2 records work. | **A:** Secure archive; **B:** Evidence custody; **C:** Sealed holdings. | Scheduled access through L5 logistics control; no routine L2 document circulation. |
| `S19-L5-04` | Critical Maintenance & Utility Reserve Division | Supports deep plant access, reserve equipment, protected infrastructure, and controlled maintenance staging. | **A:** Utility reserve; **B:** Deep plant interface; **C:** Maintenance staging. | Service core under defined work order; no general storage path. |
| `S19-L5-05` | Omega Contingency Division | Preserves the site’s separately authorised, limited last-resort contingency capability. | **A:** Vault approach; **B:** Contingency vault; **C:** Independent control support. | Independent high-security boundary; no normal circulation through the division. |
| `S19-L5-06` | L5 Logistics Control Division | Manages scheduled movement through deep freight/service lifts and custody handoffs without allowing L5 to become a shortcut. | **A:** Deep lift control; **B:** Handoff/staging; **C:** Logistics oversight. | Connects freight/service cores to L5 divisions under assignment; no personnel-transit function. |

## What this map deliberately does not decide

The draft does not assign any individual SCP, person, room number, exact floor-plan geometry, named corridor, or tactical containment detail. It decides the stable facility structure first. Those lower-level details can be added later through the appropriate dossier or division record without breaking the site model.
