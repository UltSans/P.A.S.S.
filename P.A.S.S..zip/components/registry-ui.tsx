import { ReactNode } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";

import { haptic } from "@/lib/haptics";

export const palette = {
  canvas: "#11100F",
  panel: "#191817",
  panelRaised: "#211F1D",
  ink: "#E9E4D9",
  muted: "#A29A8C",
  line: "#413C35",
  // Existing generic accents resolve to Foundation red. MTF-only interfaces must
  // use mtfBlue explicitly rather than this general palette key.
  blue: "#B33B35",
  mtfBlue: "#4F9CD9",
  green: "#778D67",
  amber: "#BD8740",
  red: "#D15B54",
  slate: "#D3CDC0",
};

export function Eyebrow({ children }: { children: ReactNode }) {
  return <Text style={styles.eyebrow}>{children}</Text>;
}

export function Panel({ children, style }: { children: ReactNode; style?: object }) {
  return <View style={[styles.panel, style]}>{children}</View>;
}

export function StatusTag({ label, tone = "blue" }: { label: string; tone?: "blue" | "green" | "amber" | "red" | "slate" }) {
  const colors = {
    blue: { backgroundColor: "#3B1D1A", color: palette.blue },
    green: { backgroundColor: "#263024", color: palette.green },
    amber: { backgroundColor: "#392B17", color: palette.amber },
    red: { backgroundColor: "#3D1E1B", color: palette.red },
    slate: { backgroundColor: "#302E2B", color: palette.slate },
  }[tone];
  return <View style={[styles.tag, { backgroundColor: colors.backgroundColor }]}><Text style={[styles.tagText, { color: colors.color }]}>{label.toUpperCase()}</Text></View>;
}

export function PrimaryButton({ label, onPress, icon = "plus", muted = false }: { label: string; onPress: () => void; icon?: keyof typeof MaterialCommunityIcons.glyphMap; muted?: boolean }) {
  return (
      <Pressable android_ripple={{ color: "rgba(255,255,255,0.14)" }} onPress={() => { haptic.light(); onPress(); }} style={[styles.button, muted && styles.mutedButton]}>
      <MaterialCommunityIcons name={icon} size={18} color={muted ? palette.ink : "#FFF7EE"} />
      <Text style={[styles.buttonLabel, muted && styles.mutedButtonLabel]}>{label}</Text>
    </Pressable>
  );
}

export function EmptyState({ icon, title, detail, action }: { icon: keyof typeof MaterialCommunityIcons.glyphMap; title: string; detail: string; action?: ReactNode }) {
  return <View style={styles.empty}><View style={styles.emptyIcon}><MaterialCommunityIcons name={icon} color={palette.blue} size={28} /></View><Text style={styles.emptyTitle}>{title}</Text><Text style={styles.emptyDetail}>{detail}</Text>{action}</View>;
}

export function ScreenTitle({ label, title, detail, action }: { label: string; title: string; detail?: string; action?: ReactNode }) {
  return <View style={styles.titleBlock}><View style={styles.titleCopy}><Eyebrow>{label}</Eyebrow><Text style={styles.title}>{title}</Text>{detail ? <Text style={styles.detail}>{detail}</Text> : null}</View>{action}</View>;
}

const styles = StyleSheet.create({
  eyebrow: { color: palette.blue, fontSize: 10, fontWeight: "900", letterSpacing: 1.45, lineHeight: 15 },
  panel: { backgroundColor: palette.panel, borderColor: palette.line, borderWidth: 1, borderRadius: 4, padding: 16 },
  tag: { alignSelf: "flex-start", borderRadius: 2, paddingHorizontal: 7, paddingVertical: 4 },
  tagText: { fontSize: 9, fontWeight: "800", letterSpacing: 0.9 },
  button: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, minHeight: 52, paddingHorizontal: 16, borderRadius: 4, backgroundColor: "#A8332E", borderColor: "#D15B54", borderWidth: 1, elevation: 2 },
  mutedButton: { backgroundColor: palette.panelRaised, borderWidth: 1, borderColor: palette.line },
  buttonLabel: { color: "#FFF7EE", fontSize: 13, fontWeight: "900", letterSpacing: 0.5 },
  mutedButtonLabel: { color: palette.ink },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
  empty: { paddingVertical: 48, paddingHorizontal: 24, alignItems: "center", gap: 10 },
  emptyIcon: { height: 60, width: 60, borderRadius: 4, justifyContent: "center", alignItems: "center", backgroundColor: "#3B1D1A", marginBottom: 4 },
  emptyTitle: { color: palette.ink, fontSize: 17, fontWeight: "800" },
  emptyDetail: { color: palette.muted, fontSize: 13, lineHeight: 19, textAlign: "center", maxWidth: 280 },
  titleBlock: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 12 },
  titleCopy: { flex: 1, gap: 3 },
  title: { color: palette.ink, fontSize: 27, fontWeight: "800", letterSpacing: -0.5, lineHeight: 33 },
  detail: { color: palette.muted, fontSize: 13, lineHeight: 19, marginTop: 3 },
});
