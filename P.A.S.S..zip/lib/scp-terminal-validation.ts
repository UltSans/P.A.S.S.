import type { TerminalEscalation } from "./registry-types";

export function terminalDocumentationError({
  isEditing,
  originalDesignation,
  selectedDesignation,
  scenario,
  rationale,
}: {
  isEditing: boolean;
  originalDesignation?: TerminalEscalation;
  selectedDesignation: TerminalEscalation;
  scenario: string;
  rationale: string;
}) {
  const unchangedLegacyDesignation = isEditing && originalDesignation === selectedDesignation;
  if (unchangedLegacyDesignation) return undefined;
  const needsScenario = selectedDesignation === "K-Class Scenario" || selectedDesignation === "Apollyon Condition + K-Class Scenario";
  const needsRationale = selectedDesignation === "Apollyon Condition" || selectedDesignation === "Apollyon Condition + K-Class Scenario";
  if (needsScenario && !scenario.trim()) return "A named K-Class scenario is required for this terminal escalation designation.";
  if (needsRationale && !rationale.trim()) return "An Apollyon condition requires an escalation rationale and response basis.";
  return undefined;
}
