# PASS Action Permissions & SCP Reference Strategy — Proposal

## Purpose

PASS already uses the active reader’s clearance to control **visibility**. The next step is to make that clearance govern **actions**: what a reader may create, amend, export, link, or administer. This must remain separate from a personnel file’s job, class, departmental authority, and keycard because those describe the subject of a record, not the active PASS session.

The proposal also sets a safe, sustainable approach to canonical SCP reference data. It rejects a silent bulk copy-and-rewrite model: official SCP material can be used only with clear source attribution, the appropriate share-alike licensing treatment, and an honest label when PASS has summarized, normalized, or locally adapted it.

## Core rule

> **Reader clearance governs database authority; personnel profiles describe institutional authority; keycards govern physical access. None of the three substitutes for the other.**

Every permission below is additionally limited by the record’s own minimum clearance. A Level 4 reader cannot export a Level 5 file, and joining a record to a Project never gives the Project reader access to that record.

## Proposed action matrix

| Reader level | Read scope | Create | Amend | Export | Administration |
|---|---|---|---|---|---|
| **Level 1** | Guide, Database references, low-clearance SCP/Personnel/Project metadata, L1 Facility Records. | None. | None. | None. | None. |
| **Level 2** | Level 2 records and applicable facility sectors. | Draft Entry documents inside readable SCP/Personnel files; import a local typeface. | Amend only an unfinished Entry draft in a future editing workflow. | None. | No record, font-deletion, or keycard administration. |
| **Level 3** | Level 3 records and L3 Facility Records. | SCP records up to Level 3; research Teams; Projects up to Level 3; structured Entries. | Amend accessible SCP research content, Team/Project scope, and non-keycard Personnel descriptive data. | TXT/PDF export of readable Entries. | No clearance elevation above Level 3; no keycard or facility-record edits. |
| **Level 4** | Level 4 records and L4 Facility Records. | Personnel profiles; controlled Projects up to Level 4; access-change Entries. | Amend accessible classification, personnel keycard/category assignments, restrictions, record clearance up to Level 4, and Team/Project membership. | Export readable controlled records and Entries. | Remove typefaces with fallback confirmation; approve or suspend Projects; modify future Site-19 registry data except deep-contingency policy. |
| **Level 5** | Full reader scope, subject to purpose-limited L5 asset summaries. | All supported record types, including Level 5 controlled records. | All supported records and classifications; archive/remove records where the application exposes a governed archival workflow. | Export readable records and Entries. | Administer Typeface Library, all Project clearance, site registry, source references, and future curated SCP imports. |

## Why the matrix is intentionally strict

### Record creation is not a casual action

Creating an SCP profile changes the registry and can misstate containment, clearance, or risk. Level 3 is the lowest reasonable authoring threshold for a research record, but the system must stop a Level 3 session from assigning a Level 4 or Level 5 document classification. Level 4 controls formal personnel profiles and keycard assignments because those alter site access and an individual’s institutional standing.

### Projects coordinate; they do not authorize

Level 3 can establish a working Project because multidisciplinary research needs a coordination layer. The Project clearance may not exceed the reader’s clearance. When a Project links a Level 4 SCP, a Level 3 reader sees neither the protected SCP data nor a link that bypasses it.

### Typefaces are document assets, not language access

Level 2 may import an `.ttf` or `.otf` for use in readable Entries. Removal is retained for Level 4 and above because it can change the visual rendering of existing documents, even though PASS preserves their Unicode text and falls back safely. The library should never expose an artificial “language usage count.”

### Export is controlled disclosure

Level 3 is the minimum proposed level for TXT/PDF export. The existing per-record clearance gate remains the first check; the additional action permission prevents a low-clearance reader from turning otherwise readable excerpts into portable copies.

## Required implementation behavior

| Rule | PASS behavior |
|---|---|
| **Unauthorized action** | Hide the action in directories where possible; show a clear `Level N authority required` explanation when a reader reaches a protected detail control. |
| **No clearance escalation** | Every editor limits selectable minimum-clearance values to the active reader’s own level. |
| **No indirect disclosure** | Project cards, Team links, search results, and Facility Records may not leak labels, counts, or descriptions for a linked record above reader clearance. |
| **Controlled edit separation** | Profile identity/descriptive edits, classification changes, keycard changes, Project status changes, and archive/destructive actions are evaluated independently. |
| **Guide accuracy** | “Your Access” must list both what the present reader can see and the actions they can perform in this session. |

## Curated SCP reference-data strategy

### Do not attempt “every SCP” as a first import

The SCP Wiki has thousands of entries, revisions, tales, translations, and alternative canons. A blanket scrape would be difficult to review, easy to misattribute, and would make local performance and maintenance worse. It should be treated as a controlled data-publication project, not a seed-data shortcut.

The recommended first release is a **curated Reference Catalog**: a small, deliberately chosen set of canonical SCP entries that are useful to the user’s projects. Each imported item has source metadata, a source status, and a PASS presentation layer.

### Required source metadata

| Field | Requirement |
|---|---|
| **Source title / item** | Original SCP identifier and article title. |
| **Source URL** | Direct canonical article URL. |
| **Author attribution** | Specific author where available; otherwise attribution to the SCP Wiki as appropriate. |
| **License** | `CC BY-SA 3.0` and a link to the license. |
| **Retrieved / reviewed date** | Enables later refresh and review. |
| **PASS source status** | `Quoted source text`, `PASS summary`, `PASS operational adaptation`, or `User-created record`. |
| **Change note** | Required whenever PASS truncates, normalizes classification, paraphrases, or supplies a local redaction placeholder. |

### Content rules

1. **Quoted source text** stays visibly quoted and attributed. PASS does not claim authorship.
2. **PASS summaries** are concise operational summaries, not reconstructed article prose.
3. **PASS operational adaptations** may reconcile classifications with the PASS framework, shorten material for a mobile dossier, or mark unavailable text as `Source detail withheld from local operational copy`. They must never be labelled as the canonical article.
4. **Do not fabricate a redacted canonical passage.** If PASS invents a placeholder, it must be identified as a local operational placeholder, not source text.
5. The application’s distribution and copied/adapted reference content must honor the SCP Wiki’s attribution and CC BY-SA 3.0 requirements.

## Suggested first catalog, not an automatic import

Start with a short, reviewable group selected for Site-19 references and Project work—for example, SCP-914, SCP-682, and other records the user explicitly asks PASS to support. Each item is reviewed one by one before entry. The user’s own SCP-9743-1 stays separate as `User-created record` and never becomes evidence for canonical data rules.

## Implementation sequence after approval

1. Add a pure permission helper and tests for all Level 1–5 actions.
2. Apply permissions to navigation, record creation, editors, Entries, exports, Script Library, Projects, and record administration.
3. Replace the Guide’s generic clearance table with live, session-specific `Your Access` actions.
4. Add source metadata to SCP records and an attribution reference screen.
5. Implement only the first user-approved curated catalog batch, with source status and adaptation notes.

## Source

The official SCP Wiki licensing guide states that derivative works should attribute the wiki and specific author where possible, and apply the **Creative Commons Attribution-ShareAlike 3.0** license to the derivative work. [1]

[1] [SCP Wiki — Licensing Guide](https://scp-wiki.wikidot.com/licensing-guide)
