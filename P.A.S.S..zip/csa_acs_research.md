# CSA / ACS Classification Research

## Primary sources

| Source | Key finding |
|---|---|
| [Object Classes](https://scp-wiki.wikidot.com/object-classes) | Object Class is a containment-oriented classification. The guide lists primary classes such as Safe, Euclid, Keter, and Thaumiel; secondary classes including Apollyon, Archon, Argus, Cernunnos, and Ticonderoga; and non-standard statuses such as Explained, Neutralized, Decommissioned, Pending, and Uncontained. |
| [Anomaly Classification System Guide](https://scp-wiki.wikidot.com/anomaly-classification-system-guide) | ACS supplements rather than replaces Object Class. Its primary component bar is composed of Clearance Level, Containment Class, Secondary Class, Disruption Class, and Risk Class. |
| [Anomaly Classification Bar Component](https://scp-wiki.wikidot.com/component:anomaly-class-bar) | Gives the concrete standard component vocabulary: containment options Safe, Euclid, Keter, Neutralized, Pending, Explained, and Esoteric; disruption options Dark, Vlam, Keneq, Ekhi, and Amida; risk options Notice, Caution, Warning, Danger, and Critical; and commonly configured secondary options including Apollyon, Archon, Cernunnos, Hiemal, Tiamat, Ticonderoga, Thaumiel, and Uncontained. |

## Product-safe interpretation

The SCP profile should retain the existing containment/object classification, then expand to a structured **ACS Classification** block. Each dimension answers a different operational question: who may read the file; how difficult the anomaly is to contain; whether it has an additional special classification; how much it could disrupt the status quo; and the severity/recoverability of its effects on individuals.

The system should present established vocabulary as selectable values and allow a clearly marked **Custom / Esoteric** value when a user needs a record that does not fit the standard choices. It should not imply that every SCP must use every optional secondary classification. The new profile needs separate values for **Containment Class** and **Secondary Class**—rather than one generic object-class dropdown—because a secondary class may qualify the record while the containment class still expresses the core containment situation.

## Additional secondary-class context

The available component list includes some esoteric classes that do not receive a generalized entry in the main Object Classes guide. The primary article for **Hiemal** shows it being applied after containment contributes to a worsening interrelated anomalous situation; PASS will describe it conservatively as a specialized/esoteric classification whose precise operational rationale must be documented in the SCP file. The primary article for **Tiamat** explicitly describes it as an immediate threat that can only be contained through Veil-breaking actions. These explanations preserve the terms’ documented use without presenting any esoteric class as a universal default.

## Taxonomy check: Ticonderoga and Thaumiel

The current official **Object Classes** guide lists **Ticonderoga** among the secondary classes, defining it as an anomaly that cannot be contained but does not need to be contained because containment is not currently possible or necessary. The official ACS guide separately states that **Thaumiel** is a secondary class, not a containment class. This creates a real modeling ambiguity for the user’s original SCP-9743-1 example, which uses Ticonderoga in the Containment Class slot and Thaumiel as Secondary Class. PASS should preserve a clear standard ACS mode, but may need an explicitly user-directed flexible classification mode for original files rather than silently treating the user’s model as incorrect.

## ACS component rule and user-file flexibility

The standard official ACS bar accepts only **Safe, Euclid, Keter, Neutralized, Pending, Explained, and Esoteric** in its Containment Class field. Its instructions state that using a Secondary Class requires the Containment Class to be **Esoteric**, and list Ticonderoga and Thaumiel as Secondary Class options. The official customizable ACS add-on separately supports a **Custom Containment Class** and a split display with a Secondary Class. This supplies a transparent PASS solution: keep the standard ACS mode accurate, but offer a clearly labeled **Custom / Extended Containment Designation** mode for original files such as SCP-9743-1, allowing Ticonderoga as the user-defined containment designation with Thaumiel secondary while documenting that this is a customized ACS layout.
