import { Modal, Pressable, StyleSheet, Text, View } from "react-native";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";

import { Eyebrow, palette } from "@/components/registry-ui";
import { vocabularyDefinition } from "@/lib/foundation-vocabulary";
import { personnelReferenceDefinition } from "@/lib/personnel-reference";

export function ContextDefinitionModal({ term, onDismiss }: { term: string | null; onDismiss: () => void }) {
  const vocabulary = vocabularyDefinition(term);
  const personnel = vocabulary ? undefined : personnelReferenceDefinition(term);
  const definition = vocabulary ?? personnel;
  const category = vocabulary?.category ?? "PERSONNEL REFERENCE";
  const guidance = vocabulary?.guidance ?? personnel?.use;
  return <Modal transparent visible={Boolean(definition)} animationType="fade" onRequestClose={onDismiss}><Pressable style={styles.backdrop} onPress={onDismiss}><Pressable style={styles.sheet} onPress={(event) => event.stopPropagation()}><View style={styles.header}><View style={styles.copy}><Eyebrow>{category}</Eyebrow><Text style={styles.title}>{term}</Text></View><Pressable style={styles.close} onPress={onDismiss}><MaterialCommunityIcons name="close" size={19} color={palette.ink} /></Pressable></View><Text style={styles.summary}>{definition?.summary}</Text><View style={styles.rule} /><Text style={styles.guidance}>{guidance}</Text><Text style={styles.footnote}>Long-press is provided only for terms that benefit from operational context.</Text></Pressable></Pressable></Modal>;
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.76)", padding: 16 },
  sheet: { backgroundColor: palette.panelRaised, borderColor: "#64312C", borderWidth: 1, borderRadius: 3, padding: 18, gap: 12 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 12 },
  copy: { flex: 1, gap: 2 },
  title: { color: palette.ink, fontSize: 22, fontWeight: "900" },
  close: { height: 40, width: 40, justifyContent: "center", alignItems: "center", borderColor: palette.line, borderWidth: 1, borderRadius: 2 },
  summary: { color: palette.ink, fontSize: 15, fontWeight: "800", lineHeight: 21 },
  rule: { height: 1, backgroundColor: palette.line },
  guidance: { color: palette.slate, fontSize: 13, lineHeight: 20 },
  footnote: { color: palette.muted, fontSize: 10, lineHeight: 15 },
});
