# PASS / Site-19 — Spatial Language and Placement Rules

## Status

**Working design for review.** This establishes the vocabulary that makes a detailed PASS-local Site-19 feel like a coherent operating facility. It is original to PASS. It borrows the understandable idea of escalating doors and gates from containment fiction, but does not reproduce a game layout, room arrangement, or access sequence.

## Core rule

> A barrier exists because it separates two different operating conditions: different people, materials, hazards, authority, or response requirements.

A card, gate, lift, or sector may never exist merely because it would look like a game map. Every mapped element must state its job, its permitted traffic, and the condition it prevents.

## Site structure

Site-19 has five fixed levels. Each level contains one or more **divisions**. A division is a functional part of the facility such as medical services, D-Class custody, a containment cluster, records control, or deep storage.

Within a division, a **sector** is the controlled operating area that PASS can name and associate with records. A sector is not necessarily a single room; it can be a suite, a wing, a custody block, a laboratory group, or a contained service area. Individual rooms are named only when a record needs the precision.

| Layer | Meaning | Example use in PASS |
|---|---|---|
| **Level** | The broad operating environment. | L3 is the Light Containment Zone. |
| **Division** | A group of related functions with compatible traffic and authority. | L3 Research & Applied Studies Division. |
| **Sector** | The addressable controlled area where a function is carried out. | A supervised engineering annex. |
| **Room / Asset location** | A precise location only when operationally justified. | A specific SCP chamber, interview room, or clinical suite. |

## PASS access boundaries

The existing PASS keycard and clearance model determines **who may request access**. The facility model adds the physical question: **what boundary must that person cross and why?** Clearance alone never converts an ordinary corridor into a valid route.

| Boundary | What it separates | Normal condition | Why it exists |
|---|---|---|---|
| **Internal Access Door** | Compatible functions inside one ordinary work division. | Credential check where needed; normal foot traffic. | Keeps administrative, medical, records, or service work private without treating every room as a fortress. |
| **Controlled Door** | A sector with limited staff, records, patients, tools, or materials. | Keycard plus sector entitlement. | Enforces least privilege within the same level, such as medical files or credential administration. |
| **Containment Door** | A containment, testing, anomalous-support, or custody sector from normal staff movement. | Authorized entry, logged movement, and local sector supervision. | Prevents casual traffic into areas where anomalous material, D-Class custody, or controlled testing is present. |
| **Light Gate** | A major transition from ordinary site work into LCZ-controlled circulation, or between incompatible LCZ divisions. | Keycard, routing control, and a monitored threshold. | Makes containment access a deliberate decision rather than an extension of an office corridor. |
| **Heavy Gate** | A transition into HCZ, a high-security transfer route, or a sector that must be isolated quickly. | Specific authority, confirmed destination, and controlled passage. | Separates high-risk containment conditions from routine research and LCZ shift traffic. |
| **Isolation Gate Pair** | A deep-isolation sector, high-consequence asset, or containment enclosure. | Sequential controlled access; entry and exit are independently monitored. | Prevents a single opened barrier from exposing the surrounding circulation system. |
| **Emergency Barrier** | An emergency-only fire, contamination, or incident compartment boundary. | Used for authorized safety isolation or evacuation, not daily shortcuts. | Lets the facility protect people and contain effects without converting emergency infrastructure into normal navigation. |

### Gates are boundaries, not decorations

An L3 heavy gate leading to the L4 transfer elevator is therefore a valid design choice. Its meaning is explicit: personnel leave the LCZ circulation system, present authority for a specific HCZ destination, and enter a transfer route that cannot be used as ordinary traffic. The L4 Deep Isolation route can require a further isolation-gate pair; this keeps the SCP-682 sector separate from even the rest of HCZ.

## Circulation types

The facility does not have one universal elevator chain. It has several overlapping circulation systems, each designed around who or what moves through it.

| Route type | Carries | Permitted purpose | Must not become |
|---|---|---|---|
| **Personnel circulation** | Cleared staff and controlled visitors. | Arrival, shifts, approved work destinations, and return. | A bypass into containment or storage. |
| **Logistics circulation** | Screened freight, equipment, consumables, and authorized material transfers. | Receiving, storage, planned resupply, and controlled handoff. | A public or staff shortcut. |
| **Clinical transfer circulation** | Patients, medical teams, and controlled clinical supplies. | Routine transfer, escalation, or movement to specialist isolation. | A route through ordinary office or cafeteria traffic during an exposure event. |
| **Containment transfer circulation** | Secured anomalous assets, D-Class dispatch, controlled test material, and escorted containment staff. | Scheduled movement between authorised sectors. | A shared path with unrestricted staff services. |
| **Restricted response circulation** | Approved incident, containment, and recovery personnel. | An authorized response to a protected sector. | A daily convenience route. |
| **Maintenance circulation** | Utilities staff and service equipment. | Access to site systems while minimizing intrusion into protected work zones. | An unmonitored bypass around access boundaries. |
| **Emergency egress** | Personnel leaving under authorized emergency conditions. | Safe evacuation or emergency relocation. | A normal way to avoid a checkpoint. |

## SCP placement standard

SCP placement is determined by the asset’s **operational posture**, not solely by its containment class, popularity, or a prior game placement. A Safe item can require a more protected location than an Euclid item if its traffic, misuse potential, privacy, or consequence profile requires it. Conversely, a tightly controlled anomalous asset may support a medical or applied-research function outside the main LCZ if that placement is justified.

| Placement question | What PASS must answer |
|---|---|
| **Primary role** | Is the asset medical, research, training, containment, storage, welfare, logistics, or another function? |
| **Access cadence** | Is it used rarely, scheduled daily, frequently by one team, or only during an incident? |
| **Users and supervision** | Who may use it, who observes use, and who approves exceptions? |
| **Input/output control** | What enters and leaves the sector, and how is it checked? |
| **Failure or misuse consequence** | What happens if ordinary procedures fail or an unauthorised person reaches it? |
| **Traffic compatibility** | Can it sit near office, clinical, research, LCZ, HCZ, or storage traffic without creating an unjustified risk? |
| **Response and recovery need** | Does it need immediate clinical, security, research, maintenance, or containment support nearby? |

### Examples of justified flexible placement

| Asset type | Plausible placement | Why the placement can be defensible | Required boundary |
|---|---|---|---|
| **Controlled medical asset, including a limited SCP-500 reserve** | L2 Clinical Anomalous Care Annex inside the larger medical division. | Clinical staff can maintain inventory, approve use, and treat ordinary patients without routing every case into LCZ. | Controlled door, pharmacy-grade custody, and clinical authorization; not a public clinic cabinet. |
| **Applied conversion/engineering asset, including SCP-914** | An L2–L3 Applied Anomalous Systems Annex located behind a containment door and separate from office circulation. | It can support supervised engineering, vetted junior-researcher observation, and scheduled material evaluation while remaining close to administrative research oversight. | Containment door, dedicated material handoff, direct research supervision, and no access from ordinary offices. |
| **Low-impact service asset, including an anomalous beverage machine** | A contained L2 staff-services observation alcove or an L3 service annex, depending on its output controls. | It may support staff welfare or controlled behavioural observation if it does not introduce incompatible containment risk. | Controlled door and logged use; move it to L3 if inputs/outputs require research handling. |
| **High-consequence or unstable asset** | L4 containment or an isolated deep sector. | The need for hard isolation, response readiness, and limited traffic overrides convenience. | Heavy gate or isolation-gate pair with protected response routes. |
| **Inert, rare-use, or long-hold asset** | L5 storage division. | It needs logged retrieval and stable storage rather than daily access. | Secure logistics route and purpose-limited vault controls. |

These examples are placement patterns. PASS does not assume that every item of a type belongs there. The dossier’s own operational explanation decides the location.

## Mapping detail standard

The finished Site-19 map should be detailed enough to answer ordinary operational questions:

| A reader asks | The map should explain |
|---|---|
| “Where does this employee work?” | Their level, division, sector, and the controlled route they use. |
| “Where is this SCP used or contained?” | Its justified operational sector and what boundary protects it. |
| “How does freight reach deep storage?” | The logistics route and controlled handoffs, without tactical or engineering detail. |
| “Why can’t an L3 worker just enter HCZ?” | The Heavy Gate, destination authorization, and restricted transfer circulation. |
| “Why is this medical or research asset not in a cell block?” | Its operational role, supervision, and traffic compatibility. |

The finished map should remain intentionally non-tactical. It can identify a division, sector, route type, gate class, and administrative access condition. It must not become an evasion guide, chamber blueprint, weapon procedure, or detailed emergency response manual.

