import type { PersonnelRecord } from "@/lib/registry-types";

export function defaultFacilityAssignment(record: Partial<PersonnelRecord>): string {
  if (record.facilityAssignment?.trim()) return record.facilityAssignment.trim();
  return record.site === "Site-19" ? "No current Site-19 division assignment recorded" : "Not assigned to Site-19";
}
