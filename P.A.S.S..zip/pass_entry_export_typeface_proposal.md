# PASS Entry Export and Typeface Proposal

## Decision requested

This proposal adds two connected document features without changing the classification system, keycard model, or entry-folder structure:

1. **Export any SCP or personnel Entry as UTF-8 TXT or PDF.**
2. **Import local TTF/OpenType typefaces into a reusable library and apply them to any number of document blocks and PDF exports.**

The goal is not a generic rich-text editor. The goal is a realistic archive: an interview with SCP-049 can preserve an ancient-French typeface or constructed script in the relevant spoken lines while the surrounding PASS database remains legible and standardised.

> **Core rule:** PASS always stores the original Unicode text. A typeface changes rendering, not meaning, ownership, classification, or searchability. A typeface is imported once into a reusable local library; it is never duplicated or locked to a single Entry.

## Proposed user flow

| Stage | User action | PASS behavior |
|---|---|---|
| **1. Create an Entry** | The user opens a new SCP or personnel Entry. | The current title, category, folder, and document fields remain unchanged. |
| **2. Choose a document block** | The user writes a normal paragraph, quotation, transcript line, or recovered-script block. | Each block can remain **Foundation Standard** or reference any typeface already in the local library. |
| **3. Import a typeface when needed** | The user taps **Import Typeface**, then chooses one `.ttf` or `.otf` file through Android’s system file picker. | PASS validates, copies, and registers the file privately on the device. The imported typeface is reusable throughout PASS. |
| **4. Read the Entry** | The user opens the Entry from its record library. | A dedicated Document Reader shows metadata in PASS styling and renders each document block in its chosen typeface. |
| **5. Export** | The user taps **Export TXT** or **Export PDF**. | PASS creates a local file and opens the Android share sheet, allowing the user to save, send, or print it. |

## What exports contain

| Export | Content | Typeface behavior |
|---|---|---|
| **TXT** | UTF-8 text with a small PASS header: record owner, Entry title, category, creation/update date, and body. | TXT deliberately has no font. It preserves the original characters for your language and keyboard app, independent of visual styling. |
| **PDF** | A document-style record with PASS classification header, entry metadata, body, and export timestamp. | PASS embeds every imported typeface referenced by its document blocks where supported, so only the relevant script or quotation uses that typeface. |

The PDF must be treated as a **best-effort visual rendering**. If a font lacks a particular glyph, no app can invent it; the rendered output may show an empty box. The TXT export remains the authoritative source text.

## Local typeface model

PASS should use a small local **Typeface Library**, not a cloud upload system.

| Rule | Reason |
|---|---|
| `.ttf` and `.otf` files are offered in the first version. | A file extension alone is not a reliable font-format decision. The supplied `enchanting-table_eb9fb153.ttf` identifies as an OpenType CFF font with family name **Enchanting Table**, so PASS must validate actual loadability rather than reject a usable font based on its label. |
| The imported typeface is copied into PASS’s private document storage. | A picker URI can be temporary, especially after an app restart. [1] [2] |
| PASS saves only local metadata: name, private URI, size, date, and generated internal family key. | The font remains local-first and never leaves the device unless the user exports/shares a document. |
| PASS attempts runtime loading before confirming the import. | A file with a `.ttf` name that cannot be registered is rejected rather than appearing as a broken choice. Expo supports runtime font loading from a URI. [3] |
| Each document block stores an optional `typefaceId`, not a duplicated font file. | Multiple Entries and multiple language passages can reuse one imported typeface without data duplication. |
| Removing a typeface never changes Entry text. | Any affected block falls back to Foundation Standard and shows that its original display typeface is unavailable. |

## Why document blocks and a reader are necessary

The existing Entry library is intentionally a compact index. It shows a title, category, date, and short excerpt. Exporting directly from that card would work technically, but it would give the user no proper place to verify a constructed script, read a long interview, or choose output format.

The supplied example also exposes a weakness in an all-document font choice: a realistic interview may contain ordinary English interviewer text and a non-English or anomalous response. Applying one font to the entire Entry would make the wrong text look anomalous.

PASS should therefore store a small sequence of **document blocks**. A block contains its Unicode text, optional speaker/label, and optional library typeface. This is not full rich text: it does not support arbitrary fonts inside every word, images, tables, or word-processor formatting. It does correctly support an English question followed by a SCP-049 response in your imported typeface.

The proposed **Document Reader** is therefore a narrow addition. It does not change folders, classification, or record ownership. It gives each Entry a controlled reading surface with actions to **Export TXT**, **Export PDF**, and adjust reusable typeface references.

## Security and preservation rules

| Protection | PASS behavior |
|---|---|
| **Source preservation** | Unicode Entry text remains in local registry storage. Font data is never used as a substitute for text. |
| **Input scope** | PASS accepts one user-selected TTF at a time; it does not fetch fonts from websites or execute third-party code. |
| **Failure handling** | Import failure leaves the current library untouched. A missing or unreadable typeface falls back to Foundation Standard. |
| **PDF safety** | Text is HTML-escaped before PDF generation. The selected font is embedded only as a local base64 resource, not loaded from a remote URL. |
| **File sharing** | Native Android export uses the system share sheet. Local `file://` paths are not treated as public links. [2] [4] |
| **Ownership** | PASS does not assess or transfer font licensing. The user should import only fonts they may use and distribute in exported documents. |

## Platform behavior

| Platform | Expected behavior |
|---|---|
| **Android — primary target** | Import TTF through the native picker, persist locally, apply it at runtime, generate TXT/PDF, and share generated files through the Android share sheet. |
| **Web preview** | The UI can be previewed, but local-file sharing is constrained by browsers. Browser printing also does not render arbitrary supplied HTML in the same way as native PDF generation. [4] [5] |
| **iOS — future compatibility** | The same local picker/storage approach is viable, but file URIs must be copied into app storage and system share behavior remains platform-specific. [1] [2] |

## Exact scope for the first implementation

The first version should include the following and no more:

| Include | Defer |
|---|---|
| SCP and Personnel Entries | Rich-text formatting, images, tables, and arbitrary font changes inside individual words |
| A local Foundation Standard fallback | Importing full keyboard layouts or language packages |
| Reusable typefaces from a local library | Online font catalogs, cloud sync, or font sharing between users |
| Text, quotation, transcript, and recovered-script blocks | Importing full keyboard layouts or language packages |
| Dedicated Document Reader | Editing an Entry after creation; this remains a separate future improvement |
| UTF-8 TXT export | DOCX or RTF export |
| Styled PDF export with an embedded selected TTF | Guaranteed identical font behavior on every external PDF viewer |

## Implementation basis

Expo’s document picker supports file selection and must be combined with local file storage when the selected URI needs to remain available after restart. [1] [2] Expo Font can register a runtime font from a URI and use its generated family key in native text rendering. [3] Expo Print can create a PDF file from HTML, and Expo Sharing can present native applications with that generated local file. [4] [5]

## Recommended approval

Approve this **document-first implementation**: a reusable local Typeface Library, block-level document rendering, an Entry Document Reader, and TXT/PDF export. It is the smallest version that makes your constructed languages feel authentic while keeping PASS an archive system rather than a general office suite.

## References

[1] [Expo DocumentPicker — persistent access and cache copying](https://docs.expo.dev/versions/latest/sdk/document-picker/)  
[2] [Expo FileSystem — local document storage and file sharing](https://docs.expo.dev/versions/latest/sdk/filesystem/)  
[3] [Expo Font — runtime font loading](https://docs.expo.dev/versions/latest/sdk/font/)  
[4] [Expo Sharing — native file sharing limitations](https://docs.expo.dev/versions/latest/sdk/sharing/)  
[5] [Expo Print — PDF generation from HTML](https://docs.expo.dev/versions/latest/sdk/print/)
