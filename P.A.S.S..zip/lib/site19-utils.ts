import { canAccessClearance } from "./registry-utils";
import type { ClearanceLevel } from "./registry-types";
import type { Site19Connector, Site19Level, Site19Sector } from "./site19-registry";

export function canAccessFacilityItem(reader: ClearanceLevel, item: Pick<Site19Level | Site19Sector | Site19Connector, "minimumClearanceLevel">) {
  return canAccessClearance(reader, item.minimumClearanceLevel);
}

export function visibleFacilitySectors(reader: ClearanceLevel, sectors: Site19Sector[]) {
  return sectors.filter((sector) => canAccessFacilityItem(reader, sector));
}

export function isSite19Address(value: string) {
  return /^S19-L[1-5]-\d{2}(?:-[A-Z])?$/.test(value);
}
