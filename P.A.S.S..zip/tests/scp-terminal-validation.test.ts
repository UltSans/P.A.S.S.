import { describe, expect, it } from "vitest";

import { terminalDocumentationError } from "../lib/scp-terminal-validation";

describe("SCP terminal escalation validation", () => {
  it("requires evidence when a new terminal designation is selected", () => {
    expect(terminalDocumentationError({ isEditing: false, selectedDesignation: "Apollyon Condition", scenario: "", rationale: "" })).toContain("rationale");
    expect(terminalDocumentationError({ isEditing: false, selectedDesignation: "K-Class Scenario", scenario: "", rationale: "" })).toContain("scenario");
  });

  it("does not block an unrelated amendment to a migrated record with an unchanged incomplete terminal designation", () => {
    expect(terminalDocumentationError({ isEditing: true, originalDesignation: "Apollyon Condition", selectedDesignation: "Apollyon Condition", scenario: "", rationale: "" })).toBeUndefined();
  });

  it("requires documentation again when a terminal designation changes", () => {
    expect(terminalDocumentationError({ isEditing: true, originalDesignation: "Apollyon Condition", selectedDesignation: "Apollyon Condition + K-Class Scenario", scenario: "", rationale: "" })).toContain("scenario");
  });
});
