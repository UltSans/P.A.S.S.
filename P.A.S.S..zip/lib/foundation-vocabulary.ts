export interface VocabularyDefinition {
  category: string;
  summary: string;
  guidance: string;
}

export const PERSONNEL_DEPARTMENT_SUGGESTIONS = [
  "Administration & Oversight",
  "Research Division",
  "Containment Operations",
  "Security & Tactical Response",
  "Medical & Psychological Services",
  "Field Operations & Investigation",
  "Records & Information Security",
  "Engineering & Technical Services",
  "Logistics, Procurement & Facilities",
  "Ethics & Compliance",
  "Occult & Specialized Studies",
  "External Relations & Liaison",
] as const;

export const PERSONNEL_POSITION_GROUPS = [
  { label: "ADMINISTRATION", options: ["Site Director", "Deputy Site Director", "Department Head", "Administrative Officer", "Executive Assistant", "Compliance Officer", "Ethics Committee Liaison"] },
  { label: "RESEARCH & CONTAINMENT", options: ["Research Assistant", "Junior Researcher", "Researcher", "Senior Researcher", "Lead Researcher", "Research Analyst", "Laboratory Technician", "Containment Specialist", "Containment Engineer", "Containment Technician", "Containment Operations Officer", "Anomalous Entity Liaison"] },
  { label: "SECURITY & RESPONSE", options: ["Security Officer", "Security Supervisor", "Tactical Response Officer", "Response Commander", "Armory Custodian", "Security Systems Analyst"] },
  { label: "MEDICAL & PSYCHOLOGICAL", options: ["Chief Medical Officer", "Physician", "Nurse", "Paramedic", "Anomalous Psychiatrist", "Psychologist", "Anomalous Pathologist", "Quarantine Officer", "Biohazard Specialist"] },
  { label: "FIELD, RECORDS & TECHNICAL", options: ["Field Agent", "Investigative Agent", "Recovery Specialist", "Tactical Forensics Lead", "Surveillance Officer", "Evidence Custodian", "Records Officer", "Archivist", "Redaction Specialist", "Document Analyst", "Information Security Analyst", "Communications Monitor", "Systems Engineer", "Paratechnology Specialist", "Facilities Technician", "Logistics Coordinator", "Procurement Officer", "Transport Officer", "Janitorial Services Officer"] },
  { label: "SPECIALIST STUDIES", options: ["Thaumaturgist", "Occult Studies Specialist", "Memetics Specialist", "Antimemetics Specialist", "Cryptozoologist", "Linguist / Translator", "Forensic Specialist", "Anomalous Materials Researcher"] },
] as const;

export const VOCABULARY_DEFINITIONS: Record<string, VocabularyDefinition> = {
  "Records & Information Security": { category: "DEPARTMENT", summary: "Controls records integrity, redaction, archival continuity, and information-security review.", guidance: "Use for staff whose primary duty is maintaining or protecting Foundation information, not for ordinary research staff who merely read restricted files." },
  "Occult & Specialized Studies": { category: "DEPARTMENT", summary: "A home for specialist disciplines that do not belong to routine laboratory, security, or medical work.", guidance: "Use when an assignment is defined by a specialist anomalous discipline such as thaumaturgy, memetics, antimemetics, cryptozoology, or anomalous linguistics." },
  "Containment Specialist": { category: "POSITION", summary: "Establishes initial containment and supports the safe management of contained anomalies.", guidance: "Use for operational containment work. It is not a synonym for researcher, security officer, or containment engineer." },
  "Containment Engineer": { category: "POSITION", summary: "Designs, refines, and maintains containment systems, chambers, and technical safeguards.", guidance: "Use for the engineering role behind a containment solution; use Containment Specialist for the operational team role." },
  "Anomalous Entity Liaison": { category: "POSITION", summary: "Maintains structured communication with a sapient or cooperative anomalous entity.", guidance: "Use only when relationship management is the person’s assigned duty. It does not grant unrestricted contact or change the entity’s containment status." },
  "Tactical Response Officer": { category: "POSITION", summary: "Provides trained response capability during dangerous anomaly or hostile-action events.", guidance: "Use for a tactical operational role. It does not automatically make a person an MTF operative or Team commander." },
  "Tactical Forensics Lead": { category: "POSITION", summary: "Leads the collection and analysis of operational evidence after an event or recovery.", guidance: "Use for evidence-led investigation work, not for general security supervision." },
  "Anomalous Psychiatrist": { category: "POSITION", summary: "Provides psychiatric assessment and care where anomalous exposure or behavior is relevant.", guidance: "Use for a medical-psychological specialty. It does not replace a quarantine decision or formal security restriction." },
  "Anomalous Pathologist": { category: "POSITION", summary: "Examines biological or post-mortem material where anomalous factors may be involved.", guidance: "Use for pathological analysis; use Biohazard Specialist for containment and safety management of hazardous biological material." },
  "Paratechnology Specialist": { category: "POSITION", summary: "Maintains, evaluates, or adapts technology with anomalous or non-standard operating principles.", guidance: "Use when technical work concerns paratechnology specifically. Use Systems Engineer for conventional or facility systems work." },
  Thaumaturgist: { category: "POSITION", summary: "Studies or applies ritual, occult, or structured magical practices in a controlled Foundation role.", guidance: "Use only when that specialist discipline is part of the assignment. A person interested in occult material is not automatically a thaumaturgist." },
  "Memetics Specialist": { category: "POSITION", summary: "Studies information patterns that can affect thought, behavior, or perception when encountered.", guidance: "Use for active memetic research, screening, or containment work. It is not a generic communications role." },
  "Antimemetics Specialist": { category: "POSITION", summary: "Works with information that resists noticing, recording, remembering, or communicating.", guidance: "Use only for a dedicated antimemetic assignment; it is distinct from ordinary records or information-security work." },
  "Acquisition / Recovery Report": { category: "SCP ENTRY", summary: "Records how an anomaly or related material entered Foundation custody or awareness.", guidance: "Use this for origin, creator, supplier, recovery location, seizure, handover, or chain-of-custody narrative. Do not add new SCP fields when the full provenance belongs in the document." },
  "Initial Containment Report": { category: "SCP ENTRY", summary: "Records the first stabilization and early containment decisions after discovery or recovery.", guidance: "Use before later containment logs when the first response needs its own auditable account." },
  "Testing Log": { category: "SCP ENTRY", summary: "Records a controlled trial, experiment, or test involving the anomaly.", guidance: "State authorization, conditions, observations, and outcome in the document. Use Research Log for broader ongoing research notes." },
  "Analysis Report": { category: "SCP ENTRY", summary: "Records a focused technical, material, forensic, medical, or anomalous analysis.", guidance: "Use when the document’s purpose is an assessment rather than a test timeline or a routine observation." },
  "Procedure Revision": { category: "SCP ENTRY", summary: "Explains a change to containment procedures without changing the PASS classification itself.", guidance: "Use this when operational instructions change. Use Reclassification only when a classification decision changes." },
  "Transfer / Custody Record": { category: "SCP ENTRY", summary: "Records a handover, movement, storage transfer, or formal change in custody.", guidance: "Use for the chain of responsibility. It does not replace the SCP file’s current custody classification." },
  "Recovered Document": { category: "SCP ENTRY", summary: "Stores a document recovered with, produced by, or materially connected to the anomaly.", guidance: "Preserve the document’s original voice in blocks where appropriate, and use the title to identify its source or context." },
  "External Correspondence": { category: "SCP ENTRY", summary: "Stores a controlled message, letter, report, or contact originating outside the Foundation.", guidance: "Use for an outside party’s communication. The document itself should state the source and the degree of confidence in it." },
  "Termination / Neutralization Record": { category: "SCP ENTRY", summary: "Records a documented final state or termination-related decision for an anomaly.", guidance: "Use only when the record establishes a final operational outcome. It does not by itself change the SCP lifecycle classification." },
  "Training & Certification": { category: "PERSONNEL ENTRY", summary: "Records training completion, qualification, renewal, or certification failure.", guidance: "Use for evidence of readiness or authorization to perform a duty; do not use it as a substitute for keycard access." },
  "Security Review": { category: "PERSONNEL ENTRY", summary: "Records a review of security suitability, access posture, compromise concerns, or restrictions.", guidance: "Use when the record is about security assessment. Use Access Amendment when an access value itself changes." },
  "Psychological Evaluation": { category: "PERSONNEL ENTRY", summary: "Records a psychological assessment or fitness-for-duty review.", guidance: "Use for professional evaluation. Use Medical / Quarantine when the operational status is exposure, treatment, or quarantine." },
  "Incident Involvement": { category: "PERSONNEL ENTRY", summary: "Records a person’s factual role, follow-up, or consequence arising from an incident.", guidance: "Use alongside a linked Incident Report when one exists; it documents the personnel history without turning the person into the incident itself." },
  "Leave / Restricted Duty": { category: "PERSONNEL ENTRY", summary: "Records a temporary limitation, leave period, or duty restriction without changing the person’s baseline clearance.", guidance: "Use for time-bound work status. Use Disciplinary for a formal disciplinary matter and Medical / Quarantine for medical exposure status." },
  "External Liaison Note": { category: "PERSONNEL ENTRY", summary: "Records controlled contact or liaison work involving an outside organization, agency, or individual.", guidance: "State the contact, purpose, and outcome in the document. It does not create a permanent affiliation field or change clearance." },
  Advisory: { category: "INCIDENT SEVERITY", summary: "A limited event requiring local attention but not a sustained command response.", guidance: "Use when the condition is contained or manageable with routine local resources and there is no major operational disruption." },
  Significant: { category: "INCIDENT SEVERITY", summary: "A material event requiring coordinated site response and documented follow-up.", guidance: "Use when operations, personnel, systems, or containment require more than routine local handling, but site-wide continuity remains intact." },
  Major: { category: "INCIDENT SEVERITY", summary: "A serious event that materially disrupts a site function, containment program, or protected operation.", guidance: "Use when command coordination, substantial resources, or multi-team action is required. It does not automatically mean a terminal escalation." },
  Critical: { category: "INCIDENT SEVERITY", summary: "An immediate severe threat to life, containment integrity, site continuity, or protected information.", guidance: "Use for events demanding urgent command action and sustained senior oversight. Record known uncertainty instead of inflating severity." },
};

export function vocabularyDefinition(term: string | null | undefined) {
  return term ? VOCABULARY_DEFINITIONS[term] : undefined;
}
