# PASS Classification Framework v1.0 — Proposal

## Purpose

PASS needs a **stable internal classification standard**. It should be informed by SCP Wiki terminology, but it must not silently change every time a wiki component, guide, or author convention changes. Each SCP file would record the framework version used—beginning with **PASS Classification Framework v1.0**—so that older files remain intelligible even if the framework grows later.

The framework does not claim to replace the SCP Wiki’s many canons. It gives this project one coherent, documented operational language for the database.

> **Core rule:** a label is only useful if it answers one defined operational question. PASS will not force unrelated ideas into the same class slot.

## The five-part record

| Field | Required? | The question it answers |
|---|---:|---|
| **Containment Designation** | Yes | What is the Foundation’s realistic relationship to containing or managing this anomaly? |
| **Secondary Operational Class** | Optional; one only | Does the anomaly have one additional strategic role or exceptional operating condition? |
| **Disruption Class** | Yes | If control fails, how far could normal society or the Veil be disrupted? |
| **Risk Class** | Yes | How harmful and recoverable are the anomaly’s effects on directly affected individuals? |
| **Status & Escalation** | Yes | What is the current condition, and what change requires emergency reclassification or response? |

This keeps containment, utility, societal impact, individual harm, and current condition from being conflated.

## 1. Containment Designation

PASS places all containment-relation terms here, including Ticonderoga. This is the deliberate project convention: the field answers **how the Foundation can realistically manage the anomaly**, not whether a current web component places an icon in a particular slot.

| Group | Designation | PASS meaning |
|---|---|---|
| **Routine** | Safe | Procedures are reliable and routine. |
|  | Euclid | Reliable containment requires active resources, research, or management of unpredictable behavior. |
|  | Keter | Consistent containment is exceptionally difficult, costly, or unreliable. |
| **Disposition** | Pending | Evidence is insufficient for a stable designation. |
|  | Neutralized | Anomalous properties have ceased. |
|  | Explained | The apparent anomaly has a complete non-anomalous explanation. |
|  | Decommissioned | The Foundation has formally ended the anomaly’s active designation or containment program. |
| **Non-physical / special** | **Ticonderoga** | The anomaly cannot realistically be physically contained and does not require ordinary physical containment. Its management method must be documented. |
|  | Archon | Containment is technically possible but should not be imposed because doing so creates worse outcomes. |
|  | Cernunnos | Containment is technically possible, but it is not justified under the documented logistical, ethical, or operational balance. |
|  | Uncontained | Control has not been established or has been lost; this is normally temporary. |
|  | Custom Designation | A defined file-specific containment relationship not represented above. |

Every non-routine designation must include a mandatory **Containment Method** field. The available methods are: physical containment, negotiated/cooperative containment, remote observation, external custody, non-interference management, or custom documented method.

## 2. Secondary Operational Class

Only **one** Secondary Operational Class may be active on a file. It exists to express one special operational fact beyond the containment relationship.

| Designation | PASS meaning |
|---|---|
| None | No secondary class is necessary. |
| Thaumiel | The anomaly is an approved asset for designated containment, support, or protection work. Use must have explicit authorization conditions. |
| Argus | A trusted external organization is the responsible custodian. |
| Apollyon | The anomaly presents an uncontainable, terminal-scale outcome requiring permanent executive treatment. |
| Tiamat | Effective response requires overt, Veil-breaking action. |
| Hiemal | A specialist class with a documented, complex containment rationale; it cannot be selected without a record-specific explanation. |
| Custom Operational Class | A single defined special role not represented above. |

Specialist terms such as Hiemal are not treated as decorative labels. Their definition, source inspiration, application criteria, and approval note must be present in the file.

## 3. Disruption and Risk

PASS retains the standard five-step ACS scales because they answer clear and separate questions.

| Dimension | Values | Rule |
|---|---|---|
| **Disruption** | Dark, Vlam, Keneq, Ekhi, Amida, Custom | Assess plausible uncontrolled impact on the Veil and normal society—not only the subject’s usual cooperative behavior. |
| **Risk** | Notice, Caution, Warning, Danger, Critical, Custom | Assess severity and recoverability of direct effects—not difficulty of containment. |

Custom values are allowed in both dimensions. They require a name, concise definition, operational use criteria, and a rationale for why the core scale is inadequate.

## 4. Status and escalation

Status must never be hidden inside a class. PASS therefore stores it separately.

| Status | Meaning |
|---|---|
| Managed | The current approved containment method is functioning. |
| Under Review | The record is being reassessed because evidence or conditions changed. |
| Restricted | Access or operations are temporarily reduced. |
| Breach / Active Incident | The approved containment method has failed or an emergency condition is active. |
| Neutralized / Closed | The anomaly is no longer active under the applicable record rules. |

Every SCP can also define an **Escalation Condition**. This permits a baseline classification and a documented emergency state without falsifying either one.

## 5. Custom values in every dimension

PASS will not make Custom available only under Secondary Class. A user may create a custom value for **Containment, Secondary Operational, Disruption, Risk, or Status**, but every custom value must contain:

| Required metadata | Why it exists |
|---|---|
| Display name | Prevents anonymous or unexplained labels. |
| Defined meaning | States the operational question the class answers. |
| Appropriate-use criteria | Prevents labels from becoming aesthetic decorations. |
| Rationale on this file | Explains why the core options do not fit. |
| Approval / author note | Records who established the designation. |
| Framework version | Preserves the record’s meaning when PASS evolves. |

## 6. Classification Registry

The project should not hard-code every esoteric label as a button. The wiki’s own resource describes many such classes as rare and highly specialized. Instead, PASS should maintain a **Classification Registry** with three levels:

| Registry level | Purpose |
|---|---|
| **PASS Core** | The stable options listed in this framework. These appear by default in the editor. |
| **PASS Specialist** | Researched classes that have full definitions and a chosen PASS field. They can be enabled when needed. |
| **File Custom** | A record-specific designation created with the required metadata above. |

This approach keeps the app usable while allowing the database to grow toward full coverage of specialist terminology without pretending that every rare class belongs in every SCP form.

## 7. The SCP-9743-1 solution

Under PASS Classification Framework v1.0, the user’s intended pair is coherent without giving the file two secondary classes:

| SCP-9743-1 field | PASS v1.0 value | Why it belongs there |
|---|---|---|
| **Containment Designation** | Ticonderoga | The story establishes that ordinary physical containment is not a realistic solution and may actively worsen risk. |
| **Containment Method** | Negotiated/cooperative containment | The procedures rely on social, emotional, psychological, and consent-based management rather than a cell. |
| **Secondary Operational Class** | Thaumiel | The anomaly has documented potential for authorized containment support, medical support, and neutralization work. |
| **Status** | Managed / Under Review | The Foundation is still learning the subject’s states and the Hatred manifestation requires ongoing reassessment. |
| **Escalation Condition** | Hatred manifestation or destabilization indicators | Allows emergency risk/disruption treatment to be documented separately from baseline cooperation. |

This gives **Ticonderoga** its proper containment role in *your* framework and preserves **Thaumiel** as the one Secondary Operational Class. No double-secondary workaround is required.

## Decision requested

Approve, reject, or revise the following principle:

> **PASS Classification Framework v1.0 will use Ticonderoga as a Containment Designation, Thaumiel as a single Secondary Operational Class, and a documented custom route in every classification dimension.**

No application field will be changed until you approve the framework.

## References

[1] [SCP Wiki — Object Classes](https://scp-wiki.wikidot.com/object-classes)  
[2] [SCP Wiki — Anomaly Classification System Guide](https://scp-wiki.wikidot.com/anomaly-classification-system-guide)  
[3] [SCP Wiki — Anomaly Classification Bar for ACS](https://scp-wiki.wikidot.com/component:anomaly-class-bar)  
[4] [SCP Wiki — Customizable ACS Add-On Guide](https://scp-wiki.wikidot.com/component:customizable-acs-guide)  
[5] [SCP Wiki — A Comprehensive List of Esoteric Classes](https://scp-wiki.wikidot.com/esoteric-classes-complete-list)  
[6] [SCP Wiki — The Origin of Object Classes](https://scp-wiki.wikidot.com/a-history-of-object-classes)
