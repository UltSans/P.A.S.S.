# PASS / Site-19 — Level 2 Administration Operating Model

## Status

**Discussion draft only.** This document defines why each proposed Level 2 function exists and how it relates to the rest of Site-19. It does **not** assign sector codes, elevator designations, corridor layouts, or app data yet.

## Level purpose

> **Level 2 is Site-19’s controlled administrative core.** It operates the site as an institution: leadership, personnel administration, records, routine staff health, briefings, security authorization, and controlled transition to deeper operational zones.

It is intentionally a **low-anomaly-contact level**. Personnel who run the site but do not need routine containment access should be able to work here without passing through the LCZ. It is not a public area, and it is not simply an office floor: every sensitive function has its own privacy, access, and traffic boundary.

## Proposed functional sectors

| Proposed sector | Operational purpose | Primary users | Why it belongs on L2 | Boundary that keeps it realistic |
|---|---|---|---|---|
| **Command & Site Coordination** | Direct the site, coordinate departments, hold restricted planning meetings, and maintain a protected incident-coordination capability. | Site Director, department heads, designated incident authorities, and approved security liaison staff. | Leadership needs central access to information and staff without being placed inside a containment zone. | It coordinates an incident but is not a tactical-response staging area and does not need open access to L4. The deputy or duty-officer structure remains intentionally undefined until it is chosen. |
| **Personnel Administration & Credentialing** | Maintain personnel files, employment status, posting, clearance administration, and controlled credential issue/review. | Personnel administrators, security-cleared credential staff, authorized supervisors. | These are institution-wide functions that need separation from public L1 intake and from containment shift traffic. | Personnel records and credential work are private; ordinary L2 staff do not automatically obtain access to them. |
| **Records & Database Operations** | Run controlled registry access, document routing, redaction review, records retention, and the physical/administrative side of PASS-style database work. | Records officers, authorized administrative staff, document-control personnel. | It supports every department but should not be embedded inside either a research wing or deep archive vault. | Reading a record here does not grant physical archive, storage, research, or containment access. |
| **Primary Medical Bay** | Provide comprehensive physical medicine, mental-health and psychological care, diagnostics, treatment, rehabilitation, routine occupational health, short observation, and controlled transfer. | Medical, mental-health, and psychological staff; employees; escorted patients. | It serves the largest daily staff population before personnel enter deeper operational levels and allows ordinary healthcare to remain outside containment zones. | It does not receive unknown active anomalous contamination through normal office traffic. L3 and L4 retain controlled isolation, stabilization, and transfer points for high-risk exposures. |
| **Briefing, Policy & Assignment Preparation** | Conduct induction administration, pre-shift briefings, procedural refreshers, controlled meetings, and post-incident administrative debriefs for already-qualified personnel. | Assigned personnel, supervisors, policy staff, and approved visitors. | It allows staff to be briefed and cleared before they enter L3/L4, instead of turning operational corridors into meeting spaces. | It is not a weapons range, drill floor, or recruit-training space. Security training occurs at a separate Foundation-controlled external academy, range, or secure annex. |
| **Security Administration** | Manage authorization records, access changes, internal security coordination, guard assignments, and administrative incident intake. | Security administration, credential officers, duty security coordinators. | It needs proximity to leadership and personnel records but is distinct from physical perimeter security on L1 and tactical response on L4. | Administrative security work does not create a direct or casual route to HCZ operations. |
| **Controlled Staff Access Hub** | Form the secure transition between screened arrival and the site’s internal work areas; direct cleared staff to administrative work, briefings, or approved lower-level routes. | Cleared staff, escorted visitors, access-control personnel. | Without this hub, every L2 office or lower-level lift would have to perform separate entry screening. | It is a regulated checkpoint and circulation node, not a public lobby and not a direct open descent into LCZ. |
| **Administrative Support & Communications** | Provide secure internal communications support, scheduling, office services, and controlled administrative supplies. | Approved administrative support staff. | These services make the command and records functions workable without creating unnecessary trips to L1 or L3. | This is not a warehouse, server vault, or general cafeteria; bulk logistics remain tied to L1/L3/L5 functions. |

## Working relationships

The level should behave as a system rather than a list of rooms. A staff member who arrives for ordinary administrative work follows a screened L1 arrival path into the **Controlled Staff Access Hub**, then proceeds only to the relevant L2 sector. A containment employee can complete briefing or routine medical clearance on L2 before taking an approved personnel route to L3. Their work route should not pass through the Site Director’s suite, private personnel records, or the primary medical bay.

Information moves differently from people. Administrative teams can route records, authorizations, and schedules through the **Records & Database Operations**, **Personnel Administration & Credentialing**, and **Security Administration** sectors without that paper or database authority becoming physical authority to enter containment, storage, or protected archives.

Medical movement has its own rule. Routine physical medicine, mental healthcare, psychological care, diagnostics, treatment, and rehabilitation belong in the **Primary Medical Bay**; a contamination, unknown anomalous exposure, or high-risk casualty is stabilized through the relevant controlled L3/L4 response point and transferred under medical/security control. This prevents unsafe movement through normal office traffic while preserving a broad, capable L2 medical department.

## What Level 2 deliberately does not contain

Level 2 should not contain D-Class custody, ordinary SCP testing, containment suites, a general cafeteria, tactical response staging, bulk freight storage, deep archive vaults, heavy decontamination, or security recruit drills. Those functions either require direct proximity to containment and shift work, an external training environment, or more restrictive low-traffic infrastructure on other levels.

## Review questions

1. The deputy or duty-officer arrangement is **intentionally unresolved** until you decide whether Site-19 needs named leadership roles beyond the Site Director.
2. The Primary Medical Bay is approved as a broad physical, mental-health, and psychological care department, while controlled L3/L4 transfer points retain responsibility for active high-risk exposure isolation.
3. Security recruitment and drills occur at a separate Foundation-controlled external academy, range, or secure annex. L2 retains only briefing, policy, and assignment preparation for already-qualified personnel.
