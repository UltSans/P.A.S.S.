import { describe, expect, it } from "vitest";

import { PERSONNEL_DEPARTMENT_SUGGESTIONS, PERSONNEL_POSITION_GROUPS, vocabularyDefinition } from "../lib/foundation-vocabulary";
import { PERSONNEL_ENTRY_CATEGORIES, SCP_ENTRY_CATEGORIES } from "../lib/registry-types";

describe("Foundation vocabulary extension", () => {
  it("keeps Personnel suggestions editable vocabulary rather than clearance or class values", () => {
    expect(PERSONNEL_DEPARTMENT_SUGGESTIONS).toContain("Medical & Psychological Services");
    expect(PERSONNEL_POSITION_GROUPS.flatMap((group) => group.options)).toContain("Paratechnology Specialist");
    expect(PERSONNEL_POSITION_GROUPS.flatMap((group) => group.options)).not.toContain("Level 3");
  });

  it("expands the existing SCP and Personnel Entry category lists without removing legacy categories", () => {
    expect(SCP_ENTRY_CATEGORIES).toEqual(expect.arrayContaining(["Administrative", "Acquisition / Recovery Report", "Procedure Revision", "Recovered Document"]));
    expect(PERSONNEL_ENTRY_CATEGORIES).toEqual(expect.arrayContaining(["Administrative", "Training & Certification", "Incident Involvement", "External Liaison Note"]));
  });

  it("provides operational help only for specialist terms that need it", () => {
    expect(vocabularyDefinition("Thaumaturgist")?.category).toBe("POSITION");
    expect(vocabularyDefinition("Acquisition / Recovery Report")?.category).toBe("SCP ENTRY");
    expect(vocabularyDefinition("Researcher")).toBeUndefined();
  });
});
