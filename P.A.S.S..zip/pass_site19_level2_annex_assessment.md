# PASS / Site-19 — Level 2 Applied Anomalies Annex Assessment

## Decision standard

An SCP belongs in Level 2 only if its work can occur in a **small, separately secured applied-anomalies annex** without forcing D-Class custody, general containment traffic, uncontrolled clinical exposure, or routine staff amenities into the administrative/clinical core. A familiar object does not qualify merely because it is useful.

| Candidate | Proposed purpose | Decision | Reasoned placement |
|---|---|---|---|
| **SCP-914** | Supervised junior-research familiarisation; approved senior material testing. | **Accept with conditions.** | A purpose-built L2 Applied Engineering Cell is defensible if it is an enclosed annex with its own guard post, heavy gate, output vestibule, and dedicated materials lift. Its L2 work is non-biological, non-custodial material/process testing and supervised observation. D-Class/living-subject work and routine LCZ material intake remain L3 functions. |
| **SCP-500** | Clinical emergency cure. | **Accept as split custody, not as normal L2 storage.** | Main stock belongs in L5 Medical-Anomalous Custody because it is rare and high-authority. L2 Clinical Services can hold a single sealed emergency dose cache only if Site Command, Clinical Services, and custody authority jointly define release conditions, dual control, reconciliation, and replacement. This gives the medical department a time-critical option without turning a scarce asset into a director-only cabinet. |
| **SCP-294** | Approved research liquid requests; controlled familiarisation. | **Accept with conditions.** | It can occupy an L2 Supervised Liquid Interface Cell because the primary procedure already permits Level 2+ use under continuous Level 3 guard coverage. It must have a request register, an approved-request protocol, an output examination point, and no open staff access. Junior researchers may observe or assist only under a named senior researcher; it is not a break-room perk. |
| **SCP-261** | Controlled anomaly acquisition and research. | **Accept with conditions.** | It fits an L2 Acquisitions Test Cell only as scheduled output generation: each run is approved, logged, health-and-safety screened, and routed to a sealed evidence/containment handoff. It is not a cafeteria vending machine. The cell needs a secure output vestibule because its products can be dangerous, anomalous, or non-consumable. |
| **SCP-207** | Emergency speed/stamina use during a breach. | **Reject.** | The primary procedure requires bio-containment storage, tightly limited supervised doses, and identifies severe injury/death risk. Its game speed effect is not a defensible emergency-use doctrine. If held at Site-19, it belongs in biological research/clinical study containment, not a Level 2 emergency kit. |
| **SCP-207-JP** | “Anti-Cola.” | **Reject the identification.** | SCP-207-JP is a book-generating bookcase, not Anti-Cola. If it were present, a limited L2 document-generation study cell could be considered separately. It cannot be renamed or reclassified as an emergency beverage. |
| **Anti-Cola / O-207-914** | Emergency resistance/evacuation aid. | **Defer pending PASS-local provenance.** | This is a Secret Laboratory derived game item, not SCP-207-JP. PASS may create a local derivative designation later, but only with its own creation record, derived-from link, PASS classification, clinical trial evidence, storage rules, and release authority. Until then it is not part of Site-19. |
| **SCP-268** | Researcher escape asset during a breach. | **Reject.** | The primary article records escape-facilitation risk, persistent effects, observation/memory failure, a security breach, and the object’s loss. It cannot be a Level 2 escape cabinet. If later recovered for local fiction, it belongs in L5 restricted-item custody and may be issued only by an exceptional field-operation authority. |

## What the annex actually is

The proposed **Level 2 Controlled Applied Anomalies Annex** is not a set of convenient SCPs beside administration. It is a narrow research-and-clinical support enclave adjacent to the Level 2 controlled staff core, isolated by a heavy gate and staffed whenever a cell is active.

| Cell or support space | Function | Required boundary |
|---|---|---|
| **Applied Engineering Cell** | SCP-914 non-biological materials/process work and supervised observation. | Heavy gate, guard post, input/output separation, materials lift. |
| **Supervised Liquid Interface Cell** | SCP-294 authorized requests and output inspection. | Guarded operator point, request record, secured output bench. |
| **Acquisitions Test Cell** | SCP-261 scheduled transactions and controlled output capture. | Health-and-safety review point and sealed handoff to evidence/containment routing. |
| **Clinical Emergency Cache** | A possible single SCP-500 emergency dose under dual control. | Tamper-evident vault, clinical authorization, immediate record reconciliation. |
| **Annex control point** | Confirms personnel authorization, active work order, and cell status before access. | The only routine entrance; no through-route to offices or medical public circulation. |

## What is deliberately excluded

The annex has **no** open cafeteria use, unlogged staff experimentation, D-Class housing or routine testing traffic, standard clinical waiting area, emergency stimulant kit, general security equipment issue, or escape-artifact cabinet. Those would destroy the point of Level 2 as a controlled administrative and clinical core.

## Decisions for discussion

The practical question is not whether all seven assets must be forced into Level 2. The defensible initial set is **SCP-914, SCP-294, SCP-261, and an L2 emergency cache for SCP-500**, subject to the boundaries above. SCP-207 and SCP-268 are rejected for the roles proposed. SCP-207-JP is a separate bookshelf object; Anti-Cola remains a future PASS-local derived-asset decision, not a current canonical placement.

## References

[1] [SCP-914](https://scp-wiki.wikidot.com/scp-914)  
[2] [Experiment Log 914](https://scp-wiki.wikidot.com/experiment-log-914)  
[3] [SCP-500](https://scp-wiki.wikidot.com/scp-500)  
[4] [SCP-294](https://scp-wiki.wikidot.com/scp-294)  
[5] [SCP-261](https://scp-wiki.wikidot.com/scp-261)  
[6] [SCP-207](https://scp-wiki.wikidot.com/scp-207)  
[7] [SCP-268](https://scp-wiki.wikidot.com/scp-268)  
[8] [SCP-207-JP](http://scp-jp.wikidot.com/scp-207-jp)  
[9] [Anti-Cola — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php?title=Anti-Cola)
