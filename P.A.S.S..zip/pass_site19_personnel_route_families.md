# PASS / Site-19 Personnel Route Families

## The rule

Personnel move through Site-19 because of **current duty and assignment**, not merely because of title or clearance. A researcher is not automatically allowed into every research division; a senior administrator is not automatically permitted in heavy containment; and an MTF operative does not automatically have every gate open.

| Attribute | What it determines | What it does not determine alone |
|---|---|---|
| **Role family** | The person’s normal route and work environment. | Every division they may enter. |
| **Rank/position** | Scope of supervision, approval, and responsibility inside a role family. | Automatic physical access across the site. |
| **Personnel class** | Exposure/protection policy and operational status. | Job title, rank, or normal division. |
| **Information clearance** | The highest information scope for which a person may be considered. | A physical door opening by itself. |
| **Division/zone assignment** | The routine areas a person is expected to work in. | Exceptional compartments or other assignments. |
| **Special permission** | A narrow project, system, medical, incident, or compartment exception. | Permanent unrestricted access. |

## Route families

| Family | Typical positions included | Normal work environment | Why it is a distinct movement family |
|---|---|---|---|
| **Administration & Site Leadership** | Site Director, deputy/duty authority if appointed, department heads, managers, administrative officers, scheduling and records staff. | L2 command, administration, credentials, and records divisions. | They must direct and document the site without becoming routine traffic in containment operations. |
| **Research & Analysis** | Junior, standard, senior, and lead researchers; analysts; interview specialists; approved technical investigators. | L2 controlled work areas and assigned L3/L4 research divisions. | Their route expands by current assignment and work order, not automatically with seniority. |
| **Clinical & Behavioural Services** | Physicians, nurses, diagnosticians, pharmacists, psychiatrists, psychologists, rehabilitation and occupational-health staff. | L2 Clinical Services, with protected transfers to L3/L4 interfaces as assigned. | Clinical staff require a protected patient route that is different from research, office, or response traffic. |
| **Containment Operations** | Containment officers, chamber/service operators, control technicians, escorted operational specialists. | Assigned L3 or L4 containment divisions and service interfaces. | Their normal work is inside operational containment environments, but each assignment remains compartmented. |
| **Security & Access Control** | Perimeter guards, gate officers, internal security, custody escorts, armory/control personnel. | L1 boundary divisions, L2 operations control, assigned L3/L4 checkpoints and response posts. | Security is distributed along boundaries; a guard’s post defines their route more than their generic title does. |
| **MTF & Specialist Response** | MTF operators, tactical medics, specialist response teams, recovery or hazardous-environment personnel. | L1 air/secure handoff, designated response staging, and incident-specific L3/L4 routes. | They are deployment/incident personnel, not routine residents of every containment division. |
| **Logistics, Maintenance & Technical Services** | Freight controllers, stores staff, engineers, electricians, systems technicians, utility and maintenance teams. | L1 freight/infrastructure, L3 materials intake, L5 storage/utility reserve, and assigned service spines. | Their work must use freight/service paths without giving them ordinary operational or custody circulation. |
| **Sanitation, Food & Shift Support** | Janitorial staff, laundry/sanitation workers, catering/food service, changing/rest-area and local supply support. | L3 Shift Support and defined service routes; limited L2/L4 work orders as needed. | They keep the site functioning but require work-order-controlled entry into sensitive areas. |
| **Custody Population** | D-Class personnel and other controlled human transfers. | L1 custody port, dedicated custody core, L3 custody processing/housing/staging, escorted approved destinations. | Their entire route is intentionally separated from staff arrival, ordinary freight, and administrative movement. |

## What the family model does not do

The family model does not replace the PASS keycard. It sets a person’s **default route**, while the keycard and assignment determine which exact division/zone they may enter.

> A junior researcher may have an L3 research assignment and no L4 access. A senior researcher may supervise an L4 project but still lack access to unrelated L4 divisions. A janitor may enter a sensitive division only with a work order, escort condition, and defined service route. A Level 5 reader in PASS can read protected database records but is not automatically a fictional employee with every physical gate grant.

This lets REF-05 explain why people move the way they do without pretending that every job title grants the same path through Site-19.
