import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import * as SystemUI from "expo-system-ui";
import { View } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { RegistryProvider } from "@/lib/registry-store";
import { SessionProvider } from "@/lib/session-store";
import { ThemeProvider } from "@/lib/theme-provider";

void SystemUI.setBackgroundColorAsync("#0D1113");

export default function RootLayout() {
  return (
    <SafeAreaProvider style={{ flex: 1, backgroundColor: "#0D1113" }}>
      <ThemeProvider>
        <SessionProvider>
          <RegistryProvider>
            <View style={{ flex: 1, backgroundColor: "#0D1113" }}>
              <StatusBar style="light" backgroundColor="#0D1113" />
              <Stack screenOptions={{ headerShown: false, animation: "fade", contentStyle: { backgroundColor: "#0D1113" } }}>
                <Stack.Screen name="index" />
                <Stack.Screen name="(tabs)" />
                <Stack.Screen name="compose" options={{ presentation: "modal" }} />
                <Stack.Screen name="guide" options={{ presentation: "modal" }} />
                <Stack.Screen name="personnel-reference" options={{ presentation: "modal" }} />
                <Stack.Screen name="classification-guide" options={{ presentation: "modal" }} />
                <Stack.Screen name="database" options={{ presentation: "modal" }} />
                <Stack.Screen name="database-access" options={{ presentation: "modal" }} />
                <Stack.Screen name="database-archive" options={{ presentation: "modal" }} />
                <Stack.Screen name="facility-records" options={{ presentation: "modal" }} />
                <Stack.Screen name="script-library" options={{ presentation: "modal" }} />
                <Stack.Screen name="projects" options={{ presentation: "modal" }} />
                <Stack.Screen name="project-compose" options={{ presentation: "modal" }} />
                <Stack.Screen name="incidents" options={{ presentation: "modal" }} />
                <Stack.Screen name="incident-compose" options={{ presentation: "modal" }} />
                <Stack.Screen name="incident/[id]" />
                <Stack.Screen name="scp/[id]" />
                <Stack.Screen name="personnel/[id]" />
                <Stack.Screen name="project/[id]" />
                <Stack.Screen name="personnel-entry" options={{ presentation: "modal" }} />
                <Stack.Screen name="scp-entry" options={{ presentation: "modal" }} />
                <Stack.Screen name="entry-folder" options={{ presentation: "modal" }} />
                <Stack.Screen name="entry-document" options={{ presentation: "modal" }} />
                <Stack.Screen name="teams/[id]" />
              </Stack>
            </View>
          </RegistryProvider>
        </SessionProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
