import type { ClearanceLevel, ProjectRecord } from "./registry-types";
import { canAccessClearance } from "./registry-utils";

export function uniqueRecordIds(ids: string[]) {
  return Array.from(new Set(ids.filter(Boolean)));
}

export function normalizeProjectLinks(project: Pick<Partial<ProjectRecord>, "scpIds" | "personnelIds" | "teamIds">) {
  return { scpIds: uniqueRecordIds(project.scpIds ?? []), personnelIds: uniqueRecordIds(project.personnelIds ?? []), teamIds: uniqueRecordIds(project.teamIds ?? []) };
}

export function canAccessProject(readerClearance: ClearanceLevel, projectClearance: ClearanceLevel) {
  return canAccessClearance(readerClearance, projectClearance);
}

export function projectLinkCount(project: { scpIds: string[]; personnelIds: string[]; teamIds: string[] }) {
  return project.scpIds.length + project.personnelIds.length + project.teamIds.length;
}
