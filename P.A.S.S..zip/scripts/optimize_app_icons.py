from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1]
source = root / "assets/images/icon.png"
targets = [
    root / "assets/images/icon.png",
    root / "assets/images/splash-icon.png",
    root / "assets/images/favicon.png",
    root / "assets/images/android-icon-foreground.png",
]

with Image.open(source) as image:
    optimized = image.convert("RGB").resize((768, 768), Image.Resampling.LANCZOS)
    optimized = optimized.quantize(colors=192, method=Image.Quantize.MEDIANCUT)
    for target in targets:
        optimized.save(target, format="PNG", optimize=True, compress_level=9)
