# PASS Classification Framework — Research Basis

## What the source material establishes

The SCP Wiki’s classification vocabulary is not a single fixed taxonomy. The history resource records that object-class naming evolved from early hazardous-object labels and changed as the collaborative writing community developed. The ACS guide and component bar later added independent clearance, containment, secondary, disruption, and risk fields. The current standard component constrains its default containment choices, while its customization add-on explicitly supports custom containment, disruption, and risk classes.

The official Classification Committee Memo provides the clearest operational separation: **Containment Class** identifies the challenge of containment rather than an intrinsic feature of the anomaly; **Disruption Class** communicates potential public or Veil disruption if control fails; **Risk Class** communicates immediate danger to personnel; and **Secondary Class** is an auxiliary classification for additional special cases. The memo calls Esoteric a catch-all when additional containment specifications are required. This supports PASS separating containment relationship, secondary operational role, disruption, and individual harm rather than collapsing them into a single label.

The full Object Classes guide now gives the project a defensible functional map. It defines Safe, Euclid, and Keter by containment difficulty; Pending as research incomplete; Neutralized, Explained, and Decommissioned as disposition outcomes; Apollyon as uncontainable terminal-scale failure; Archon as containment possible but harmful to impose; Argus as trusted third-party custody; Cernunnos as containment possible but not justified by the logistical or ethical balance; Ticonderoga as not containable but not requiring containment; and Uncontained as a current failure or absence of containment. It also states directly that object classes measure containment difficulty, not danger.

The ACS guide defines Disruption by spread, scale, and ease of neutralizing public/Veil effects, from Dark through Amida; Risk by individual severity and recoverability, from Notice through Critical; and Secondary Class as optional. It confirms that a standard component can display an Esoteric containment class with a secondary class, but also states that this formatting convention is not a mandatory rule. The official customizable ACS component supports custom containment, disruption, and risk classes. Finally, the comprehensive esoteric list describes such terms as rare and often unsuitable as standard documentation defaults, reinforcing the need for a curated PASS Core plus Specialist Registry rather than an undifferentiated mega-dropdown.

The comprehensive esoteric-class resource also states that esoteric classes are exceedingly rare, highly specialized, and frequently unsuitable as general documentation defaults. Therefore, a grounded PASS system should neither pretend that the terminology has never shifted nor put every esoteric term into the main selector without context.

## Product implication

PASS should establish a transparent **versioned internal standard** rather than mechanically mirror a changing web component. Its framework should have a finite, carefully explained core vocabulary, a registry for specialist terms, and a custom designation route in every dimension.

| Framework layer | Purpose in PASS | Initial treatment |
|---|---|---|
| **Containment Designation** | Describes the Foundation’s practical relationship to controlling or managing the anomaly. | Standard options plus approved non-physical / nonstandard designations such as Ticonderoga; custom allowed. |
| **Secondary Operational Class** | Adds one optional, distinct operational role or special condition. | One optional value only; Thaumiel belongs here; custom allowed. |
| **Disruption Class** | Describes plausible impact on normal society or Veil integrity. | Standard ACS scale with custom route. |
| **Risk Class** | Describes severity and recoverability of effects on affected people. | Standard ACS scale with custom route. |
| **Status and escalation** | Records current condition and failure-state changes without overloading a classification field. | Separate fields, including defined escalation conditions. |

## Ticonderoga–Thaumiel working resolution

PASS can consistently place **Ticonderoga** under Containment Designation in its own versioned framework because it answers the containment relationship: the anomaly is not realistically containable but does not need conventional physical containment. **Thaumiel** remains a single Secondary Operational Class because it describes authorized use as a containment-support asset. This is a deliberate PASS convention, documented as such, rather than a false claim about the current standard ACS bar.

## Design guardrails

1. Every selectable value must have an explanation, appropriate-use criteria, and misuse warning.
2. Every classification dimension must permit a **Custom Designation** with a required rationale and approval note.
3. The class registry must show whether a designation is **PASS Core**, **PASS Specialist**, or **Custom**, and cite its source inspiration where relevant.
4. The app must preserve the classification framework version used by each SCP file so future revisions do not silently rewrite prior records.

## Sources

1. https://scp-wiki.wikidot.com/object-classes
2. https://scp-wiki.wikidot.com/anomaly-classification-system-guide
3. https://scp-wiki.wikidot.com/component:anomaly-class-bar
4. https://scp-wiki.wikidot.com/component:customizable-acs-guide
5. https://scp-wiki.wikidot.com/esoteric-classes-complete-list
6. https://scp-wiki.wikidot.com/a-history-of-object-classes
7. https://scp-wiki.wikidot.com/classification-committee-memo
8. https://scp-wiki.wikidot.com/esoteric-classes-complete-list
