import type { ClearanceLevel } from "@/lib/registry-types";

const clearanceRank: Record<ClearanceLevel, number> = {
  "Level 1": 1,
  "Level 2": 2,
  "Level 3": 3,
  "Level 4": 4,
  "Level 5": 5,
};

export function normalizeClearanceLevel(value: unknown): ClearanceLevel {
  if (typeof value === "number" && Number.isInteger(value) && value >= 1 && value <= 5) return `Level ${value}` as ClearanceLevel;
  if (typeof value !== "string") return "Level 1";
  const match = value.trim().match(/^(?:level|lvl|o)?\s*([1-5])$/i);
  return match ? `Level ${match[1]}` as ClearanceLevel : "Level 1";
}

export function recordId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

export function recordDetailPath(type: "scp" | "personnel" | "team", id: string) {
  const segment = type === "team" ? "teams" : type;
  return `/${segment}/${encodeURIComponent(id)}`;
}

export function scpItemNumberRank(itemNumber: string) {
  const match = itemNumber.trim().toUpperCase().match(/^SCP-(\d+)/);
  return match ? Number.parseInt(match[1], 10) : Number.MAX_SAFE_INTEGER;
}

export function compareScpItemNumbers(a: { itemNumber: string }, b: { itemNumber: string }) {
  const numericDifference = scpItemNumberRank(a.itemNumber) - scpItemNumberRank(b.itemNumber);
  return numericDifference || a.itemNumber.localeCompare(b.itemNumber, undefined, { numeric: true, sensitivity: "base" });
}

export function accessZonesForClearance(level: ClearanceLevel): string[] {
  const base = ["Personnel Commons", "Records Annex"];
  if (level === "Level 1") return base;
  if (level === "Level 2") return [...base, "Research Wing"];
  if (level === "Level 3") return [...base, "Research Wing", "Containment Corridor"];
  if (level === "Level 4") return [...base, "Research Wing", "Containment Corridor", "Site Command"];
  return [...base, "Research Wing", "Containment Corridor", "Site Command", "O5 Archive"];
}

export function canAccessClearance(activeLevel: ClearanceLevel | string | number | undefined, requiredLevel: ClearanceLevel) {
  return clearanceRank[normalizeClearanceLevel(activeLevel)] >= clearanceRank[requiredLevel];
}

export function highestClearanceLevel(levels: ClearanceLevel[], fallback: ClearanceLevel = "Level 1") {
  return levels.reduce<ClearanceLevel>((highest, level) => clearanceRank[level] > clearanceRank[highest] ? level : highest, fallback);
}

export function formatDate(value: string) {
  const date = new Date(value);
  return new Intl.DateTimeFormat("en", { month: "short", day: "2-digit", year: "numeric" }).format(date);
}

export function shortDate(value: string) {
  const date = new Date(value);
  return new Intl.DateTimeFormat("en", { month: "short", day: "2-digit" }).format(date);
}
