import { useRouter } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";

import { Eyebrow, Panel, ScreenTitle, StatusTag, palette } from "@/components/registry-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useRegistry } from "@/lib/registry-store";
import { canAccessClearance } from "@/lib/registry-utils";
import { useSession } from "@/lib/session-store";

export default function TerminalScreen() {
  const router = useRouter();
  const { scps, personnel, projects, incidents, hydrated } = useRegistry();
  const { profile } = useSession();
  const visibleScps = scps.filter((record) => canAccessClearance(profile.clearanceLevel, record.minimumClearanceLevel));
  const visibleProjects = projects.filter((project) => canAccessClearance(profile.clearanceLevel, project.minimumClearanceLevel));
  const visibleIncidents = incidents.filter((incident) => canAccessClearance(profile.clearanceLevel, incident.minimumClearanceLevel));
  const active = personnel.filter((record) => record.accessStatus === "Active").length;

  return (
    <ScreenContainer className="flex-1" containerClassName="bg-[#0D1113]">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <ScreenTitle label={`SITE NETWORK · ${profile.clearanceLevel.toUpperCase()}`} title="Terminal" detail={hydrated ? `${visibleScps.length} anomaly files available to this session.` : "Decrypting local records…"} />
        <Panel style={styles.statusPanel}>
          <View style={styles.statusTop}><View><Eyebrow>OPERATING STATE</Eyebrow><Text style={styles.statusTitle}>SYSTEM NOMINAL</Text></View><StatusTag label="Secure" tone="green" /></View>
          <View style={styles.statusRule} />
          <View style={styles.metrics}>
            <Metric value={String(visibleScps.length).padStart(2, "0")} label="ANOMALOUS FILES" />
            <Metric value={String(active).padStart(2, "0")} label="ACTIVE CREDENTIALS" />
            <Metric value={String(visibleProjects.length).padStart(2, "0")} label="ACTIVE PROJECTS" />
            <Metric value={String(visibleIncidents.filter((incident) => incident.status === "Active").length).padStart(2, "0")} label="ACTIVE INCIDENTS" />
          </View>
        </Panel>
        <View style={styles.actionGroup}><TerminalAction label="Database" detail="Guides, access references, archive systems, and facility records." icon="database-search-outline" onPress={() => router.push("/database" as never)} /><TerminalAction label="Incident Reports" detail="File, review, and control general operational incidents." icon="alert-octagon-outline" onPress={() => router.push("/incidents" as never)} /><TerminalAction label="Script Library" detail="Register and manage Entry typefaces." icon="format-font" onPress={() => router.push("/script-library" as never)} /><TerminalAction label="Projects" detail="Coordinate controlled multi-record Foundation work." icon="briefcase-account-outline" onPress={() => router.push("/projects" as never)} /></View>
      </ScrollView>
    </ScreenContainer>
  );
}

function Metric({ value, label }: { value: string; label: string }) { return <View style={styles.metric}><Text style={styles.metricValue}>{value}</Text><Text style={styles.metricLabel}>{label}</Text></View>; }
function TerminalAction({ label, detail, icon, onPress }: { label: string; detail: string; icon: keyof typeof MaterialCommunityIcons.glyphMap; onPress: () => void }) { return <Pressable android_ripple={{ color: "rgba(255,255,255,0.08)" }} onPress={onPress} style={styles.action}><View style={styles.actionIcon}><MaterialCommunityIcons name={icon} size={21} color={palette.blue} /></View><View style={styles.actionCopy}><Text style={styles.actionTitle}>{label}</Text><Text style={styles.actionDetail}>{detail}</Text></View><MaterialCommunityIcons name="chevron-right" size={22} color={palette.muted} /></Pressable>; }

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 28, gap: 18 },
  statusPanel: { gap: 15, padding: 18, backgroundColor: "#131E20" },
  statusTop: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" },
  statusTitle: { color: palette.ink, fontSize: 22, fontWeight: "900", letterSpacing: 0.6, marginTop: 3 },
  statusRule: { height: 1, backgroundColor: palette.line },
  metrics: { flexDirection: "row", justifyContent: "space-between", gap: 8 },
  metric: { flex: 1, gap: 4 },
  metricValue: { color: palette.ink, fontSize: 22, fontWeight: "800", fontVariant: ["tabular-nums"] },
  metricLabel: { color: palette.muted, fontSize: 8, fontWeight: "800", letterSpacing: 0.8, lineHeight: 12 },
  actionGroup: { gap: 10 }, action: { minHeight: 76, borderColor: palette.line, borderWidth: 1, backgroundColor: palette.panel, borderRadius: 4, flexDirection: "row", alignItems: "center", gap: 12, padding: 12, elevation: 1 }, actionIcon: { height: 42, width: 42, borderRadius: 3, backgroundColor: "#311B19", borderWidth: 1, borderColor: "#6C3833", alignItems: "center", justifyContent: "center" }, actionCopy: { flex: 1, gap: 3 }, actionTitle: { color: palette.ink, fontSize: 15, fontWeight: "900" }, actionDetail: { color: palette.muted, fontSize: 11, lineHeight: 15 }, pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});
