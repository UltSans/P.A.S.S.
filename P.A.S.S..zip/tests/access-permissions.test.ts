import { describe, expect, it } from "vitest";

import { availableClearanceLevels, canAssignClearance, canPerformAction, canPerformRecordAction } from "../lib/access-permissions";
import { normalizeClearanceLevel } from "../lib/registry-utils";

describe("PASS reader action permissions", () => {
  it("keeps Level 1 readers in a reference-only role", () => {
    expect(canPerformAction("Level 1", "create-entry")).toBe(false);
    expect(canPerformAction("Level 1", "create-scp")).toBe(false);
    expect(canPerformAction("Level 1", "export-entry")).toBe(false);
  });

  it("permits Level 2 document work but not registry authoring or exports", () => {
    expect(canPerformAction("Level 2", "create-entry")).toBe(true);
    expect(canPerformAction("Level 2", "import-typeface")).toBe(true);
    expect(canPerformAction("Level 2", "create-scp")).toBe(false);
    expect(canPerformAction("Level 2", "export-entry")).toBe(false);
  });

  it("requires Level 4 for personnel administration and typeface removal", () => {
    expect(canPerformAction("Level 3", "create-personnel")).toBe(false);
    expect(canPerformAction("Level 3", "remove-typeface")).toBe(false);
    expect(canPerformAction("Level 4", "create-personnel")).toBe(true);
    expect(canPerformAction("Level 4", "remove-typeface")).toBe(true);
    expect(canPerformAction("Level 5", "remove-typeface")).toBe(true);
  });

  it("normalizes persisted Level 5 variants before evaluating removal authority", () => {
    expect(normalizeClearanceLevel("LEVEL 5")).toBe("Level 5");
    expect(normalizeClearanceLevel("5")).toBe("Level 5");
    expect(normalizeClearanceLevel(5)).toBe("Level 5");
    expect(canPerformAction(normalizeClearanceLevel("Level5"), "remove-typeface")).toBe(true);
  });

  it("never permits a reader to assign a clearance above their own level", () => {
    expect(canAssignClearance("Level 3", "Level 4")).toBe(false);
    expect(availableClearanceLevels("Level 3")).toEqual(["Level 1", "Level 2", "Level 3"]);
  });

  it("requires both amendment authority and target-record visibility", () => {
    expect(canPerformRecordAction("Level 3", "amend-scp", "Level 3")).toBe(true);
    expect(canPerformRecordAction("Level 3", "amend-scp", "Level 4")).toBe(false);
    expect(canPerformRecordAction("Level 4", "amend-personnel", "Level 4")).toBe(true);
    expect(canPerformRecordAction("Level 4", "amend-personnel", "Level 5")).toBe(false);
    expect(canPerformRecordAction("Level 5", "amend-incident", "Level 5")).toBe(true);
  });
});
