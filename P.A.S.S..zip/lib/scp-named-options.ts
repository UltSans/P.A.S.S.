import { NOT_LISTED_SPECIFY, SCP_CLASSIFICATION_OPTION_FIELDS, type SCPRecord, type ScpClassificationOptionField, type ScpNamedClassificationOptions } from "./registry-types";

export function createEmptyScpNamedClassificationOptions(): ScpNamedClassificationOptions {
  return {
    containmentClass: [],
    custody: [],
    operationalRole: [],
    responsePosture: [],
    containmentConfiguration: [],
    lifecycleStatus: [],
    terminalEscalation: [],
    disruptionClass: [],
    riskClass: [],
  };
}

export function mergeScpNamedClassificationOptions(...catalogs: ScpNamedClassificationOptions[]): ScpNamedClassificationOptions {
  const merged = createEmptyScpNamedClassificationOptions();
  for (const field of SCP_CLASSIFICATION_OPTION_FIELDS) {
    const names = catalogs.flatMap((catalog) => catalog?.[field] ?? []).map(normalizeName).filter(Boolean);
    merged[field] = [...new Map(names.map((name) => [name.toLocaleLowerCase(), name])).values()];
  }
  return merged;
}

export function namedOptionsFromScp(record: SCPRecord): ScpNamedClassificationOptions {
  const options = createEmptyScpNamedClassificationOptions();
  const possible: Record<ScpClassificationOptionField, string | undefined> = {
    containmentClass: record.containmentClass === NOT_LISTED_SPECIFY ? record.customContainmentClass : undefined,
    custody: record.custody === NOT_LISTED_SPECIFY ? record.customCustody : undefined,
    operationalRole: record.operationalRole === NOT_LISTED_SPECIFY ? record.customOperationalRole : undefined,
    responsePosture: record.responsePosture === NOT_LISTED_SPECIFY ? record.customResponsePosture : undefined,
    containmentConfiguration: record.containmentConfiguration === NOT_LISTED_SPECIFY ? record.customContainmentConfiguration : undefined,
    lifecycleStatus: record.lifecycleStatus === NOT_LISTED_SPECIFY ? record.customLifecycleStatus : undefined,
    terminalEscalation: record.terminalEscalation === NOT_LISTED_SPECIFY ? record.customTerminalEscalation : undefined,
    disruptionClass: record.disruptionClass === NOT_LISTED_SPECIFY ? record.customDisruptionClass : undefined,
    riskClass: record.riskClass === NOT_LISTED_SPECIFY ? record.customRiskClass : undefined,
  };
  for (const field of SCP_CLASSIFICATION_OPTION_FIELDS) {
    const name = normalizeName(possible[field]);
    if (name) options[field] = [name];
  }
  return options;
}

export function visibleNamedOptions(builtIns: readonly string[], names: readonly string[]) {
  const builtInKeys = new Set(builtIns.map((value) => value.toLocaleLowerCase()));
  const reusable = names.map(normalizeName).filter((name) => Boolean(name) && name !== NOT_LISTED_SPECIFY && !builtInKeys.has(name.toLocaleLowerCase()));
  return [...builtIns.filter((value) => value !== NOT_LISTED_SPECIFY), ...new Map(reusable.map((name) => [name.toLocaleLowerCase(), name])).values(), NOT_LISTED_SPECIFY];
}

function normalizeName(value?: string) {
  return value?.trim().replace(/\s+/g, " ") ?? "";
}
