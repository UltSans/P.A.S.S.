import { PERSONNEL_DEPARTMENT_SUGGESTIONS, PERSONNEL_POSITION_GROUPS } from "./foundation-vocabulary";

export type PersonnelReferenceDefinition = { summary: string; use: string };

export const SITE19_PERSONNEL_ID_FORMAT = "S19-0001";
export const SITE19_PERSONNEL_ID_RULE = "Use S19 followed by a four-digit permanent personnel serial. The hyphen separates the site identifier from the serial. The ID identifies the record, not the person’s department, rank, clearance, class, or current assignment.";

export function formatSite19PersonnelId(serial: number): string {
  return `S19-${Math.max(0, Math.floor(serial)).toString().padStart(4, "0")}`;
}

export const PERSONNEL_DEPARTMENT_REFERENCE: Record<string, PersonnelReferenceDefinition> = {
  "Administration & Oversight": { summary: "Runs site governance, staffing, compliance, scheduling, and senior coordination.", use: "Use for people whose main work is directing or governing Site-19 rather than delivering a specialist service." },
  "Research Division": { summary: "Plans, performs, reviews, and documents anomalous research.", use: "Use for laboratory, analysis, interview, and research-management assignments." },
  "Containment Operations": { summary: "Operates containment areas and maintains day-to-day procedural control around anomalies.", use: "Use for staff who manage containment work itself, not for security-only posts or technical design alone." },
  "Security & Tactical Response": { summary: "Provides perimeter, access, custody, response, and security-system capability.", use: "Use for guards, security command, response staff, armory roles, and site security operations." },
  "Medical & Psychological Services": { summary: "Provides physical care, clinical support, behavioural health, and controlled patient transfer.", use: "Use for clinicians and medical support staff; it does not itself grant anomalous research authority." },
  "Field Operations & Investigation": { summary: "Handles recovery, investigation, surveillance, and controlled off-site operations.", use: "Use when the person’s normal work begins outside the site or concerns field evidence and recovery." },
  "Records & Information Security": { summary: "Protects, archives, redacts, and controls Foundation information.", use: "Use for records, archive, communications-monitoring, and information-security work." },
  "Engineering & Technical Services": { summary: "Maintains the site’s conventional and anomalous technical systems.", use: "Use for systems, paratechnology, technical maintenance, and infrastructure design work." },
  "Logistics, Procurement & Facilities": { summary: "Moves supplies, maintains workspaces, and supports site continuity.", use: "Use for transport, purchasing, stores, facilities, sanitation, and operational support." },
  "Ethics & Compliance": { summary: "Reviews whether site work follows approved ethical, legal, and procedural limits.", use: "Use for compliance oversight and Ethics Committee liaison work, not as a generic administrative label." },
  "Occult & Specialized Studies": { summary: "Hosts specialist anomalous disciplines outside routine research, medical, or security practice.", use: "Use for dedicated occult, memetic, antimemetic, linguistic, zoological, or similar specialist assignments." },
  "External Relations & Liaison": { summary: "Manages controlled contact with outside agencies, organizations, and individuals.", use: "Use for formal liaison work; document significant contacts in Personnel Entries." },
};

export const PERSONNEL_POSITION_REFERENCE: Record<string, PersonnelReferenceDefinition> = {
  "Site Director": { summary: "Leads Site-19 across departments and authorizes site-wide priorities.", use: "Use only for the site’s senior command role." },
  "Deputy Site Director": { summary: "Supports site command and acts for the Site Director when formally assigned.", use: "Use for a designated deputy rather than any senior administrator." },
  "Department Head": { summary: "Leads one department’s staffing, work programme, and internal standards.", use: "Use when the person is responsible for a defined department." },
  "Administrative Officer": { summary: "Manages administrative workflow, records, staffing coordination, or schedules.", use: "Use for operational administration rather than executive command." },
  "Executive Assistant": { summary: "Supports senior command through scheduling, correspondence, briefing, and coordination.", use: "Use for a dedicated senior-support position." },
  "Compliance Officer": { summary: "Reviews whether site activity follows approved procedure and required controls.", use: "Use for ongoing compliance work rather than a one-time audit." },
  "Ethics Committee Liaison": { summary: "Coordinates communication between Site-19 and Ethics Committee oversight.", use: "Use for the assigned liaison; it does not make the person an Ethics Committee member." },
  "Research Assistant": { summary: "Supports defined research work under a researcher or lead’s direction.", use: "Use for trained support work below independent research responsibility." },
  "Junior Researcher": { summary: "Performs supervised early-career anomalous research and documentation.", use: "Use for the Research Clearance 1 career stage." },
  "Researcher": { summary: "Conducts approved anomalous research within an assigned programme.", use: "Use for independent routine research responsibility." },
  "Senior Researcher": { summary: "Leads or reviews complex research work and mentors lower-clearance researchers.", use: "Use for the Research Clearance 4 career stage." },
  "Lead Researcher": { summary: "Owns a defined research programme, team, or major investigation.", use: "Use when programme leadership is the person’s primary duty." },
  "Research Analyst": { summary: "Interprets research data, evidence, patterns, or accumulated findings.", use: "Use for analysis-led work rather than laboratory or containment operation." },
  "Laboratory Technician": { summary: "Maintains laboratory workflow, equipment, samples, and controlled preparation.", use: "Use for technical laboratory support, not independent research command." },
  "Containment Specialist": { summary: "Runs practical containment procedures and supports anomaly management.", use: "Use for operational containment work." },
  "Containment Engineer": { summary: "Designs, improves, and maintains containment systems and safeguards.", use: "Use for engineering responsibility behind a containment solution." },
  "Containment Technician": { summary: "Performs hands-on inspection, maintenance, and setup of containment equipment.", use: "Use for technical execution under containment engineering or operations." },
  "Containment Operations Officer": { summary: "Coordinates containment staffing, schedules, incidents, and procedure execution.", use: "Use for operational coordination rather than chamber maintenance." },
  "Anomalous Entity Liaison": { summary: "Maintains controlled communication with a cooperative or sapient anomalous entity.", use: "Use only when structured relationship management is assigned." },
  "Security Officer": { summary: "Provides routine security duty at assigned posts, routes, or checkpoints.", use: "Use for ordinary permanent site-security work." },
  "Security Supervisor": { summary: "Supervises a security shift, post group, or local response function.", use: "Use for direct supervision, not site-wide security command." },
  "Tactical Response Officer": { summary: "Provides trained tactical response during hostile or dangerous operational events.", use: "Use for a tactical role; it does not automatically make the person MTF." },
  "Response Commander": { summary: "Directs an assigned tactical or incident-response operation.", use: "Use when the person commands a specific response, not routine guard duty." },
  "Armory Custodian": { summary: "Controls issue, return, inspection, and records for authorized security equipment.", use: "Use for accountable armory management." },
  "Security Systems Analyst": { summary: "Maintains or reviews surveillance, access-control, alarm, and security-system data.", use: "Use for security technology and analysis rather than frontline patrol." },
  "Chief Medical Officer": { summary: "Leads Site-19 clinical services, standards, and medical staffing.", use: "Use only for the clinical department’s senior command role." },
  Physician: { summary: "Diagnoses and treats physical illness or injury within Clinical Services.", use: "Use for a licensed medical practitioner role." },
  Nurse: { summary: "Provides ongoing patient care, monitoring, treatment support, and clinical coordination.", use: "Use for nursing work rather than general medical administration." },
  Paramedic: { summary: "Stabilizes patients during urgent movement, incident response, or transfer.", use: "Use for emergency pre-hospital or transfer-focused clinical work." },
  "Anomalous Psychiatrist": { summary: "Provides psychiatric assessment where anomalous exposure or behaviour is relevant.", use: "Use for a clinical specialty, not a general security restriction role." },
  Psychologist: { summary: "Provides psychological evaluation, support, and fitness-for-duty assessment.", use: "Use for clinical psychological work." },
  "Anomalous Pathologist": { summary: "Examines biological or post-mortem material involving anomalous factors.", use: "Use for pathology and forensic biological analysis." },
  "Quarantine Officer": { summary: "Coordinates procedural isolation, movement limits, and quarantine records.", use: "Use for operational quarantine management, not every clinician." },
  "Biohazard Specialist": { summary: "Manages hazardous biological containment, controls, and safety procedure.", use: "Use for biohazard safety and response work." },
  "Field Agent": { summary: "Carries out authorized off-site Foundation operations.", use: "Use for general field activity outside Site-19." },
  "Investigative Agent": { summary: "Builds and pursues controlled inquiries into anomalous events or leads.", use: "Use for investigation-led field work." },
  "Recovery Specialist": { summary: "Plans or supports the recovery and secure transfer of anomalous material.", use: "Use for recovery logistics and field containment support." },
  "Tactical Forensics Lead": { summary: "Leads operational evidence collection and analysis after an incident or recovery.", use: "Use for forensics leadership, not routine security supervision." },
  "Surveillance Officer": { summary: "Operates or coordinates authorized observation and surveillance activity.", use: "Use for monitoring-focused field or site work." },
  "Evidence Custodian": { summary: "Maintains chain of custody and controlled storage for evidence.", use: "Use for evidence accountability, not general records work." },
  "Records Officer": { summary: "Processes, maintains, and controls formal site records.", use: "Use for records workflow and documentation control." },
  Archivist: { summary: "Maintains long-term archival continuity, retrieval, and preservation.", use: "Use for archive stewardship rather than live records intake." },
  "Redaction Specialist": { summary: "Removes or controls sensitive information before authorized circulation.", use: "Use for deliberate information-sanitization work." },
  "Document Analyst": { summary: "Reviews documents for content, provenance, relevance, or intelligence value.", use: "Use for analytical document work." },
  "Information Security Analyst": { summary: "Protects systems and records from unauthorized disclosure or compromise.", use: "Use for information-security analysis and controls." },
  "Communications Monitor": { summary: "Monitors authorized communications channels for operational continuity or security.", use: "Use for controlled communications oversight." },
  "Systems Engineer": { summary: "Designs or maintains conventional technical systems used by the site.", use: "Use for non-anomalous systems engineering." },
  "Paratechnology Specialist": { summary: "Maintains or evaluates technology with anomalous or non-standard principles.", use: "Use when the technical work is specifically paratechnological." },
  "Facilities Technician": { summary: "Maintains site utilities, workspace systems, and physical infrastructure.", use: "Use for facilities maintenance and technical support." },
  "Logistics Coordinator": { summary: "Plans controlled movement of supplies, people, or operational resources.", use: "Use for logistics planning rather than vehicle operation alone." },
  "Procurement Officer": { summary: "Sources, receives, and records authorized equipment and materials.", use: "Use for purchasing and controlled acquisition work." },
  "Transport Officer": { summary: "Operates or coordinates authorized vehicle, freight, or transfer movement.", use: "Use for transport-focused operational support." },
  "Janitorial Services Officer": { summary: "Maintains sanitation, cleaning, and safe working conditions in assigned areas.", use: "Use for sanitation work; it does not determine personnel class or clearance." },
  Thaumaturgist: { summary: "Studies or applies controlled ritual, occult, or structured magical practice.", use: "Use only for a dedicated specialist assignment." },
  "Occult Studies Specialist": { summary: "Analyzes occult systems, artefacts, traditions, or related anomalous practices.", use: "Use for broad occult-specialist work distinct from a thaumaturgist role." },
  "Memetics Specialist": { summary: "Works with information patterns that can affect cognition, perception, or behaviour.", use: "Use for active memetic study, screening, or containment." },
  "Antimemetics Specialist": { summary: "Works with information that resists noticing, recording, remembering, or communicating.", use: "Use only for a dedicated antimemetic assignment." },
  Cryptozoologist: { summary: "Studies anomalous fauna or biological entities with zoological methods.", use: "Use for an anomalous-animal specialist role." },
  "Linguist / Translator": { summary: "Interprets languages, scripts, codes, or communication systems needed for operations.", use: "Use for formal linguistic or translation responsibility." },
  "Forensic Specialist": { summary: "Analyzes physical, biological, digital, or scene evidence for operational findings.", use: "Use for forensic analysis outside the specific Tactical Forensics Lead command role." },
  "Anomalous Materials Researcher": { summary: "Studies physical substances, alloys, samples, or materials with anomalous properties.", use: "Use for materials-focused research." },
};

export const PERSONNEL_REFERENCE_AUDIT = {
  departmentCount: PERSONNEL_DEPARTMENT_SUGGESTIONS.length,
  positionCount: PERSONNEL_POSITION_GROUPS.flatMap((group) => group.options).length,
  missingDepartments: PERSONNEL_DEPARTMENT_SUGGESTIONS.filter((term) => !PERSONNEL_DEPARTMENT_REFERENCE[term]),
  missingPositions: PERSONNEL_POSITION_GROUPS.flatMap((group) => group.options).filter((term) => !PERSONNEL_POSITION_REFERENCE[term]),
};

export function personnelReferenceDefinition(term: string | null | undefined): PersonnelReferenceDefinition | undefined {
  if (!term) return undefined;
  return PERSONNEL_DEPARTMENT_REFERENCE[term] ?? PERSONNEL_POSITION_REFERENCE[term];
}
