// PASS uses React Native style callbacks for every Pressable. A global NativeWind
// remap stripped those styles on Android, leaving only bare vertical children
// visible. Keep this module as an intentional no-op because it is imported at
// application startup, but do not mutate Pressable's native prop handling.
export {};
