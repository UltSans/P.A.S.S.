import { describe, expect, it } from "vitest";

import { canAccessProject, normalizeProjectLinks, projectLinkCount, uniqueRecordIds } from "../lib/project-utils";

describe("project relationships", () => {
  it("deduplicates and removes blank linked record IDs before persistence", () => {
    expect(uniqueRecordIds(["scp-014", "", "scp-014", "scp-112", "scp-112"])).toEqual(["scp-014", "scp-112"]);
  });

  it("counts only explicit links across SCP, personnel, and team records", () => {
    expect(projectLinkCount({ scpIds: ["scp-014", "scp-112"], personnelIds: ["per-014"], teamIds: ["team-014", "team-031"] })).toBe(5);
  });

  it("migrates missing local project link arrays safely and keeps them deduplicated", () => {
    expect(normalizeProjectLinks({ scpIds: ["scp-014", "scp-014"] })).toEqual({ scpIds: ["scp-014"], personnelIds: [], teamIds: [] });
  });

  it("does not expose a Project above the reader clearance", () => {
    expect(canAccessProject("Level 2", "Level 2")).toBe(true);
    expect(canAccessProject("Level 2", "Level 4")).toBe(false);
  });
});
