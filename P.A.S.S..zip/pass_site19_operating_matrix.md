# PASS / Site-19 — Facility-First Operating Matrix

## Design question

The five levels must not be a stack of unrelated room categories. They are five different **operating environments** in one institution. Each level exists because it accepts a different degree of external contact, anomaly contact, custody risk, or infrastructure sensitivity.

> **Facility rule:** A person, patient, D-Class subject, delivery, record, asset, or emergency moves through Site-19 only along a route that has a clear operating owner and a reason to exist.

## The vertical model

| Level | Operating environment | What the level produces for the rest of Site-19 | What it must not become |
|---|---|---|---|
| **L1 — Surface and Entry** | The controlled boundary with the outside world. | Screened people, cleared freight, perimeter security, external handoff, and safe egress. | A public lobby, a direct route to containment, or a generic office floor. |
| **L2 — Administration and Clinical Services** | The low-anomaly-contact institutional core. | Command, records, personnel administration, credential control, broad staff care, and controlled assignment into deeper work. | An extension of LCZ, an on-site security academy, or a place where restricted assets are casually displayed. |
| **L3 — Light Containment and Research** | The daily containment-and-research work environment. | Routine containment work, supervised research, custody dispatch, materials handling, staff services, and the controlled HCZ handoff. | A free-movement campus, an administrative shortcut, or a cafeteria connected to containment cells. |
| **L4 — Heavy Containment and Isolation** | The low-traffic, high-consequence operating environment. | High-risk custody, specialist work, decontamination/isolation, recovery support, and deep-isolation management. | A continuation of LCZ or a through-route to storage. |
| **L5 — Heavy Storage and Protected Systems** | The rare-use custody and infrastructure environment. | Long-hold storage, protected evidence/archives, deep logistics, protected utilities, and purpose-limited contingency custody. | An ordinary lower basement, a daily workplace, or an alternate staff route. |

## Who works where

| Workforce | Normal operating level | Reason |
|---|---|---|
| Site leadership, administration, credential staff, records staff, general clinical staff, and department coordinators | **L2** | Their routine job requires protected institutional support, not routine anomaly contact. |
| Research personnel, containment officers, LCZ security, service staff, approved maintenance, and D-Class custody staff | **L3** | Their work is active, repeated, and directly tied to routine containment/research operations. |
| HCZ specialists, containment recovery personnel, specialist researchers, decontamination staff, and restricted response support | **L4** | Their routine work is controlled, destination-specific, and not compatible with general L3 circulation. |
| Custodians, deep logistics personnel, archive/evidence staff, and restricted infrastructure technicians | **L5** | Their work is infrequent, logged, and purpose-specific. |
| Perimeter security, arrivals staff, receiving teams, vehicle-control personnel, and external liaison staff | **L1** | Their job exists at the point where the site meets the outside world. |

No person should receive an entire level as a default entitlement. A person is assigned a **division and route**, then granted a particular local exception only when their work requires it.

## The six movements Site-19 must support

| Movement | Normal path | Reason it is separate |
|---|---|---|
| **Staff movement** | L1 personnel arrival → L2 staff access/briefing → assigned level and division. | Administrative staff must not cross containment checkpoints merely to reach an office. |
| **D-Class custody movement** | Controlled L1 custody handoff → dedicated secure transfer → L3 D-Class custody/dispatch. | D-Class arrival, welfare, screening, housing, and testing dispatch are a custody operation—not staff circulation. |
| **Freight and material movement** | L1 receiving → controlled logistics route → L3 material intake or L5 deep logistics. | Deliveries never move through personnel reception, L2 offices, dining, or general clinical corridors. |
| **Clinical movement** | L1/L2 ordinary staff → L2 Clinical Services; L3/L4 incident → local stabilization → controlled clinical isolation/transfer. | An exposure or contaminated patient must not enter general treatment circulation without a safety decision. |
| **Maintenance movement** | L1/L2 service coordination → designated maintenance route → assigned systems area. | Utilities work needs access without granting researchers, cleaners, or technicians general containment movement. |
| **Emergency egress** | Any level → protected egress core → safe surface exit. | Egress saves life; it is not a convenient ordinary travel route. |

## The facility boundary hierarchy

The Site-19 door and gate model is not about decoration. It indicates who owns the next environment and what must be checked before crossing it.

| Boundary | Required decision | Examples |
|---|---|---|
| **Room / Light Door** | Does this person have a routine assignment to this internal workspace? | Clinical consultation room, records workroom, ordinary lab office. |
| **Division / Heavy Door** | Does this person have standing authority for this controlled division and any required local assignment? | D-Class custody block, Light Containment Cluster, research cell corridor. |
| **Checkpoint** | Is this person both authorized and currently expected to move into a separately supervised operating environment? | L1 secure arrival → L2; L2 → L3 LCZ duty control. |
| **Gate** | Is this major environment transition available, and does the destination authority justify it? | L3 → L4 HCZ transfer; deep freight/custody handoff; controlled surface egress. |
| **Isolation boundary** | Is the person explicitly approved for the named isolated sector, under the required condition? | Deep Isolation; restricted clinical isolation; exceptional custody vault. |

## What each level must support internally

| Level | Required internal support | Why this makes the level realistic |
|---|---|---|
| **L1** | Perimeter/security operations, personnel screening, vehicle/freight handling, external liaison, controlled surface utilities, emergency assembly/egress. | It can accept external traffic without letting the site’s actual work begin at the surface door. |
| **L2** | Command, records, credentials, personnel administration, clinical services, briefings/assignment preparation, internal communications, office services. | It lets Site-19 operate like a large employer and institution without routine anomaly traffic. |
| **L3** | Duty control, containment clusters, research/interview/testing support, D-Class custody, material intake, food/rest/sanitation, clinical response, maintenance support, HCZ handoff. | People working long shifts around anomalies have all needed daily support without mixing risky flows. |
| **L4** | Transfer control, HCZ clusters, specialist research, decontamination/clinical isolation, recovery support, protective equipment, isolated technical support. | High-consequence work is operationally self-contained instead of depending on normal LCZ routes. |
| **L5** | Long-hold custody, evidence/archive custody, deep logistics, protected utilities, rare-use controlled assets, purpose-limited contingency governance. | Rare retrieval and infrastructure work stay deliberate and do not turn into uncontrolled daily traffic. |

## Decisions that should remain open until the full draft

The current model does **not** decide the surface-cover identity, exact sector codes, how many lifts each level has, the exact size of any division, or the location of any new individual SCP. Those are second-order design choices. The first-order requirement is that each level can explain its work, people, inputs, outputs, and boundaries.
