import { describe, expect, it } from "vitest";

import { typefaceUsage } from "../lib/typeface-usage";

describe("typeface usage registry", () => {
  it("counts reusable typeface references across multiple Entries without counting plain blocks", () => {
    const usage = typefaceUsage([
      { documentBlocks: [{ id: "one", kind: "Paragraph", text: "Plain." }, { id: "two", kind: "Recovered Script", text: "𐌀", typefaceId: "font-a" }] },
      { documentBlocks: [{ id: "three", kind: "Transcript", text: "Line.", typefaceId: "font-a" }, { id: "four", kind: "Quotation", text: "Other.", typefaceId: "font-b" }] },
    ]);
    expect(usage.get("font-a")).toBe(2);
    expect(usage.get("font-b")).toBe(1);
    expect(usage.get("unknown")).toBeUndefined();
  });
});
