import { useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useRouter } from "expo-router";

import { Eyebrow, Panel, ScreenTitle, StatusTag, palette } from "@/components/registry-ui";
import { ScreenContainer } from "@/components/screen-container";
import { SITE19_CONNECTORS, SITE19_LEVELS, SITE19_PERSONNEL_ROUTES, SITE19_SECTORS, type Site19LevelId, type Site19Sector } from "@/lib/site19-registry";
import { canAccessFacilityItem, visibleFacilitySectors } from "@/lib/site19-utils";
import { useSession } from "@/lib/session-store";

export default function FacilityRecordsScreen() {
  const router = useRouter();
  const { profile } = useSession();
  const [levelId, setLevelId] = useState<Site19LevelId>("L1");
  const levels = SITE19_LEVELS.map((level) => ({ ...level, available: canAccessFacilityItem(profile.clearanceLevel, level) }));
  const selectedLevel = SITE19_LEVELS.find((level) => level.id === levelId)!;
  const divisions = useMemo(
    () => visibleFacilitySectors(profile.clearanceLevel, SITE19_SECTORS).filter((sector) => sector.level === levelId),
    [profile.clearanceLevel, levelId],
  );
  const routes = useMemo(
    () => SITE19_CONNECTORS.filter((connector) => canAccessFacilityItem(profile.clearanceLevel, connector)),
    [profile.clearanceLevel],
  );
  const personnelRoutes = useMemo(
    () => SITE19_PERSONNEL_ROUTES.filter((route) => canAccessFacilityItem(profile.clearanceLevel, route)),
    [profile.clearanceLevel],
  );

  return (
    <ScreenContainer className="flex-1" containerClassName="bg-[#0D1113]">
      <FlatList
        data={divisions}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View style={styles.header}>
            <View style={styles.topbar}>
              <Pressable onPress={() => router.back()} style={styles.back}>
                <MaterialCommunityIcons name="arrow-left" color={palette.ink} size={25} />
              </Pressable>
              <Eyebrow>DATABASE / REF-05 / FACILITY RECORDS</Eyebrow>
            </View>
            <ScreenTitle
              label="SITE-19 FACILITY-ONLY MAP"
              title="Division Register"
              detail="Levels, divisions, zones, boundaries, and route families. This record maps the site itself, not the contents assigned to it."
            />
            <Panel style={styles.note}>
              <MaterialCommunityIcons name="office-building-marker-outline" color={palette.blue} size={20} />
              <Text style={styles.noteText}>Every division exists for a defined operational purpose. Individual SCP contents, room plans, and tactical procedures remain outside REF-05.</Text>
            </Panel>
            <View style={styles.levels}>
              {levels.map((level) => (
                <Pressable
                  key={level.id}
                  disabled={!level.available}
                  onPress={() => setLevelId(level.id)}
                  style={[styles.level, level.id === levelId && styles.levelActive, !level.available && styles.levelLocked]}
                >
                  <Text style={[styles.levelCode, level.id === levelId && styles.levelCodeActive]}>{level.id}</Text>
                  <Text style={[styles.levelTitle, level.id === levelId && styles.levelTitleActive]}>{level.available ? level.title : "Restricted"}</Text>
                  {!level.available ? <MaterialCommunityIcons name="lock-outline" size={13} color={palette.muted} /> : null}
                </Pressable>
              ))}
            </View>
            <Panel style={styles.levelPanel}>
              <Eyebrow>{selectedLevel.id} / {selectedLevel.minimumClearanceLevel.toUpperCase()}</Eyebrow>
              <Text style={styles.selectedTitle}>{selectedLevel.title}</Text>
              <Text style={styles.selectedMission}>{selectedLevel.mission}</Text>
            </Panel>
            <View style={styles.sectionHeading}>
              <Eyebrow>REGISTERED DIVISIONS</Eyebrow>
              <Text style={styles.sectionTitle}>{divisions.length} clearance-available division{divisions.length === 1 ? "" : "s"}</Text>
            </View>
          </View>
        }
        renderItem={({ item }) => <DivisionCard division={item} />}
        ListEmptyComponent={
          <Panel style={styles.empty}>
            <MaterialCommunityIcons name="lock-outline" color={palette.muted} size={25} />
            <Text style={styles.emptyTitle}>No division detail at this clearance</Text>
            <Text style={styles.emptyDetail}>The level remains registered, but its controlled division detail is unavailable to the current reader session.</Text>
          </Panel>
        }
        ListFooterComponent={
          <View style={styles.footer}>
            <View style={styles.sectionHeading}>
              <Eyebrow>APPROVED ROUTE FAMILIES</Eyebrow>
              <Text style={styles.sectionTitle}>Movement registry</Text>
            </View>
            <View style={styles.routeList}>
              {routes.map((route) => (
                <Panel key={route.id} style={styles.route}>
                  <View style={styles.routeTop}>
                    <StatusTag label={route.id} tone="blue" />
                    <Text style={styles.routeTitle}>{route.title}</Text>
                  </View>
                  <Text style={styles.routeBody}>{route.connects}</Text>
                  <Text style={styles.routeUsers}>{route.users}</Text>
                  <Text style={styles.routeRule}>{route.rule}</Text>
                </Panel>
              ))}
            </View>
            <View style={styles.sectionHeading}>
              <Eyebrow>PERSONNEL MOVEMENT MODEL</Eyebrow>
              <Text style={styles.sectionTitle}>Normal routes by operational family</Text>
            </View>
            <Panel style={styles.clearanceContext}>
              <Eyebrow>CLEARANCE AND ROUTE CONTEXT</Eyebrow>
              <Text style={styles.clearanceText}>Clearance expresses seniority, trust, and responsibility inside a person’s department. Physical movement still requires a current division assignment, route authority, work purpose, active restriction check, and any necessary escort.</Text>
              <Text style={styles.trackText}>Research: Level 1 Junior Researcher · Level 2 Research Assistant · Level 3 Researcher · Level 4 Senior Researcher · Level 5 Site Director</Text>
              <Text style={styles.trackText}>Security: Level 1 Security Guard · Level 2 Senior Security Guard · Level 3 Security Operative or MTF Operative · Level 4 Security Director or MTF Commander · Level 5 Site Director</Text>
            </Panel>
            <View style={styles.personnelRouteList}>
              {personnelRoutes.map((route) => (
                <Panel key={route.id} style={styles.personnelRoute}>
                  <Text style={styles.personnelRouteTitle}>{route.title}</Text>
                  <Text style={styles.personnelRouteLabel}>NORMAL ROUTE</Text>
                  <Text style={styles.personnelRouteText}>{route.normalRoute}</Text>
                  <Text style={styles.personnelRouteLabel}>CONTROLLED TRANSITION</Text>
                  <Text style={styles.personnelRouteText}>{route.controlledTransition}</Text>
                  <Text style={styles.personnelRouteExclusion}>{route.exclusion}</Text>
                </Panel>
              ))}
            </View>
            <Panel style={styles.address}>
              <Eyebrow>FACILITY DESIGNATION STANDARD</Eyebrow>
              <Text style={styles.addressCode}>S19-L&#123;LEVEL&#125;-&#123;DIVISION&#125;[-&#123;ZONE&#125;]</Text>
              <Text style={styles.addressBody}>The optional zone suffix identifies a large internal zone such as A, B, or C. REF-05 does not register every room, corridor, person, or anomaly contents.</Text>
            </Panel>
          </View>
        }
      />
    </ScreenContainer>
  );
}

function DivisionCard({ division }: { division: Site19Sector }) {
  return (
    <Panel style={styles.division}>
      <View style={styles.divisionTop}>
        <View style={styles.divisionHeading}>
          <Text style={styles.divisionCode}>{division.code}</Text>
          <Text style={styles.divisionTitle}>{division.title}</Text>
        </View>
        <StatusTag label={division.accessBoundary} tone="blue" />
      </View>
      <Text style={styles.divisionFunction}>{division.function}</Text>
      <View style={styles.population}>
        <MaterialCommunityIcons name="account-group-outline" size={15} color={palette.blue} />
        <Text style={styles.populationText}>{division.population}</Text>
      </View>
      <View style={styles.zoneBlock}>
        <Eyebrow>MAP-LEVEL ZONES</Eyebrow>
        <View style={styles.zoneList}>
          {division.zones.map((zone) => <Text key={zone.id} style={styles.zoneChip}>{zone.id} / {zone.label}</Text>)}
        </View>
      </View>
      <View style={styles.boundary}>
        <MaterialCommunityIcons name="shield-lock-outline" size={15} color={palette.blue} />
        <Text style={styles.boundaryText}>{division.boundary}</Text>
      </View>
      <View style={styles.routeCodes}>{division.connectors.map((route) => <Text key={route} style={styles.routeCode}>{route} ROUTE</Text>)}</View>
    </Panel>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 34, gap: 10, flexGrow: 1 },
  header: { gap: 14, marginBottom: 4 },
  topbar: { flexDirection: "row", alignItems: "center", gap: 11 },
  back: { height: 52, width: 52, borderRadius: 4, backgroundColor: palette.panelRaised, borderColor: palette.line, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  note: { flexDirection: "row", alignItems: "flex-start", gap: 10, backgroundColor: "#211A18", borderColor: "#64312C", borderRadius: 2 },
  noteText: { flex: 1, color: palette.slate, fontSize: 12, lineHeight: 18 },
  levels: { gap: 7 },
  level: { minHeight: 54, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 12, borderWidth: 1, borderColor: palette.line, backgroundColor: palette.panelRaised, borderRadius: 2 },
  levelActive: { borderColor: "#7A2A26", backgroundColor: "#3B1D1A" },
  levelLocked: { opacity: 0.48 },
  levelCode: { width: 28, color: palette.muted, fontSize: 12, fontWeight: "900", letterSpacing: 0.7 },
  levelCodeActive: { color: palette.blue },
  levelTitle: { flex: 1, color: palette.muted, fontSize: 12, fontWeight: "800" },
  levelTitleActive: { color: palette.ink },
  levelPanel: { gap: 6, borderRadius: 2 },
  selectedTitle: { color: palette.ink, fontSize: 18, fontWeight: "900" },
  selectedMission: { color: palette.slate, fontSize: 12, lineHeight: 18 },
  sectionHeading: { gap: 2, marginTop: 3 },
  sectionTitle: { color: palette.ink, fontSize: 16, fontWeight: "900" },
  division: { gap: 11, borderRadius: 2, padding: 14 },
  divisionTop: { flexDirection: "row", gap: 10, justifyContent: "space-between" },
  divisionHeading: { flex: 1, gap: 4 },
  divisionCode: { color: palette.blue, fontSize: 10, fontWeight: "900", letterSpacing: 0.9 },
  divisionTitle: { color: palette.ink, fontSize: 16, fontWeight: "900", lineHeight: 21 },
  divisionFunction: { color: palette.slate, fontSize: 12, lineHeight: 18 },
  population: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  populationText: { flex: 1, color: palette.muted, fontSize: 11, lineHeight: 16 },
  zoneBlock: { gap: 6, paddingTop: 10, borderTopColor: palette.line, borderTopWidth: 1 },
  zoneList: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  zoneChip: { color: palette.slate, fontSize: 10, fontWeight: "800", borderColor: palette.line, borderWidth: 1, paddingHorizontal: 7, paddingVertical: 5, borderRadius: 2 },
  boundary: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  boundaryText: { color: palette.muted, fontSize: 11, lineHeight: 16, flex: 1 },
  routeCodes: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  routeCode: { color: palette.muted, fontSize: 9, fontWeight: "900", letterSpacing: 0.7, borderColor: palette.line, borderWidth: 1, paddingHorizontal: 7, paddingVertical: 5, borderRadius: 2 },
  footer: { gap: 10, marginTop: 10 },
  routeList: { gap: 8 },
  route: { gap: 6, borderRadius: 2, padding: 13 },
  routeTop: { flexDirection: "row", alignItems: "center", gap: 9 },
  routeTitle: { color: palette.ink, fontSize: 13, fontWeight: "900" },
  routeBody: { color: palette.slate, fontSize: 11, lineHeight: 16 },
  routeUsers: { color: palette.muted, fontSize: 10, lineHeight: 15 },
  routeRule: { color: palette.muted, fontSize: 10, lineHeight: 15, paddingTop: 7, borderTopColor: palette.line, borderTopWidth: 1 },
  clearanceContext: { gap: 8, borderRadius: 2, borderColor: "#64312C", backgroundColor: "#211A18" },
  clearanceText: { color: palette.slate, fontSize: 12, lineHeight: 18 },
  trackText: { color: palette.muted, fontSize: 10, lineHeight: 16 },
  personnelRouteList: { gap: 8 },
  personnelRoute: { gap: 5, borderRadius: 2, padding: 13 },
  personnelRouteTitle: { color: palette.ink, fontSize: 13, fontWeight: "900" },
  personnelRouteLabel: { color: palette.blue, fontSize: 9, fontWeight: "900", letterSpacing: 0.8, marginTop: 3 },
  personnelRouteText: { color: palette.slate, fontSize: 11, lineHeight: 16 },
  personnelRouteExclusion: { color: palette.muted, fontSize: 10, lineHeight: 15, paddingTop: 7, marginTop: 2, borderTopColor: palette.line, borderTopWidth: 1 },
  address: { gap: 7, borderRadius: 2, marginTop: 4 },
  addressCode: { color: palette.blue, fontSize: 11, fontWeight: "900", letterSpacing: 0.8 },
  addressBody: { color: palette.slate, fontSize: 12, lineHeight: 18 },
  empty: { alignItems: "center", gap: 8, paddingVertical: 28, borderRadius: 2 },
  emptyTitle: { color: palette.ink, fontSize: 16, fontWeight: "900" },
  emptyDetail: { color: palette.muted, fontSize: 12, lineHeight: 18, textAlign: "center", maxWidth: 310 },
});
