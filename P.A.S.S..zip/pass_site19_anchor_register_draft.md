# PASS / Site-19 — Provisional Anchor Register

## Purpose

This register applies the approved rule that **Facility Records names only SCPs or assets that materially change Site-19’s operations, routes, or boundaries**. It does not create any app data or final placement. All non-anchor SCPs remain dossier-assigned to a meaningful generic cluster.

An asset is a map anchor only when at least one of the following is true:

| Anchor test | Why it matters to the map |
|---|---|
| It needs its own dedicated operating division or cell. | The building must provide a distinct work environment, not only capacity. |
| It changes a cross-level route. | Staff, material, patient, or custody movement must be planned around it. |
| It requires a unique gate or deep-isolation boundary. | The facility’s normal circulation cannot reach it. |
| It has a site-wide custodial or clinical governance function. | Its location affects more than one division. |

## Confirmed candidate anchors

| Anchor | Proposed role in the map | Strongest provisional assignment | Why it earns map status | What Facility Records may show |
|---|---|---|---|---|
| **SCP-914** | Active controlled materials research asset. | **L3 Research & Engineering — Research Cell 109-B.** | Requires a guarded research cell, command-approved operation, materials staging, and separate output assessment. | Cell name, L3 research division, Heavy Door, restricted scheduled operation. |
| **SCP-500** | Scarce medical-anomalous custody asset with a cross-level clinical release path. | **L5 Medical-Anomalous Custody Vault**, released for L2 Secure Custody Treatment. | Its custody affects L5 storage, L2 clinical authority, and a documented patient-specific transfer. | Vault identity, Level-4 custodial restriction, controlled clinical release relationship. |
| **SCP-682** | Deep-isolation containment anchor. | **L4 Deep Isolation Sector.** | Its procedure requires a purpose-built isolated environment and changes HCZ access/transfer architecture. | Sector identity and restricted status only; no chamber or tactical details. |
| **Omega Contingency Custody** | Site-critical governance/infrastructure anchor, not an SCP placement. | **L5 Restricted Custody.** | It justifies a uniquely restricted L5 boundary but should not be presented as a chamber or weapon system. | Governance-level custody label and access restriction only. |

## Generic clusters for all other dossier-assigned SCPs

| Generic cluster | Intended asset pattern | Level | Dossier use |
|---|---|---|---|
| **Applied Research Cells** | Active non-biological or low-consequence research assets requiring routine supervised study. | L3 | A dossier records the named cell/cluster and project-specific permission. |
| **Light Containment Clusters** | Safe and appropriate Euclid records whose normal work does not require HCZ isolation. | L3 | A dossier records cluster, cell/subsector, and ordinary access conditions. |
| **HCZ Containment Clusters** | Assets requiring high-consequence separation but not a unique site anchor. | L4 | A dossier records cluster, restricted sector grant, and any local compartment permission. |
| **Long-Hold Anomalous Storage** | Packaged, inert, rarely retrieved, or stable custodial items. | L5 | A dossier records vault/cluster and a retrieval authority. |
| **Evidence and Physical Archive Custody** | Recovered material, physical records, samples, and evidence rather than active containment. | L5 | A dossier records archive division and handling restriction. |
| **External / Field / Joint Custody** | Records not normally housed at Site-19. | Outside Site-19 | A dossier records custody status and, where needed, a Site-19 liaison/project relationship. |

## Do not name an SCP on the map merely because it is famous

The following are not enough by themselves to make an SCP a map anchor: being canonical, being Safe/Euclid/Keter, appearing in a game, or being remembered easily. The procedure and site workflow must demonstrate a facility-level consequence.

The register remains deliberately short until any new candidate has received the same procedure-first evaluation used for SCP-914, SCP-500, and SCP-682.

## References

[1] [SCP Wiki — SCP-914](https://scp-wiki.wikidot.com/scp-914)  
[2] [SCP Wiki — Experiment Log 914](https://scp-wiki.wikidot.com/experiment-log-914)  
[3] [SCP Wiki — SCP-500](https://scp-wiki.wikidot.com/scp-500)  
[4] [SCP Wiki — SCP-682](https://scp-wiki.wikidot.com/scp-682)
