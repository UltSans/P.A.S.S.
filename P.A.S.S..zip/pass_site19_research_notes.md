# PASS / Site-19 Research Notes

## Scope

These notes distinguish between two kinds of source material:

1. **Foundation Wiki reference material**, used for broad concepts such as clearance, need-to-know access, personnel proximity, and facility scale.
2. **SCP: Secret Laboratory’s official wiki**, used only for a legible visual vocabulary—credentials can unlock zones, gates, chambers, lockers, and other locked areas. Its game layout and tier structure will **not** be copied into PASS.

## Initial findings

| Finding | PASS design implication | Source |
|---|---|---|
| A clearance is the maximum information access a person can be granted; it does not automatically grant every item at that level because access remains need-to-know and department-controlled. | PASS gates must check both reader authority and a sector’s approved purpose. A Level 4 reader does not automatically need a route through every protected sector. | [Security Clearance Levels — SCP Wiki](https://scp-wiki.wikidot.com/security-clearance-levels) |
| Personnel classifications describe operational proximity to anomalies. The reference treats Class A as strategically essential and kept away from anomaly areas; Class B as locally essential with limited cleared exposure; Class C as routine direct-access personnel; and Class E as exposed personnel who require quarantine and screening. | L2 should support strategic/administrative and broad medical functions, while containment contact, high-risk isolation, and exposure transfer need explicit L3/L4 boundaries. | [Security Clearance Levels — SCP Wiki](https://scp-wiki.wikidot.com/security-clearance-levels) |
| The game keycard reference states that different doors and objects need credentials with the correct access tier, and uses categories such as containment, security, and administration. | PASS can use a readable access language where a barrier separates different operating conditions. It must use the PASS permission system and original level plan rather than game-specific cards or room sequence. | [Keycard — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php?title=Keycard) |
| The Foundation Facilities reference describes Site-19 as a large, high-security facility holding hundreds of Safe and Euclid anomalies, with dedicated laboratories and storage for anomalous items that do not need individual procedures. | PASS should map Site-19 as a major operational complex with clustered functions, supporting departments, and deliberately generic capacity where individual SCP placement is not yet needed. | [Foundation Facilities — SCP Wiki](https://scp-wiki.wikidot.com/secure-facilities-locations) |
| The official game door reference names Light Doors, Heavy Doors, Checkpoints, and Gates, distinguishing them broadly by zone and scale. | These names can become a familiar but original PASS vocabulary: a light boundary controls sector access; a heavy boundary marks a high-consequence transition; checkpoints regulate recurring movement; gates define major compartment transitions. PASS will not copy the game’s speeds, locks, room sequence, or mechanics. | [Door Mechanics — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php?title=Door_Mechanics) |
| The Foundation lockdown reference frames lockdown as a variable response to security or containment compromise and emphasizes site-wide familiarity with basic procedures while reserving advanced materials for involved personnel. | PASS should model emergency barriers as context-dependent compartment controls, not as everyday movement shortcuts. The Facility Records map can identify that a boundary has an emergency-isolation role without showing tactical procedure. | [Lockdown Procedures — SCP Wiki](https://scp-wiki.wikidot.com/lockdown-procedures) |
| The expanded clearance-code resource distinguishes global, division, and local access scopes; it describes division access as an employee’s default scope inside their division and local access as specific file/document access. | PASS can make each gate evaluation understandable without inventing a second keycard system: a person needs an active credential, an appropriate standing division/sector grant, and—where relevant—a local compartment or project authorization. | [Expanded Security Clearance Codes — SCP Wiki](https://scp-wiki.wikidot.com/expanded-security-clearance-codes) |
| The official Secret Laboratory Entrance Zone reference uses gates as the large access points between an internal facility environment and the surface. | PASS can reserve the word **Gate** for a major compartment or environment transition, such as controlled surface entry/egress or the L3-to-L4 operating break, rather than using it for ordinary office or sector doors. | [Entrance Zone — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php/Entrance_Zone) |
| The Containment Breach room reference describes checkpoints as zone-separation rooms that retain keycard control after lockdown conditions are lifted. | PASS can define a **Checkpoint** as an operational boundary that verifies both normal access and whether the route is available in the current condition. PASS will not copy the game’s unlock tasks, room sequence, or particular keycard levels. | [Rooms — SCP: Containment Breach Wiki](https://scpcb.fandom.com/wiki/Rooms) |

## Design constraints emerging from the sources

The original PASS Site-19 model should use **two separate questions** at every controlled boundary:

1. Does the person have enough reader clearance and an approved personnel role for this sector?
2. Does their current task or route justify crossing the boundary?

This supports a real-facility logic: administrative authority, medical duty, maintenance access, research assignment, containment supervision, and incident response can each open different routes without pretending that a single general clearance card opens the entire site.

The game’s five names are useful because they are immediately understandable, but their meaning must be redesigned for PASS. A PASS **Checkpoint** is a staffed or monitored recurring access point, not merely a fast-closing door. A PASS **Gate** is a large compartment boundary between operating environments, such as L3-to-L4 transfer or controlled surface egress. The planned site will use no game-specific room arrangements.

The research does **not** establish one mandatory Foundation-wide gate taxonomy. The SCP setting deliberately varies by article and canon. PASS can therefore responsibly use a local, explicit taxonomy, provided it treats the game’s names as inspiration and defines each boundary by operational purpose, access authority, and emergency role.

The existing PASS dossier already has a compatible vocabulary: **departmental clearance** can describe a standing division-level role; **access categories** can represent approved sector grants; and **special permissions** can represent a local compartment, project, or asset exception. The proposal should preserve that separation rather than turn the user’s reader-clearance session into an employee’s physical keycard.

The game comparison supports a simple PASS hierarchy. **Doors** protect workspaces or individual controlled sectors. **Checkpoints** regulate repeated movement between compatible but separately supervised divisions. **Gates** mark the strongest environment transitions: surface↔internal operations, LCZ↔HCZ, egress, or deep isolation. A lockdown can change whether a checkpoint or gate is available, but does not replace the ordinary access decision.

## SCP-914 primary-source findings

| Finding | Placement consequence | Source |
|---|---|---|
| SCP-914 is kept in **research cell 109-B** with two guards on duty. Researchers entering the cell must be accompanied by at least one guard, and operators require a formal request plus Site Command approval. | SCP-914 is not compatible with open office access or casual training use. Its placement requires a dedicated controlled research cell, a standing guard post, escorted researcher access, and a command-approved operation schedule. | [SCP-914 — SCP Wiki](https://scp-wiki.wikidot.com/scp-914) |
| The machine weighs several tons, occupies about eighteen square metres, has distinct Intake and Output booths, and needs material to be moved through the sector in a controlled way. | Any location requires a purpose-built machine cell, adjacent material staging, a guarded researcher entry path, and separate intake/output handling. It cannot be treated as a small laboratory instrument. | [SCP-914 — SCP Wiki](https://scp-wiki.wikidot.com/scp-914) |
| The containment procedure prohibits biological testing. The experiment log likewise suspends biological testing absent O5 Command clearance and holds researchers accountable for output, damage, and loss of life. | The ordinary workflow is **non-biological controlled materials work**, not general training, D-Class routine, or clinical processing. Any biological exception belongs outside the normal site map and requires exceptional governance. | [SCP-914 — SCP Wiki](https://scp-wiki.wikidot.com/scp-914) [Experiment Log 914 — SCP Wiki](https://scp-wiki.wikidot.com/experiment-log-914) |
| The official game places SCP-914 in LCZ and presents its intake, operating body, and output as a dedicated containment chamber. | This supports LCZ as a familiar reference placement, but the primary procedure—not the game map—remains decisive. PASS will use the game only to reinforce that the object needs a dedicated chamber, not to dictate its location. | [SCP-914 — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php/SCP-914) |

### Preliminary conclusion — not yet a placement decision

SCP-914 can plausibly sit in a research-oriented L3 sector or, less naturally, a deeply compartmented L2 applied-research annex. It does **not** plausibly sit beside general offices, inside a medical bay, or as a routine junior-researcher training asset. The decisive placement question is whether Site-19 needs its materials intake, guard post, staging space, research support, and potential output handling closer to daily LCZ research logistics (strong L3 case) or separate from it under command/engineering control (narrow, exceptional L2 case). L4 is only justified if the site’s own operational assessment treats its output or research programme as high-consequence; the base containment procedure does not by itself establish that.

## SCP-500 primary-source findings

| Finding | Placement consequence | Source |
|---|---|---|
| SCP-500 is a small can of finite pills that cure disease when taken orally. The primary procedure requires a cool, dry, dark storage condition and limits access to Level 4 personnel to prevent misapplication. | Its risk is chiefly **custodial, ethical, and allocation-based**, not a need for a large physical containment chamber. It needs a small controlled vault environment, environmental storage, inventory accountability, and high-level release authority. | [SCP-500 — SCP Wiki](https://scp-wiki.wikidot.com/scp-500) |
| The article records denied personal-medkit requests, authorized case-specific testing, an example of theft, and a request that uses one pill with SCP-914. | Access cannot be treated as routine pharmacy dispensing. A clinical department may advise on treatment, but custody release requires a formal case-specific approval chain and a documented return/reconciliation process. | [SCP-500 — SCP Wiki](https://scp-wiki.wikidot.com/scp-500) |
| The article documents successful authorized use for severe anomalous medical conditions and notes failed synthesis attempts. | Clinical proximity is useful for consultation and controlled handoff, but scarcity means the main stock should not be kept in a general medical cabinet or be physically available at every patient-care point. | [SCP-500 — SCP Wiki](https://scp-wiki.wikidot.com/scp-500) |
| The official game presents SCP-500 as an immediately consumable medical item. | This is a gameplay simplification. PASS should retain the primary article’s controlled, scarce, case-specific custody model rather than treating SCP-500 as general medical inventory. | [SCP-500 — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php?title=SCP-500) |

### Preliminary conclusion — not yet a placement decision

The strongest default placement is a **Level 5 medical-anomalous custody vault**, not Level 2. Level 2 Comprehensive Clinical Services should hold the treatment authority, consultation function, and an emergency handoff protocol, while the main stock remains in a small L5 vault that has environmental control, dual custody, and case-specific release. A tightly controlled one-dose emergency cache near L2 clinical isolation is possible only if the user wants Site-19 to accept that custody trade-off; it should not be assumed. L3 and L4 are appropriate **treatment destinations or clinical transfer points**, not normal stock locations. This is a provisional design conclusion to test in the final synthesis.

## Medical-facility planning findings

| Finding | Site-19 medical implication | Source |
|---|---|---|
| Health-facility planning guidance treats clinical services as a set of interrelated functional units, including emergency care, inpatient care, medical imaging, laboratory, pharmacy, mental health, rehabilitation, operating/procedure units, sterilization, decontamination, and staff amenities. | A large Site-19 “medical bay” should be modeled as a **Clinical Services Division** with several sub-units, not one room. The exact capacity can stay generic while the medical, behavioural-health, diagnostic, treatment, pharmacy, and isolation functions are mapped. | [International Health Facility Guidelines — Functional Planning Units](https://www.healthfacilityguidelines.com/FPUs) |
| Isolation guidance distinguishes a protected inner patient zone from a safer outer staff zone, emphasizing containment of contaminant migration and controlled clinical work conditions. | The Site-19 medical model needs a clear split between ordinary care and high-risk isolation. L2 can host comprehensive routine care and controlled clinical isolation; L3/L4 require protected stabilization/transfer points so an unknown exposure is not taken through standard offices or waiting areas. | [CDC/NIOSH — Expedient Patient Isolation Rooms](https://www.cdc.gov/niosh/healthcare/hcp/pandemic/patient-isolation-rooms.html) |

### Medical-department principle

For Site-19, the correct name is not simply **Medical Bay** if it is large and capable. It is a **Clinical Services Division** on L2, containing routine/emergency treatment, diagnostics, pharmacy, behavioural health, psychological evaluation, rehabilitation, short-stay observation, and controlled clinical isolation. It does not replace L3/L4 clinical response rooms: those are small protected **stabilization and transfer points**, needed because a hazardous patient should not pass through ordinary clinical circulation before their condition is understood.

The division should not be treated as the default storage location for every medical SCP. Clinical professionals need authority to assess and treat patients, but scarce anomalous treatments such as SCP-500 can be held in a separate custodial vault and released under a documented patient-specific authorization.

### Proposed Site-19 Clinical Services Division — research-based working model

The user’s “medical bay” should be represented as the **Level 2 Clinical Services Division**. It is a true departmental environment, large enough to support the site but not a replacement for the custody and isolation functions that belong nearer to hazardous work.

| Sub-unit | Purpose | Correct relationship to the rest of Site-19 |
|---|---|---|
| **Clinical Intake and Acute Care** | Staff assessment, urgent treatment, resuscitation capability, short acute observation, and patient routing. | Reached from the L2 staff-access/clinical route; not an open public clinic. |
| **Diagnostics and Treatment** | Laboratory diagnostics, imaging/assessment capacity, treatment/procedure rooms, rehabilitation, and occupational-health review. | Supports the site-wide workforce. It requires ordinary clinical supply routes, not containment traffic. |
| **Behavioural Health and Psychological Evaluation** | Confidential psychiatric assessment, counselling, fitness-for-duty evaluation, post-incident support, and structured observation. | Separate from high-traffic acute care to protect privacy and avoid mixing different patient needs. |
| **Clinical Pharmacy and Controlled Medicines** | Stores and dispenses ordinary site medicines under clinical control. | Does not automatically store anomalous medical assets. It has a controlled handoff relationship to the L5 medical-anomalous vault. |
| **Clinical Isolation Annex** | Provides small controlled isolation rooms, decontamination support, secure clinical evaluation, and onward-transfer authority for patients whose condition is not yet safe for ordinary clinical circulation. | Located at the controlled edge of L2 Clinical Services, with a dedicated transfer route from L3/L4—not beside waiting, counselling, or ordinary staff care. |
| **Secure Custody Treatment Room** | Provides the clinical setting for a patient-specific use of a restricted anomalous medical asset after formal authorization. | It is a treatment environment, not the asset’s storage vault. Dosing/custody is handed over through controlled procedure. |

### Clinical routing rule

| Origin | First clinical response | Normal route after stabilization |
|---|---|---|
| **L1 / L2 ordinary staff** | L2 Clinical Intake and Acute Care. | Diagnostic, treatment, behavioural-health, observation, or discharge route inside L2. |
| **L3 LCZ incident** | L3 Clinical Response Post: immediate first aid, initial contamination/exposure assessment, controlled patient handoff. | L2 Clinical Isolation Annex if safe for transfer; otherwise remain under controlled L3/L4 direction. |
| **L4 HCZ incident** | L4 Decontamination and Clinical Isolation: stabilized in the HCZ environment first. | Only after appropriate clearance can the patient use a dedicated transfer path to L2 Clinical Isolation Annex. |
| **D-Class patient** | Custody-compatible clinical assessment route, not general staff treatment circulation. | Secure observation/treatment arrangement with custodial escort and separately managed exit. |

This model explains why L2 can legitimately be medically comprehensive while L3 and L4 still have their own limited clinical spaces. **L2 owns care; L3/L4 own safe transfer from hazardous work.**

## SCP-682 anchor finding

| Finding | Site-19 anchor consequence | Source |
|---|---|---|
| SCP-682’s procedure requires a purpose-built containment chamber, prohibits unauthorized interaction, describes frequent breach attempts, and places it at a site whose surrounding land can be kept clear of human development. | If PASS retains SCP-682 as a Site-19 anchor, it is not an ordinary HCZ cell. It needs a distinct **L4 Deep Isolation Sector** with a dedicated restricted transfer route and no routine staff, research, or service circulation. Facility Records should identify only the sector and restricted status—not physical chamber design, tactical response, or technical containment details. | [SCP-682 — SCP Wiki](https://scp-wiki.wikidot.com/scp-682) |

SCP-682 is therefore a genuine named map anchor because it changes the facility’s geometry and security boundaries. The L4 Deep Isolation Sector remains defensible, but it should be treated as a purpose-built isolated sector rather than a generic “important SCP room.”

## Foundation secrecy and facility-doctrine findings

| Finding | Level 1 implication | Source |
|---|---|---|
| The SCP Wiki describes the Foundation as a clandestine organization dedicated to containing dangerous and incomprehensible anomalies and keeping them out of public awareness. | Site-19’s surface cannot be designed as an ordinary civilian-facing facility by default. Its L1 model must privilege secrecy, control, and denial of direct public contact. | [SCP Foundation Main Page](https://scp-wiki.wikidot.com/) |
| The Foundation Facilities reference describes a world-wide network ranging from small outposts to complexes with thousands of personnel. It distinguishes Sites that are known to the public, Locations whose real purpose is disguised behind government or corporate fronts, and remote Areas unknown to the public. It also frames inconsistencies as products of compartmentalization, redaction, disinformation, anomalous influence, and database error. | A large Site-19 can credibly have a surface presence, but it does **not** need a public-facing lobby or routine visitors. Its surface model should choose among a strictly controlled known site, a minimal front with a hidden purpose, or a remote unknown area—then keep external contact tightly constrained. | [Foundation Facilities](https://scp-wiki.wikidot.com/secure-facilities-locations) |

### Corrected Level 1 premise

The Foundation does not build a surface floor for customer service. If Site-19 requires an external presence, it exists only to conceal, receive, screen, redirect, or deny. Every L1 division must support one of those functions. Public-facing office work, routine visitors, and a generic civilian campus are rejected unless a user-approved cover story makes them strictly necessary.

| Finding | Level 1 implication | Source |
|---|---|---|
| The amnestic orientation guide describes amnestics as an information-suppression tool, normally used post-incident and subject to case-by-case authority, training, and Ethics Committee oversight. | Information control does not justify a casual public interface. It reinforces the need to reduce exposure at the surface first, leaving post-incident measures as controlled exceptional activity rather than normal arrival handling. | [Amnestic Use Guide](https://scp-wiki.wikidot.com/amnestic-orientation-manual) |
| The Disinformation Bureau orientation describes the Foundation’s information-control role as protecting the public from knowledge of anomalies through cover narratives, cleanup, evidence management, and management of witnesses, with extreme measures depicted in the setting. | Site-19 needs an external-contact and evidence-control capability, but it does **not** need a customer-facing office. Any surface-facing element should be a minimal controlled interface that can manage contact, deliveries, cover consistency, and incident containment without revealing the site. | [Disinformation Bureau Orientation](https://scp-wiki.wikidot.com/disinformation-bureau-orientation) |

### Additional correction

Level 1 should not contain an in-house “civilian liaison office” open to walk-ins. The only external-contact capability it may need is a **restricted cover-control cell**: a small operational function that maintains a chosen cover, pre-clears legitimate external arrivals, coordinates legally/administratively plausible explanations, and hands any anomaly-related exposure to Foundation information-control channels. It is an access-control and containment-of-information function, not public relations.

## Surface-facility reference finding

| Finding | Original Site-19 implication | Source |
|---|---|---|
| The official Secret Laboratory Surface Zone is framed as the site’s receiving area and outermost security layer. It combines surface gates, elevator connections to the internal facility, vehicle-road access, and surface security; its text also treats locational secrecy and external-approach control as key surface concerns. | The useful concept is a **separate surface receiving/security compound with multiple controlled entrances and underground access shafts**, not the game’s exact Gate A/B, warhead, escape, tower, or combat layout. Site-19 can use distinct personnel, vehicle/freight, and air/authorized-transfer access points, each feeding a separate underground system. | [Surface Zone — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php/Surface_Zone) |

The game source reinforces an important physical answer: Level 1 exists because people, vehicles, cargo, air access, surface security, utilities, and emergency exits cannot be placed underground without a secured physical interface. PASS will keep that function while rejecting game-specific battle routes, missile/warhead mechanics, sniper structures, spawn logic, and named gates.

### Surface compound: non-negotiable physical functions

For a huge underground Site-19, Level 1 is best understood as the **surface compound and entry deck**, not as an office floor. It needs the following functions because the underground complex cannot perform them on its own:

| Surface function | Why Site-19 needs it | Correct physical form |
|---|---|---|
| **Perimeter and approach control** | The site must know who or what is approaching before it reaches a building, lift, or ventilation structure. | Restricted land boundary, monitored approach road, and controlled outer/inner access points—not a public gate. |
| **Staff entry** | Large numbers of authorized personnel must reach the underground institutional core at shift change. | Small guarded entry structure connected to secure personnel lifts for L2; it has no direct containment-level access. |
| **Vehicle/freight arrival** | Food, equipment, construction parts, technical spares, recovery containers, and routine site supplies arrive by road. | A separately gated covered vehicle inspection/transfer bay; external drivers stop at the outer handoff and cleared cargo goes to dedicated freight lifts. |
| **Custody transfer** | The Foundation needs a way to move controlled subjects or sensitive transfers without using staff or cargo paths. | A distinct secure vehicle port and internal custody connector, separated from ordinary personnel/freight movement. |
| **Air access** | A remote facility may need rapid authorized arrival, evacuation, recovery support, or limited high-priority transfer. | One controlled landing area with a small sheltered support/transfer point, located inside the secure perimeter but away from staff/freight gates; it is not a public airfield. |
| **Underground entry points** | Personnel, freight, custody, and emergency traffic have incompatible risk profiles. | Separate protected lift/shaft systems rather than one elevator chain shared by everyone. |
| **Utility interface** | An underground site still requires electrical grid/backup connection, water, communications, ventilation intake/exhaust, drainage, and access for exterior maintenance. | Low-profile hardened utility/service structures placed within the perimeter and kept distinct from entry circulation. |
| **Emergency egress** | Personnel require protected exits independent of normal gates and lifts. | Distributed sealed egress structures/shafts that surface within the controlled reservation; they are exit-only in ordinary conditions. |
| **Surface security command** | Someone must control the outer boundary, coordinate a surface response, and keep internal operations separated from an intrusion. | A restricted security post with monitoring and controlled response staging; no public counter or conventional reception. |

The resulting surface is **not a giant jail with one door** and **not a game combat arena**. It is a restricted compound whose multiple gates exist because staff, freight, custody, aircraft, utilities, and emergency escape are different operational problems. Every one of those paths stops short of the actual underground work unless it passes a separate controlled handoff.

## Level 2 candidate research: SCP-294 and SCP-261

| Asset | What the primary procedure supports | What it rules out | Initial Level 2 implication |
|---|---|---|---|
| **SCP-294** | Level 2+ personnel access; continuous Level 3 guard coverage; liquid-only outputs; a demonstrated need for security supervision. The article records its storage in a personnel break room, which shows that a supervised non-containment environment can be defensible. | It is not an unrestricted drinks machine. It can obtain dangerous liquids and extract/request information with privacy and psychological consequences. | Plausible in a controlled L2 applied-anomalies room attached to research support, with a guarded interface, request logging, restricted approved-use menu, and separate output examination. It should not be in a cafeteria or open break room in PASS. |
| **SCP-261** | Level 2+ approval; use restrictions; full transaction/time recording; Health and Safety review before consumption; security confiscation of dangerous or useful outputs. | It is not staff refreshment. It may dispense unknown, dangerous, non-consumable, or anomalous outputs—especially during unstable operation—and it can produce items that demand containment handling. | Plausible only as a scheduled, staffed **anomalous acquisition/testing station**, likely near L2 research governance and a sealed evidence handoff. It is not defensible as an ordinary vending machine or general personnel convenience. |

Both items illustrate the core Level 2 test: a familiar object can belong close to administration and research only when it becomes a **controlled work cell**, rather than a casual amenity.

## Level 2 candidate research: SCP-207 and SCP-268

| Asset | What the primary procedure supports | What it rules out | Initial Level 2 implication |
|---|---|---|---|
| **SCP-207** | Highly restricted, bio-containment-held research material; very small supervised experimental doses; high authority for non-routine use. | It is not a rapid-evacuation drink or routine personnel stimulant. The source documents severe stress, dangerous overestimation, organ failure, ruptured arteries, and death after extended effects. The game’s temporary speed effect is not a sufficient basis for PASS emergency doctrine. | **Reject the current Level 2 emergency-use proposal.** If Site-19 retains the asset, it belongs to a bio-containment research/clinical study cell with medical oversight, not a security/evacuation cabinet. |
| **SCP-268** | Extremely limited field testing after approval; the possibility of agent use was considered under review in the primary article. | It is not a researcher escape cap. Its effects can strengthen and persist, create memory/observation failures, facilitate restricted-personnel escape, and it was ultimately reported missing after a security breach. Game invisibility mechanics must not override those risks. | **Reject Level 2 emergency access.** If present at Site-19, it belongs in high-security restricted-item custody, issued only under an exceptional field-operation authorization outside ordinary site evacuation procedures. |

These two candidates demonstrate why emergency use cannot be inferred from game effects: a real site doctrine must account for the source’s adverse effects, misuse risk, accountability, and the possibility that the asset undermines the site’s own control systems.

## Level 2 candidate research: SCP-207-JP and game Anti-Cola

| Item | Primary/source status | Planning consequence |
|---|---|---|
| **SCP-207-JP** | The Japanese-branch primary article is a six-tier bookcase that generates new books from combinations of books placed on its shelves. It is a Safe object with limited, controlled generation experiments; higher-generation outputs can develop anomalous properties. It is **not** an Anti-Cola. | The user’s remembered “SCP-207-JP / Anti-Cola” combines two different things. If Site-19 ever contains SCP-207-JP, it belongs in a controlled document/language generation study cell, not an emergency-drink cabinet. It should retain its official item identifier; PASS can later add a plain-language operational label without overwriting the identifier. |
| **Anti-Cola / O-207-914** | The official Secret Laboratory page identifies Anti-Cola as a game item obtained from a cross-test of SCP-207 and SCP-914. Its regenerative / speed-reduction effects and game-specific locker/keycard mechanics are not the SCP-207-JP primary procedure. | It cannot be added to PASS as a canonical SCP-207-JP placement. If the user wants it in the local fiction, it must be documented as a **PASS-local derived experimental asset** with its own approved designation, origin record, containment, and clinical risk review—not silently treated as a canonical JP object. |

The proposed anti-cola emergency doctrine is therefore not accepted on the current evidence. Its game identity is useful inspiration, but a grounded PASS implementation would first need to decide whether it exists locally as a documented derivative at all.

## SCP-914 derivatives: verified distinction

| Result | Evidence | What PASS should conclude |
|---|---|---|
| **SCP-427, the Lovecraftian Locket** | The primary SCP-427 article states that it was created by placing a pill of SCP-500 in SCP-914 on the Fine setting. | The user is correct that a documented SCP-914 cross-test can become a distinct SCP asset. This supports a provenance model for genuine derivatives. [SCP-427](https://scp-wiki.wikidot.com/scp-427) |
| **Anti-Cola / O-207-914** | The official Secret Laboratory page identifies Anti-Cola as a rare game item and calls it an SCP-207/SCP-914 cross-test result. The primary SCP-914 experiment log establishes that researchers are accountable for outputs and that biological testing requires O5 clearance, but the accessible primary material did not establish Anti-Cola as a canonical SCP item with an SCP number. | Anti-Cola is valid **game-continuity evidence** for the idea of a 914-derived medical asset, but it should enter PASS only as a clearly labeled local derivative rather than falsely as SCP-207-JP or a canonically numbered SCP. [Experiment Log 914](https://scp-wiki.wikidot.com/experiment-log-914) [Anti-Cola — SCP: Secret Laboratory](https://en.scpslgame.com/index.php?title=Anti-Cola) |

### Evidence-based correction

The user’s larger point stands: Site-19 can reasonably have 914-derived assets and should not treat all cross-test outcomes as disposable. The required distinction is between:

1. **Canonical derivative:** a source-recognized asset such as SCP-427;
2. **Game-continuity derivative:** an item such as Anti-Cola / O-207-914; and
3. **PASS-local derivative:** an explicitly documented Site-19 output created by the user’s selected continuity.

For a grounded Site-19, a PASS-local derivative must carry its parent inputs, 914 setting, output date/batch, observed effects, clinical risk decision, custody location, and release authority. This preserves the user’s idea while avoiding false canon claims.

### Containment Breach implementation check

The available SCP: Containment Breach SCP-914 reference documents the game’s variable output system and lists SCP-427 and SCP-500 among associated items, supporting the user’s recollection that the game uses 914-derived objects such as the locket. However, the accessible source did **not** document Anti-Cola as a vanilla SCP-207 output, and focused searching did not produce an original-Containment-Breach source for that claim. PASS should therefore not state that Anti-Cola is in both games as a verified fact. The honest status is: **verified in Secret Laboratory; unverified for vanilla Containment Breach; potentially present in a remaster, mod, or remembered derived-item context.** [SCP-914 — SCP: Containment Breach Wiki](https://scpcb.fandom.com/wiki/SCP-914)

## Secret Laboratory access concepts adapted for PASS

The official Secret Laboratory Keycard material separates containment, security, administrative, and unique access cases. Its Heavy Containment material links restricted checkpoints and locked chambers with security equipment, response tools, and high-consequence operations. These are useful concepts, but **not a map to copy**.

PASS should retain only the transferable ideas:

| Game concept | PASS-local adaptation |
|---|---|
| Different access categories can coexist on one credential. | Separate **Research Authority**, **Security Authority**, and assignment-based **Facility Access**. |
| Lower/mid-tier armories and lockers appear in operating zones. | Each Site-19 level may contain security-rated rooms or containers; their required S-level depends on the asset and incident consequence, not solely on the level. |
| Research/containment rooms and checkpoints may need different credentials. | A PASS facility gate can require Facility Access plus Research Authority, Security Authority, or both, depending on the division’s purpose. |
| Heavy containment brings stronger restricted equipment and response resources. | L4 normally hosts higher S-level response/control capability, while L2/L3 can hold appropriate low-to-mid security resources. |
| A keycard is not just a job title. | The PASS dossier must keep role, rank, information authority, physical route access, and special restrictions separate. |

Source boundaries: [Secret Laboratory Keycard](https://en.scpslgame.com/index.php?title=Keycard) and [Heavy Containment Zone](https://en.scpslgame.com/index.php/Heavy_Containment_Zone) inform only broad access vocabulary. PASS deliberately retains its own five-level site, divisions, routes, authorities, and content-free Facility Records model.

## Correction: clearance as seniority and trust

The primary Foundation clearance material supports the user’s core principle that clearance is strongly associated with seniority, trusted responsibility, and need-to-know, but it does not provide a universal department-by-department rank ladder. It describes Level 2 as common among research/security personnel with direct operational data needs, Level 3 among senior research/security personnel and response teams, Level 4 among site/security directors and commanders, and Level 5 among the highest administration. It also stresses that clearance alone does not provide every file or physical area; active need-to-know and local scope remain material. [Security Clearance Levels](https://scp-wiki.wikidot.com/security-clearance-levels) [Expanded Security Clearance Codes](https://scp-wiki.wikidot.com/expanded-security-clearance-codes)

For PASS, the user-defined research progression overrides any attempt to copy that source ladder:

| Research Clearance | PASS position |
|---|---|
| 1 | Junior Researcher |
| 2 | Research Assistant |
| 3 | Researcher |
| 4 | Senior Researcher |
| 5 | Site Director |

The task is therefore **not** to create a second R1–R5 authority ladder. It is to create an equally readable, PASS-local **Security Clearance 1–5 seniority progression** for security staff, then combine each person’s department clearance with their assigned Site-19 division/route. The external sources guide principles—seniority, compartmentalization, and need-to-know—but do not dictate the PASS department titles.

## User-supplied Security rank reference video

The user supplied [a video reference](https://youtu.be/H4va2F3Oynw). Its analysed rank sequence is: Cadet; Junior Guard; Security Officer; Senior Security Officer; Corporal/Sergeant; Lieutenant; Captain; Security Chief. The video ties the early ranks to fixed-post and door watch, Security Officer to breach response and D-Class escort, Senior Officer to high-risk patrol and mentorship, Corporal/Sergeant to fire-team leadership, Lieutenant to shift command/local lockdown, Captain to site-wide security management, and Security Chief to Security Department leadership reporting to the Site Director.

The video itself notes that this is a rigid military hierarchy and not a universal SCP canon. Its useful value for PASS is the **duty escalation**—post duty → independent officer → specialist/veteran → team/shift command → site security leadership—not any claim that every Foundation site uses the exact titles or powers. The user specifically prefers a more interesting hierarchy than the rejected generic draft and suggested Security Guard, Senior Security Guard, Operative/MTF Operative, Security Director, and an unresolved Level 5 as useful directions.

## Second user-supplied clearance reference

The second video, [Msw3kQAlbj0](https://youtu.be/Msw3kQAlbj0), reinforces a useful general principle: clearance, role, rank, and physical access are related but not identical. It presents checkpoints, D-Class custody, testing areas, armories, and safe/lockdown locations as contexts in which a person’s clearance is checked. It also presents MTF as specialist deployment personnel rather than ordinary site guards.

However, its exact claims—such as a universal Level 2 guard, Level 3 researcher, and Level 4 Site Director—would conflict with the user-defined PASS approach and must not be copied. PASS retains the stronger rule that the same five clearance numbers express **seniority, trust, responsibility, and need-to-know within the person’s relevant department or site command structure**, while assignment and division access determine the actual location or gate. The video’s specific emergency-phone, mortality, and universal rank claims are treated as video-specific, not as PASS requirements.

## Sources consulted

1. [Security Clearance Levels — SCP Wiki](https://scp-wiki.wikidot.com/security-clearance-levels)
2. [Keycard — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php?title=Keycard)
3. [Foundation Facilities — SCP Wiki](https://scp-wiki.wikidot.com/secure-facilities-locations)
4. [Door Mechanics — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php?title=Door_Mechanics)
5. [Lockdown Procedures — SCP Wiki](https://scp-wiki.wikidot.com/lockdown-procedures)
6. [Expanded Security Clearance Codes — SCP Wiki](https://scp-wiki.wikidot.com/expanded-security-clearance-codes)
7. [Entrance Zone — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php/Entrance_Zone)
8. [Rooms — SCP: Containment Breach Wiki](https://scpcb.fandom.com/wiki/Rooms)
9. [SCP-914 — SCP Wiki](https://scp-wiki.wikidot.com/scp-914)
10. [Experiment Log 914 — SCP Wiki](https://scp-wiki.wikidot.com/experiment-log-914)
11. [SCP-500 — SCP Wiki](https://scp-wiki.wikidot.com/scp-500)
12. [International Health Facility Guidelines — Functional Planning Units](https://www.healthfacilityguidelines.com/FPUs)
13. [CDC/NIOSH — Expedient Patient Isolation Rooms](https://www.cdc.gov/niosh/healthcare/hcp/pandemic/patient-isolation-rooms.html)
14. [SCP-914 — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php/SCP-914)
15. [SCP-500 — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php?title=SCP-500)
16. [SCP-682 — SCP Wiki](https://scp-wiki.wikidot.com/scp-682)
17. [SCP Foundation Main Page](https://scp-wiki.wikidot.com/)
18. [Foundation Facilities](https://scp-wiki.wikidot.com/secure-facilities-locations)
19. [Amnestic Use Guide](https://scp-wiki.wikidot.com/amnestic-orientation-manual)
20. [Disinformation Bureau Orientation](https://scp-wiki.wikidot.com/disinformation-bureau-orientation)
21. [Surface Zone — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php/Surface_Zone)
