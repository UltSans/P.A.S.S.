# PASS External Organizations & Affiliations Proposal

**Status:** Proposed for approval; no app changes included in this document.

## Purpose

PASS should recognize the wider SCP setting without pretending that all external groups are Foundation departments, without importing canonical SCP files, and without filling the user’s blank registry with unwanted profiles. The correct addition is a compact **External Organizations & Affiliations** reference layer. It would make records more believable when an incident, document, Project, team, or person involves a known outside group.

> **Core principle:** A Foundation Team is a user-created operational unit. An external organization is a controlled reference subject. Neither category grants reader clearance, creates personnel, or changes the user’s local records automatically.

The SCP Wiki itself describes Groups of Interest as organizations that possess, use, or attempt to create anomalous objects, with relationships ranging from rival to splinter group to associate.[1] This supports a reference layer rather than a single “enemy list.”

## Necessary corrections to the supplied list

Several items in the supplied material should **not** be added as separate, equal organizations.

| Supplied item | PASS treatment | Reason |
|---|---|---|
| **UNGOI** | Alias of the **Global Occult Coalition** | The official GOC page uses “United Nations Global Occult Coalition”; PASS should store this as an alias, not duplicate it.[2] |
| **Wanderer’s Library** | Location / knowledge network, not an organization | It is a place associated with the Serpent’s Hand, but the Hand does not directly control it.[4] |
| **Mekhane sects** | Subgroups under Church of the Broken God | Broken Church, Cogwork Orthodoxy, and Maxwellism are denominations or related movements, not generic duplicate GoIs.[1] |
| **Sarkic-affiliated biotech collectives** | User-created or source-specific subgroups | “Sarkic” describes broad traditions with Proto- and Neo-Sarkic strands; generic unnamed biotech collectives should not be invented as canonical entities.[9] |
| **GOC R&D branches / UIU divisions** | Internal-unit metadata, not global organizations | They should only exist inside a named external organization when the user needs a specific unit. |
| **East Asian bureaus / MI13 / NSA divisions** | Optional source-variant entries | They are not one single stable shared catalog. PASS should not flatten canon variants into asserted fact. |

This is important because the SCP setting has no universal canon. The UIU’s own hub explicitly notes changing interpretations and author freedom,[8] while the Chaos Insurgency hub documents conflicting histories and interpretations.[3] PASS should preserve that uncertainty instead of silently choosing one canon.

## Recommended catalog: three reference tiers

PASS should not load every group ever written. The initial database should contain a restrained **Core Reference Catalog**, an **Expansion Catalog** hidden by default, and a **User-Created / Variant** catalog.

| Tier | Purpose | Initial contents |
|---|---|---|
| **Core reference** | Most useful for ordinary Foundation documents, personnel history, and incident reports. | Chaos Insurgency; Global Occult Coalition; Horizon Initiative; FBI Unusual Incidents Unit; Serpent’s Hand; Marshall, Carter & Dark; Prometheus Labs; Anderson Robotics; Are We Cool Yet?; Dr. Wondertainment; Church of the Broken God; Sarkic Traditions; Fifth Church; GRU Division “P”. |
| **Expansion reference** | Useful when a record specifically needs a broader setting connection. | Wilson’s Wildlife Solutions; Gamers Against Weed; Alexylva University; Three Moons Initiative; Wanderer’s Library; Church of Maxwellism. |
| **User-created / variant** | Prevents PASS from falsely asserting one canon. | User-defined organizations, national agencies, regional branches, individual cults, named cells, divisions, and setting-specific groups. |

The catalog uses **organization type** rather than simplistic moral labels. A small classification system would be more operationally credible:

| Organization type | Examples | Typical PASS use |
|---|---|---|
| **Anomalous governance / treaty body** | GOC; Horizon Initiative | Liaison notes, jurisdiction conflicts, joint operations. |
| **State investigative or intelligence body** | FBI UIU; GRU Division “P” | Jurisdiction, evidence custody, surveillance, legacy material. |
| **Breakaway or hostile network** | Chaos Insurgency | Security incident, compromise, theft, infiltration, or claim of responsibility. |
| **Commercial or research supplier** | MC&D; Prometheus Labs; Anderson Robotics; Dr. Wondertainment | Procurement trail, recovered product, laboratory provenance, commercial interface. |
| **Civil / activist / cultural network** | Serpent’s Hand; AWCY?; Gamers Against Weed | Public exposure, liberation activity, anart, online distribution, source attribution. |
| **Religious or ideological tradition** | Church of the Broken God; Sarkic traditions; Fifth Church; Horizon Initiative | Ritual materials, ideological motive, community contact, expert review. |
| **Extradimensional institution or location** | Alexylva University; Wanderer’s Library; Three Moons Initiative | Origin, access point, correspondence, restricted research context. |

This classification reflects the published material without forcing all groups into “enemy” status. For example, MC&D is a commercial broker in anomalous goods,[5] Anderson Robotics is a paratechnology firm,[6] the UIU is an FBI unit for paranormal-related crime,[8] and the Serpent’s Hand is a decentralized movement rather than a conventional hierarchy.[4]

## How PASS should use the catalog

### Database: external organization reference

Add **Database → External Organizations** as a read-only reference index. Each short record should contain only:

| Field | Behavior |
|---|---|
| Name and aliases | Example: “Global Occult Coalition” with “United Nations Global Occult Coalition” as an alias. |
| Type | One of the controlled types above. |
| PASS reference posture | `Known`, `Legacy`, `Disputed`, `Variant-specific`, or `User-created`. |
| Neutral operational summary | One or two PASS-authored sentences; no copied article text. |
| Relevant record contexts | Personnel affiliation, incident subject, document provenance, Project stakeholder, or site/interface note. |
| Source note | Optional link to an official hub and an attribution note. |

The page should contain **no live personnel roster, tactical deployment detail, or imported stories**. It is a vocabulary and context system, not a second SCP Wiki.

### Personnel: relationship, not automatic membership

Personnel dossiers should gain an optional fixed **Affiliation & Service Relationship** section. It must not replace Department, Personnel Class, Clearance, or keycard access.

| Field | Controlled values |
|---|---|
| Primary service relationship | Foundation staff; seconded liaison; external contact; person of interest; former affiliate; detained subject; unknown. |
| Associated organization | Optional catalog selection or user-created entity. |
| Relationship status | Cooperative; monitored; adverse; restricted contact; historical; unknown. |
| Disclosure basis | Verified record; self-reported; intelligence assessment; unverified allegation. |

This lets a dossier record an external liaison or former affiliation without falsely changing their Foundation access. A selected organization provides **context only**; it never grants a role, clearance, zone, or permission.

### Teams: preserve the user’s internal structures

The five groups supplied by the user—SCP Research Team, Investigation Task Force, SCP Anomaly Response Unit, Omega Research Unit Task Force, and SCP Containment & Analysis Group—should become **user-created Foundation Teams**, not additions to the external catalog.

PASS should eventually add two optional Team fields:

| Field | Use |
|---|---|
| **Operational posture** | Research; investigation; response; analysis; containment support; liaison. |
| **External interface** | Optional organization links only when a Team regularly coordinates with or monitors a group. |

The names, leaders, members, and roles in the user’s notes remain their own local data. PASS should not pre-create them, because the user explicitly wants a blank registry.

### Documents and Entries: subject, provenance, and confidence

An Entry should be able to name one or more organizations using three optional metadata fields:

| Field | Why it matters |
|---|---|
| **Organizations referenced** | Makes a report searchable without trying to infer names from prose. |
| **Information role** | Subject; source; claimant; counterparty; affected party; mentioned only. |
| **Confidence** | Confirmed; corroborated; assessed; disputed; alleged; unknown. |

This is especially necessary for groups with multiple canon interpretations. A document can say “Chaos Insurgency — alleged responsibility” instead of treating an uncertain claim as settled fact. The Insurgency hub itself emphasizes contradictory source material,[3] and the Sarkicism hub distinguishes multiple traditions and practices.[9]

### Incidents and Projects: external involvement without bias

Incident Reports should replace any future informal “outside actor” text with a structured repeatable link:

| Field | Values |
|---|---|
| External organization | Controlled catalog or user-created entry. |
| Involvement type | Suspected actor; confirmed actor; claimant; victim; partner; observer; source; unknown. |
| Operational relationship | Adversarial; cooperative; neutral; disputed; unresolved. |
| Evidence status | Confirmed; corroborated; preliminary; unverified. |

Projects should use a lighter **External Stakeholders** link for liaison, monitoring, recovery, negotiated access, provenance study, or counter-intelligence. No external organization should expose restricted record links to a lower-clearance reader.

## Data and access rules

The implementation should add a small immutable catalog and optional local extensions:

```text
OrganizationReference
  id, displayName, aliases[], organizationType
  catalogTier, referencePosture, shortSummary
  sourceUrl?, sourceLabel?, isUserCreated

OrganizationRelationship
  organizationId, role, confidence, relationshipStatus
  note?
```

The core catalog would be visible at **Level 1**, because it contains only short context. Operational notes, personnel links, Documents, Incidents, Projects, and any user-created intelligence remain protected by the existing record-level clearance rules. This ensures that universe recognition does not become a clearance bypass.

## What PASS should deliberately not do

PASS should not import canonical SCP pages, pre-populate the user’s blank local registry with characters or documents, present its reference catalog as a single canon, automatically identify organizations from document text, or model real-world state agencies as if every canon agrees on their anomalous branches. It should also avoid classifying every group as hostile. The GOC, UIU, and Horizon Initiative can be competitors, contacts, or counterparts depending on the record; the app should describe a relationship at the level of evidence available.[2] [7] [8]

## Recommended implementation order

I recommend a narrow first release, then an approval gate before every expansion.

| Stage | Scope |
|---|---|
| **1. Reference foundation** | Database index, 14 Core entries, aliases, short source-attributed reference cards, search and type filters. |
| **2. Operational links** | External organization relationships in Incident Reports, Projects, and Entries with evidence/confidence labels. |
| **3. Personnel and Teams** | Optional affiliation/service relationship in personnel; optional operational posture and external interface in Teams. |
| **4. Expansion and custom entities** | User-created groups, regional branches, historical variants, and the Expansion catalog. |

This sequence improves the current app immediately without making a blank registry feel pre-filled or turning PASS into an encyclopedia.

## Approval requested

Before implementation, please decide whether to approve this scope with these defaults:

1. Add a **Core 14** external-organization catalog in Database while keeping the user’s SCP, Personnel, Teams, Entries, Projects, and Incident Reports blank.
2. Treat **UNGOI as a GOC alias**, the **Wanderer’s Library as a location/resource**, and organizational subsects or regional agencies as variants rather than separate asserted canon.
3. Start with **Incident Reports, Projects, and Entries**; add Personnel and Team affiliation fields only in the next controlled stage.

## References

[1]: https://scp-wiki.wikidot.com/groups-of-interest "SCP Wiki — Groups of Interest"
[2]: https://scp-wiki.wikidot.com/goc-hub-page "SCP Wiki — Global Occult Coalition Casefiles"
[3]: https://scp-wiki.wikidot.com/chaos-insurgency-hub "SCP Wiki — Chaos Insurgency Hub"
[4]: https://scp-wiki.wikidot.com/serpent-s-hand-hub "SCP Wiki — Serpent’s Hand Hub"
[5]: https://scp-wiki.wikidot.com/marshall-carter-and-dark-hub "SCP Wiki — Marshall, Carter and Dark Hub"
[6]: https://scp-wiki.wikidot.com/anderson-robotics-hub "SCP Wiki — Anderson Robotics Hub"
[7]: https://scp-wiki.wikidot.com/horizon-initiative-hub "SCP Wiki — Horizon Initiative Hub"
[8]: https://scp-wiki.wikidot.com/unusual-incidents-unit-hub "SCP Wiki — Unusual Incidents Unit Hub"
[9]: https://scp-wiki.wikidot.com/sarkicism-hub "SCP Wiki — Sarkicism Hub"
[10]: https://scp-wiki.wikidot.com/prometheus-labs-hub "SCP Wiki — Prometheus Labs Hub"
