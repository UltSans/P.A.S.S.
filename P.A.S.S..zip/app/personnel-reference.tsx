import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";

import { Eyebrow, Panel, palette } from "@/components/registry-ui";
import { ScreenContainer } from "@/components/screen-container";
import {
  PERSONNEL_DEPARTMENT_REFERENCE,
  PERSONNEL_POSITION_REFERENCE,
  SITE19_PERSONNEL_ID_FORMAT,
  SITE19_PERSONNEL_ID_RULE,
} from "@/lib/personnel-reference";
import { PERSONNEL_DEPARTMENT_SUGGESTIONS, PERSONNEL_POSITION_GROUPS } from "@/lib/foundation-vocabulary";

type ReferenceRow = { id: string; type: "heading" | "item"; label: string; summary?: string; guidance?: string };

const referenceRows: ReferenceRow[] = [
  { id: "department-heading", type: "heading", label: "DEPARTMENTS" },
  ...PERSONNEL_DEPARTMENT_SUGGESTIONS.map((label) => ({ id: `department-${label}`, type: "item" as const, label, summary: PERSONNEL_DEPARTMENT_REFERENCE[label]?.summary, guidance: PERSONNEL_DEPARTMENT_REFERENCE[label]?.use })),
  ...PERSONNEL_POSITION_GROUPS.flatMap((group) => [
    { id: `position-heading-${group.label}`, type: "heading" as const, label: group.label },
    ...group.options.map((label) => ({ id: `position-${label}`, type: "item" as const, label, summary: PERSONNEL_POSITION_REFERENCE[label]?.summary, guidance: PERSONNEL_POSITION_REFERENCE[label]?.use })),
  ]),
];

export default function PersonnelReferenceScreen() {
  const router = useRouter();
  return (
    <ScreenContainer className="flex-1" containerClassName="bg-[#11100F]">
      <View style={styles.topbar}>
        <Pressable onPress={() => router.back()} style={styles.back}><MaterialCommunityIcons name="arrow-left" color={palette.ink} size={21} /></Pressable>
        <View><Eyebrow>REFERENCE / PERSONNEL</Eyebrow><Text style={styles.topTitle}>Personnel Reference</Text></View>
      </View>
      <FlatList
        data={referenceRows}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={<View style={styles.header}><Text style={styles.title}>Choose a role with a reason.</Text><Text style={styles.detail}>Department describes the person’s broad work area. Position or Rank describes their actual duty. Both suggestion lists are editable local starting points: select one, change it, or type a completely new value.</Text><Panel style={styles.idPanel}><Eyebrow>PERSONNEL ID</Eyebrow><Text style={styles.idFormat}>{SITE19_PERSONNEL_ID_FORMAT}</Text><Text style={styles.idDetail}>{SITE19_PERSONNEL_ID_RULE}</Text></Panel><Panel style={styles.rulePanel}><MaterialCommunityIcons name="information-outline" size={18} color={palette.blue} /><Text style={styles.ruleText}>Personnel Class, Department, Position/Rank, Departmental Clearance, Division Assignment, and Facility Access answer different questions. Do not use one field to stand in for another.</Text></Panel></View>}
        renderItem={({ item }) => item.type === "heading" ? <Text style={styles.heading}>{item.label}</Text> : <Panel style={styles.item}><Text style={styles.itemTitle}>{item.label}</Text><Text style={styles.summary}>{item.summary}</Text><Text style={styles.guidance}>{item.guidance}</Text></Panel>}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  topbar: { paddingHorizontal: 20, paddingTop: 8, flexDirection: "row", alignItems: "center", gap: 12 },
  back: { height: 52, width: 52, borderRadius: 4, backgroundColor: palette.panelRaised, borderColor: palette.line, borderWidth: 1, justifyContent: "center", alignItems: "center" },
  topTitle: { color: palette.ink, fontSize: 21, fontWeight: "900", marginTop: 2 },
  content: { padding: 20, paddingBottom: 42, gap: 10 },
  header: { gap: 10, marginBottom: 8 },
  title: { color: palette.ink, fontSize: 27, lineHeight: 33, fontWeight: "900", letterSpacing: -0.4 },
  detail: { color: palette.slate, fontSize: 13, lineHeight: 20 },
  idPanel: { gap: 7, backgroundColor: "#211A18", borderColor: "#64312C" },
  idFormat: { color: palette.ink, fontSize: 17, fontWeight: "900", letterSpacing: 1.1 },
  idDetail: { color: palette.slate, fontSize: 12, lineHeight: 18 },
  rulePanel: { flexDirection: "row", gap: 9, padding: 12, backgroundColor: "#191817" },
  ruleText: { color: palette.slate, fontSize: 12, lineHeight: 18, flex: 1 },
  heading: { color: palette.blue, fontSize: 10, fontWeight: "900", letterSpacing: 1.1, marginTop: 12, marginBottom: 1 },
  item: { gap: 7, padding: 14 },
  itemTitle: { color: palette.ink, fontSize: 15, fontWeight: "900" },
  summary: { color: palette.slate, fontSize: 13, fontWeight: "700", lineHeight: 19 },
  guidance: { color: palette.muted, fontSize: 12, lineHeight: 18 },
});
