# PASS Keycard System Review — Assessment Only

## Scope and conclusion

This review evaluates the **existing** PASS personnel and keycard model. It proposes no app changes. The current design is already a strong Foundation-style **personnel dossier** because it separates personnel classification, department, position, departmental authority, access categories, special permissions, restrictions, credential status, and auditable entries. That separation is much more grounded than assigning everything from a person’s job title or a single clearance number.

The important limitation is that PASS currently describes access well, but it does not yet express a fully enforceable **authorization model**. In particular, its zone list is partly derived from clearance level while its access categories and exceptions are free-text lists. This creates an unresolved question: if two fields disagree, which one actually decides whether a door opens?

> **Assessment:** Keep the core personnel dossier. Do not replace it with a generic “Level 1–5 keycard” system. If PASS is later expanded, add narrow authorization metadata and a single access-decision rule rather than additional vague permission fields.

## What PASS already does correctly

| Existing PASS element | Why it is grounded | Assessment |
|---|---|---|
| **Personnel Class A–E** | It records exposure/operational status rather than rank or job title. The SCP Wiki likewise treats personnel classifications as proximity to anomalous hazards, separate from security clearance. [1] | Correct separation. Retain it. |
| **Department and position** | It explains the person’s work assignment without pretending it grants universal access. | Correct separation. Retain it. |
| **Departmental clearance** | It recognizes that an employee can need deeper access within their own division than elsewhere. The SCP clearance-code resource describes different global, division, and local scopes. [2] | Good concept, but currently only free text. |
| **Access categories** | It provides a place for physical zones such as laboratories or containment zones. | Correct concept, but needs a defined zone vocabulary if it later enforces access. |
| **Special permissions** | It supports project-specific, system-specific, and anomaly-specific authorization. | Correct concept, but needs authority, purpose, and expiry data. |
| **Restrictions** | It supports explicit denials, which is essential for least privilege. NIST defines least privilege as granting only the minimum resources and authorizations required for a function. [3] | Correct concept. Restrictions should override ordinary grants. |
| **Active / Restricted / Suspended credential status** | It models the possibility that a card state changes independently of job title. | Sound basis, but it lacks expiry/revocation and review metadata. |
| **Personnel Entries** | It can preserve an auditable history of changes. | Strong basis for approval and recertification history. |
| **Reader clearance at launch** | It is explicitly separated from a personnel profile’s keycard. | Correct: reader clearance governs what the user may see in PASS, not which physical door a fictional employee may enter. |

## The central problem: two competing access rules

PASS currently contains two competing ideas:

| Current mechanism | What it implies | Risk if treated as enforcement |
|---|---|---|
| **Clearance-to-zone helper** | A Level 2, 3, 4, or 5 clearance automatically adds progressively more physical zones. | Information clearance can silently become broad physical access. A Level 3 research specialist could appear to gain a containment corridor even without a specific work assignment. |
| **Access categories and special permissions** | Physical access is explicitly assigned per person and can be restricted. | This is closer to a realistic keycard model, but it has no formal precedence rule or structured approval metadata. |

The SCP Wiki is clear that a clearance level represents the highest **information** access that may be granted; it does not automatically provide all information at that level because access remains need-to-know. [1] The expanded clearance-code resource makes the same point more explicitly: an employee’s global, division, and local access may differ, and a low-ranked field agent can have deeper access to their specific work than a senior administrator. [2]

PASS should follow that principle. **Document clearance, physical zone access, and project access must remain separate.** A high clearance should make a person eligible for a request; it should not by itself open every door.

## Gaps to address only if the keycard system becomes active

| Gap | Why it matters | Minimal future control |
|---|---|---|
| **No authoritative decision rule** | A profile can show a clearance level, a zone list, a special permission, and a restriction with no stated precedence. | Define one evaluation order: credential status → explicit restriction → valid temporary grant → approved standing zone grant → deny. |
| **Free-text zone names** | “Laboratories”, “Security Areas”, and “Light Containment Zone” can overlap or be entered inconsistently. | Create a controlled zone catalog with stable identifiers and readable labels. |
| **No compartment / project grant** | A researcher needs access to an assigned SCP file or project without receiving the entire department’s authority. | Add project or record grants distinct from general department clearance. |
| **No expiry or review** | A temporary assignment can become permanent by accident. NIST access-management guidance includes disabling accounts that expire, are inactive, no longer belong to a user, or present significant risk. [4] | Add a review date and optional expiration to every exceptional grant. |
| **No recorded authority** | The current special-permissions list cannot identify who approved it or on what basis. | Add approver, purpose, and supporting Entry reference for exceptional grants. |
| **No conditional entry rule** | High-value, quarantined, or hazardous personnel may need escorted or time-limited access instead of a flat grant/deny outcome. | Add access conditions: unescorted, escort required, emergency-only, or medical hold. |
| **No emergency logic** | Breach response requires controlled exception handling, but unrestricted “emergency access” would undermine the model. | Treat emergency overrides as scoped, time-bound, logged, and later reviewed—not as a normal standing permission. |

## Recommended PASS access model

The following is the smallest model that would make PASS feel operational without turning the app into a complicated enterprise security product.

| Layer | Question it answers | Examples | Rule |
|---|---|---|---|
| **Credential state** | Is the credential usable at all? | Active, Restricted, Suspended, Revoked, Expired | A non-active state blocks ordinary access. |
| **Identity and assignment** | Who is the person and what is their normal duty context? | Personnel class, department, position, site | Context informs approval; it does not itself grant a door. |
| **Information scope** | What documentation may they read? | Global, division, project/SCP clearance | Need-to-know and the file’s own requirement remain decisive. |
| **Standing physical grants** | Which routine locations can they enter? | Staff commons, research wing, LCZ, armory | Zone catalog plus explicit grants. |
| **Compartment grants** | Which project, chamber, system, or archive is specially authorized? | SCP-049 chamber, SCP-914 chamber, Project Atlas lab | Narrow purpose-bound grants. |
| **Conditions and restrictions** | Under what limits may access occur? | Escort required, no armory, medical hold, daytime only | Explicit restrictions override grants. |
| **Temporary authority** | What unusual access exists and when does it stop? | Incident response, maintenance, temporary project duty | Requires approver, purpose, start/end, and review. |
| **Audit trail** | Why did a grant change? | Personnel Entry, approval reference, periodic review | Every exceptional or changed permission has an Entry. |

This is an attribute-based approach: the decision uses attributes of the requester, the protected location or record, and the current conditions rather than relying on one rank number. NIST defines attribute-based access control as authorization based on attributes of subjects, objects, and environment conditions combined through policy. [5]

## PASS decision rule

If PASS later simulates a door or document decision, use the following sequence. This is more realistic than simply comparing two clearance numbers.

1. **Is the credential active?** If it is suspended, revoked, expired, or in medical hold, deny ordinary access.
2. **Does an explicit restriction apply?** A restriction overrides an ordinary grant unless a separately recorded emergency procedure applies.
3. **Is there a valid time-bound exceptional authorization?** It must match the site, zone or system, purpose, and date range.
4. **Is there an approved standing zone or compartment grant?** If yes, allow under its stated conditions.
5. **Does the person meet the required information scope and need-to-know?** This governs database records, not a physical door by itself.
6. **Otherwise, deny and record the request if it is operationally significant.**

## What should not be changed

The following choices are already correct and should not be removed:

| Keep | Reason |
|---|---|
| **Class A–E separate from job and clearance** | It represents exposure and protection policy, not a permission tier. |
| **Reader clearance separate from personnel keycard data** | The user’s PASS session is a database-reading credential, not the employee profile they are viewing. |
| **Free-text containment/SCP exceptions as a display surface** | It is useful for narrative detail, provided the app later gives it structured approval metadata rather than treating text as executable access logic. |
| **Personnel Entries for changes** | It gives PASS the audit history a real security system needs. |

## Practical recommendation

Your current model should be described as **“good and deliberately incomplete.”** It is a convincing Foundation dossier now. It should only become more structured if you want PASS to answer questions such as “Can this person enter this chamber right now?” or “Why was this exception granted?”

The best next increment would therefore be **not** a wholesale redesign. It would be a small, focused **Keycard Authorization Layer**: controlled zone names, standing grants, exceptional grants with expiry/approver, conditions, and a documented precedence rule. If you do not want PASS to simulate actual door decisions, then the existing human-readable model is already sufficient and should simply gain a short Guide explanation of the distinction between clearance and access.

## References

[1] [SCP Wiki — Security Clearance Levels](https://scp-wiki.wikidot.com/security-clearance-levels)  
[2] [SCP Wiki — Expanded Security Clearance Codes](https://scp-wiki.wikidot.com/expanded-security-clearance-codes)  
[3] [NIST CSRC — Least Privilege](https://csrc.nist.gov/glossary/term/least_privilege)  
[4] [NIST SP 800-171 Rev. 3 — Account Management](https://nvlpubs.nist.gov/nistpubs/SpecialPublications/800-171r3/NIST.SP.800-171r3.html)  
[5] [NIST CSRC — Attribute-Based Access Control](https://csrc.nist.gov/glossary/term/attribute_based_access_control)
