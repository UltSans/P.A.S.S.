# PASS Terminal, Database, Script Library, and Site-19 Proposal

## Recommendation

The proposed direction is strong, with two changes of emphasis:

1. **Terminal should stop creating records.** It should be a secure operational gateway, not a generic dashboard with duplicate creation buttons.
2. A TTF manager should be named for what it currently does. **Script Library** is a better immediate name than **Communicator**. “Communicator” should be held for a future dispatch, radio, message, or intercom system.

This proposal makes no app changes. It defines a small, coherent information architecture for approval.

## Terminal after restructuring

| Terminal element | Purpose | Recommended action |
|---|---|---|
| **Operating state** | Retain the current session clearance, record count, credential count, and task-group summary. | Keep. It is useful situational awareness. |
| **Database** | Open controlled reference material rather than live SCP or personnel registries. | Add. |
| **Script Library** | Manage reusable typefaces for Entry documents. | Add. |
| **Create SCP file** | Creation belongs in the Anomalies registry. | Remove from Terminal; retain the contextual create action in Anomalies. |
| **Register personnel** | Creation belongs in the Personnel registry. | Remove from Terminal; retain the contextual create action in Personnel. |
| **PASS Guide** | It should be part of the reference database rather than a loose Terminal shortcut. | Move into Database. |

The resulting Terminal is deliberately plain: it reports the site’s state and gives the operator two systems to enter. That is closer to an internal secure terminal than a consumer-app home page.

## Database structure

The Database should use a compact index. It does not need decorative cards; it needs clear sections and disciplined separation of information.

| Database section | Contents | Existing PASS material that moves here |
|---|---|---|
| **Reference Manuals** | Reader clearance, personnel classes, keycard/access model, Entry folders, document handling. | PASS Guide sections. |
| **Classification Manual** | Full PASS classification framework, decision flow, specialist terminology, terminal escalation. | Existing Classification Manual. |
| **Facility Records** | Site-19 overview, five-level site plan, controlled-zone information, route legend. | New. |
| **Protocol Index** | Future place for access-control rules, emergency procedures, and site-specific protocols. | New but initially empty or marked unavailable. |

This solves a current organizational problem: guides, classifications, and facility material are all reference data, but they do not answer the same question and should not be placed in one long scrolling guide.

## Script Library, not Communicator

The Typefaces feature is an archive utility. Its function is to import, list, identify, and safely reuse fonts in Entry blocks and exports. Calling it **Communicator** makes a user expect messages, broadcasts, radio traffic, logs, or calls. It is the wrong word for a typeface registry.

| Option | Assessment |
|---|---|
| **Script Library** | Recommended. It covers constructed scripts, typefaces, recovered writing, and language documents without overstating the feature. |
| **Typeface Registry** | Most precise, but more technical and less immersive. |
| **Document Systems** | Acceptable if the section later includes templates, export rules, and archival metadata. |
| **Communicator** | Reserve for a future communication/dispatch module. Do not use for fonts alone. |

The Script Library’s first scope should be intentionally narrow:

| Action | Required behavior |
|---|---|
| **Import typeface** | Select a local `.ttf` or `.otf`, validate it, copy it into PASS local storage, and register it once. |
| **Inspect** | Show family name, file name, format, import date, and number of Entry blocks that reference it. |
| **Preview** | Render a fixed sample string and a user-entered sample string without changing any document. |
| **Delete** | Require confirmation. Never delete Entry Unicode text; affected blocks revert to Foundation Standard and display an unavailable-typeface note. |

## Site-19: five-level facility map

The five-level model is credible **as your own PASS Site-19 facility model**. It should not be presented as a fixed universal SCP Wiki floor plan. The official facility overview describes Site-19 as a large, high-security site holding hundreds of Safe and Euclid anomalies, with dedicated laboratories and storage for anomalous items; it does not prescribe a universal five-level map. [1] The Wiki explicitly allows inconsistencies across facilities as results of compartmentalization, redaction, disinformation, anomalous influence, and database errors. [1]

> **Recommendation:** label it `SITE-19 / PASS FACILITY PLAN / LOCAL CONFIGURATION`. This makes it grounded: the map is the plan for this PASS continuity, not a claim that every SCP author must use it.

### Proposed operational role of each level

| Level | Your concept | Recommended operational definition |
|---|---|---|
| **Level 1** | Surface | Public cover, vehicle control, delivery screening, loading, surface security, and controlled staff arrival. This is the interface between the site and the outside world. |
| **Level 2** | Administrative Area | Administration, records, internal briefing rooms, HR, finance, basic medical triage, staff services, and secure but non-anomalous support functions. |
| **Level 3** | Light Containment Zone | Low-to-moderate containment, routine research, approved interview rooms, quarantine staging, laboratories, and tightly controlled Class C personnel movement. |
| **Level 4** | Heavy Containment Zone | High-risk containment suites, tactical security staging, advanced medical response, redundant containment systems, and limited escorted access. |
| **Level 5** | Heavy Storage Zone | Deep storage, inert/packaged anomalous-item vaults, high-security archive caches, critical infrastructure, and low-traffic logistics. This level should not be a generic “more dangerous Level 4”; it is a separate storage and isolation function. |

I would preserve your name **Heavy Storage Zone**, but add “Deep Storage & Critical Infrastructure” as its internal subtitle. This explains why it is physically lower without claiming every item stored there is more immediately dangerous than an item in Level 4.

### Non-negotiable map rules for realism

| Rule | Reason |
|---|---|
| Every boundary between Level 2→3, 3→4, and 4→5 has a named checkpoint or vestibule. | The map must reflect access-control transitions, not only walls. |
| Every below-surface level has a staff route, secure/service route, and emergency egress concept. | A deep facility cannot operate with one elevator and one hallway. |
| Level 3 and Level 4 are separated by security and pressure/containment controls, not merely a label. | Light and heavy containment must have operationally meaningful separation. |
| Level 5 has restricted logistics access and does not serve as a shortcut between other levels. | Deep storage should reduce traffic, not create a convenient bypass route. |
| The first map is a **schematic floor plan**, not an artistic 3D render. | Functional layout, checkpoints, rooms, and routes are more useful than appearance. |

## What must be decided before building the map

You said you already have ideas for Site-19. The correct next step is not to invent the rooms. PASS needs your basic site brief first:

| Needed decision | Examples |
|---|---|
| **Site cover and geography** | Industrial plant, warehouse, research campus, remote underground complex, military property. |
| **Vertical circulation** | Main staff lift, secure freight lift, emergency stair cores, tunnel/vehicle access. |
| **Core departments by level** | Whether medical belongs mostly at Level 2, 3, or both; whether records remain at Level 2 or have a secured archive below. |
| **Containment distribution** | Which anomaly types or hazards belong in Light, Heavy, and Deep Storage. |
| **Security architecture** | Checkpoint names, guard posts, access zones, lockdown boundaries, and evacuation routes. |
| **Map sensitivity** | Whether a reader’s clearance level should hide Level 4/5 detail or show only a redacted outline. |

## Recommended staged implementation

| Stage | Deliverable | Requires another approval? |
|---|---|---|
| **1** | Restructure Terminal: replace duplicate creation buttons with Database and Script Library destinations. | Yes. |
| **2** | Build Script Library: import, preview, usage count, and safe deletion rules. | Yes. |
| **3** | Build Database index: Reference Manuals, Classification Manual, Facility Records, Protocol Index. | Yes. |
| **4** | Draft a text-first Site-19 room and route specification from your site brief. | Yes. |
| **5** | Build the 2D schematic map with level switching and clearance-aware detail. | Yes. |

This sequence keeps the project practical. It avoids prematurely drawing a map that later contradicts your actual Site-19 design.

## References

[1] [SCP Wiki — Foundation Facilities](https://scp-wiki.wikidot.com/secure-facilities-locations)
