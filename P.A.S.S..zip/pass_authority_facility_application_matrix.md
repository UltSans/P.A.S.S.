# PASS / Authority-to-Facility Application Matrix

## Rule before every entry

Every row below assumes the person already has **Facility Access** to the named division/zone and an active duty, work order, clinical transfer, incident assignment, or custody purpose. Research and Security Authority do not create a route by themselves.

## Research Authority in Site-19

| Research authority | Normal facility context | What it can authorize after Facility Access | What stays separately controlled |
|---|---|---|---|
| **R1** | L2 Personnel Readiness & Operations Control; approved L2 controlled-work observation; defined L3 research support. | Supervised research orientation, approved low-sensitivity documentation, escorted observation, and non-contact assistance. | Testing interfaces, independent experiment initiation, restricted outputs, and containment work. |
| **R2** | L2 Controlled Applied Anomalies; L3 Research, Analysis & Interview Division. | Routine assigned research work, standard research rooms, designated lower-risk test interfaces, ordinary research files, and supervised benefit/utility studies. | New test approval, unrelated containment clusters, high-consequence outputs, L4 specialist work. |
| **R3** | L3 Research/Analysis/Interview; selected L3 containment-support interfaces. | Lead approved L3 research, access restricted research records within assignment, supervise R1/R2 work, authorize standard work in a designated programme. | L4 research, terminal records, custody release, L5 restricted storage. |
| **R4** | L4 Specialist Research & Observation; L5 restricted research archive on defined assignment. | Specialist high-risk research, L4 observation interfaces, multi-division programme leadership, restricted methodological systems. | Deep Isolation, Omega, unrelated L5 custody, all L4 divisions. |
| **R5** | L2 Site Command, L4 specialist governance, L5 secure archive/critical custody by explicit appointment. | Strategic research review, terminal research records, exceptional methodology, cross-site/project authority. | Any room, container, security system, or contingency mechanism without Facility Access and the other required authority. |

## Security Authority in Site-19

| Security authority | Normal facility context | What it can authorize after Facility Access | What stays separately controlled |
|---|---|---|---|
| **S1** | L1 Perimeter/Personnel Access; L2 Operations Control; assigned local security posts. | Basic duty lockers, perimeter and personnel-control stations, local alarms, standard post equipment. | L3 custody, armory issue, restricted containers, heavy gate, HCZ response stores. |
| **S2** | L3 LCZ Entry & Operations Control; L3 Custody Processing; L3 Shift Support security post. | LCZ armory/equipment issue, custody escort controls, standard response stores, local checkpoint operation. | Heavy containers, L4 gate control, high-consequence equipment, deep custody. |
| **S3** | L3 Materials/Service Intake security interfaces; L3 restricted stores; L4 HCZ Transition Control. | Heavy security containers, enhanced response stores, controlled heavy-gate post operation, supervised restricted equipment issue. | L4 response command, Deep Isolation controls, L5 critical custody, strategic contingency assets. |
| **S4** | L4 Containment Response Support; L4 HCZ service/security control; defined L5 custody handoff. | L4 response equipment, high-consequence security systems, HCZ post command, secured transfer/custody supervision. | Omega action, unrestricted L5 vault access, research authority, site-wide route access. |
| **S5** | L2 incident/command authority; L5 critical custody and contingency controls by appointment. | Strategic security oversight, rare deep-custody approvals, contingency security authorization, S4 review. | Unrecorded use of force, unrestricted research, medical decision-making, or bypassing Facility Access. |

## Facility-level pattern

| Level | Research pattern | Security pattern | Facility Access role |
|---|---|---|---|
| **L1** | Research is exceptional: R1/R2 may use controlled arrival or project transfer only. | S1 runs normal perimeter/access; S2 may supervise custody/transfer security. | Separates personnel, freight, custody, air, and service movement before it reaches the underground site. |
| **L2** | R1–R3 support controlled applied work; R4/R5 govern specialist/strategic work by assignment. | S1 protects local entry/operations posts; S2/S3 can access designated secure rooms/containers. | Gives staff access to their L2 division; it does not let them pass the L3 Light Gate without assignment. |
| **L3** | R2 is normal research work; R3 leads assigned programmes; R4 appears only on defined specialist work. | S2 controls normal LCZ security, custody, and armories; S3 controls restricted containers/heavy equipment and the L4 transition post. | Governs entry from the Light Gate and separates containment, research, custody, shift support, and freight zones. |
| **L4** | R4 is the normal threshold for specialist research; R5 oversees strategic/terminal decisions. | S3 controls the Heavy Gate and restricted issue; S4 directs high-consequence response/security. | Keeps the HCZ a deliberate assignment-only environment, not a route that a high R/S level may casually enter. |
| **L5** | R4/R5 can access defined secure archive or specialist records only by explicit assignment. | S3/S4 cover controlled custody and logistics handoff; S5 covers strategic critical custody/contingency security. | Restricts movement to scheduled logistics, custody, archive, and maintenance routes; L5 remains no shortcut. |

## Examples of combined requirements

| Controlled interface | Requirement pattern | Reason |
|---|---|---|
| L2 controlled research work cell | Facility Access to `S19-L2-05` + R2 or above + approved work order. | The person must reach the annex, understand the work, and be assigned to the activity. |
| L3 security-rated armory room | Facility Access to the L3 security zone + S2 or above + active security duty. | The room supports the LCZ security post, not every employee. |
| L3 heavy security container | Facility Access to the host zone + S3 or above + logged issue purpose. | The container is more restricted than its surrounding division. |
| L4 Heavy Gate control console | Facility Access to `S19-L4-01` + S3 or above + active transition post. | A gate is a security operation, not merely a pass-through door. |
| L4 specialist research interface | Facility Access to `S19-L4-04` + R4 or above + specialist assignment. | High research authority does not turn into general HCZ access. |
| L5 restricted custody issue | Facility Access to `S19-L5-02` + relevant R/S authority + named custody release. | No single level opens scarce/critical custody by itself. |

## What this makes possible

The matrix lets PASS eventually explain a realistic profile without one oversized clearance number. For example, an employee can be **R2 / S1** with L2 and L3 research routes; a custody supervisor can be **R1 / S3** with L3 custody and L4 transition-post duty; and a clinician can have no R/S authority but the correct L2 Clinical Services Facility Access and professional assignment. The map, the keycard, and the person’s actual job now reinforce each other rather than contradicting one another.
