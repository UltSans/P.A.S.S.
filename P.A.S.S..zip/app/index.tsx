import { useEffect, useRef, useState } from "react";
import { useRouter } from "expo-router";
import { Alert, Animated, Easing, Image, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { palette } from "@/components/registry-ui";
import { ScreenContainer } from "@/components/screen-container";
import { haptic } from "@/lib/haptics";
import { useSession, type Designation } from "@/lib/session-store";
import { CLEARANCE_LEVELS, type ClearanceLevel } from "@/lib/registry-types";

const designations: Designation[] = ["Dr.", "Researcher", "Agent", "SCP-", "O5-", "Administrator"];

export default function EntryScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { stage, profile, hydrated, showCredential, requestAccess, finishAuthorization } = useSession();
  const [form, setForm] = useState(profile);
  const [designationPickerOpen, setDesignationPickerOpen] = useState(false);
  const designationSheetBottomInset = Math.max(insets.bottom, 28) + 44;

  useEffect(() => setForm(profile), [profile]);
  useEffect(() => {
    if (!hydrated || stage !== "booting") return;
    const timer = setTimeout(showCredential, 1700);
    return () => clearTimeout(timer);
  }, [hydrated, showCredential, stage]);
  useEffect(() => {
    if (stage !== "authorizing") return;
    const timer = setTimeout(() => { finishAuthorization(); router.replace("/(tabs)" as never); }, 1550);
    return () => clearTimeout(timer);
  }, [finishAuthorization, router, stage]);

  if (!hydrated || stage === "booting") return <BootScreen />;
  if (stage === "authorizing") return <AuthorizationScreen profile={profile} />;
  if (stage === "authorized") return <BootScreen />;

  const submit = () => {
    if (!form.name.trim()) {
      haptic.warning();
      Alert.alert("Identity required", "Enter a name before requesting access.");
      return;
    }
    haptic.success();
    requestAccess({ ...form, name: form.name.trim() });
  };

  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="flex-1" containerClassName="bg-[#11100F]"><View style={styles.credentialScreen}><View style={styles.credentialHeader}><View style={styles.headerMark}><MaterialCommunityIcons name="shield-key-outline" color={palette.blue} size={17} /></View><Text style={styles.headerText}>PASS / ACCESS TERMINAL</Text></View><View style={styles.credentialContent}><Text style={styles.eyebrow}>PERSONNEL ACCESS & SITE SECURITY</Text><Text style={styles.credentialTitle}>Identity verification</Text><Text style={styles.credentialDetail}>Confirm the credential presented for this registry session.</Text><View style={styles.formCard}><View style={styles.fieldBlock}><Text style={styles.fieldLabel}>PERSONNEL DESIGNATION & NAME</Text><View style={styles.identityLine}><Pressable accessibilityRole="button" accessibilityLabel="Select personnel designation" onPress={() => setDesignationPickerOpen(true)} style={styles.designationSelect}><Text style={styles.selectedDesignation} numberOfLines={1}>{form.designation}</Text><MaterialCommunityIcons name="chevron-down" color={palette.blue} size={18} /></Pressable><TextInput value={form.name} onChangeText={(name) => setForm((current) => ({ ...current, name }))} placeholder="Enter name" placeholderTextColor="#8D857B" style={styles.nameInput} autoCapitalize="words" returnKeyType="done" onSubmitEditing={submit} /></View></View><View style={styles.divider} /><View style={styles.fieldBlock}><Text style={styles.fieldLabel}>CLEARANCE LEVEL</Text><View style={styles.clearanceRow}>{CLEARANCE_LEVELS.map((level) => <Pressable key={level} onPress={() => { haptic.light(); setForm((current) => ({ ...current, clearanceLevel: level })); }} style={[styles.clearance, form.clearanceLevel === level && styles.clearanceActive]}><Text style={[styles.clearanceNumber, form.clearanceLevel === level && styles.clearanceNumberActive]}>{level.replace("Level ", "")}</Text><Text style={[styles.clearanceLabel, form.clearanceLevel === level && styles.clearanceLabelActive]}>LVL</Text></Pressable>)}</View></View></View><Pressable android_ripple={{ color: "rgba(255,255,255,0.16)" }} onPress={submit} style={styles.accessButton}><MaterialCommunityIcons name="lock-open-variant-outline" size={18} color="#FFF7EE" /><Text style={styles.accessButtonText}>ACCESS REGISTRY</Text></Pressable><Text style={styles.localNote}>Credential details are retained locally for your next entry.</Text></View><Text style={styles.footer}>SECURE NODE / LOCAL DEVICE AUTHORIZATION</Text><Modal transparent visible={designationPickerOpen} animationType="fade" onRequestClose={() => setDesignationPickerOpen(false)}><View style={[styles.modalBackdrop, { paddingBottom: designationSheetBottomInset }]}><Pressable style={styles.dismissArea} onPress={() => setDesignationPickerOpen(false)} /><View style={styles.designationSheet}><View style={styles.sheetHeader}><Text style={styles.sheetLabel}>SELECT DESIGNATION</Text><Pressable accessibilityRole="button" accessibilityLabel="Close designation selector" onPress={() => setDesignationPickerOpen(false)} style={styles.sheetClose}><MaterialCommunityIcons name="close" color={palette.ink} size={20} /></Pressable></View><ScrollView style={styles.designationScroll} contentContainerStyle={styles.designationGrid} showsVerticalScrollIndicator={false} nestedScrollEnabled>{designations.map((item) => <Pressable key={item} accessibilityRole="button" onPress={() => { haptic.light(); setForm((current) => ({ ...current, designation: item })); setDesignationPickerOpen(false); }} style={[styles.sheetItem, form.designation === item && styles.sheetItemActive]}><Text style={[styles.sheetItemText, form.designation === item && styles.sheetItemTextActive]}>{item}</Text>{form.designation === item ? <MaterialCommunityIcons name="check" color={palette.blue} size={18} /> : null}</Pressable>)}</ScrollView></View></View></Modal></View></ScreenContainer>;
}

function BootScreen() {
  const scale = useRef(new Animated.Value(0.94)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const scan = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.parallel([
      Animated.timing(scale, { toValue: 1, duration: 780, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      Animated.timing(opacity, { toValue: 1, duration: 650, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      Animated.loop(Animated.sequence([Animated.timing(scan, { toValue: 1, duration: 900, useNativeDriver: true }), Animated.timing(scan, { toValue: 0, duration: 900, useNativeDriver: true })])),
    ]).start();
  }, [opacity, scale, scan]);
  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="flex-1" containerClassName="bg-[#11100F]"><View style={styles.boot}><Animated.View style={[styles.bootContent, { opacity, transform: [{ scale }] }]}><View style={styles.iconHalo}><Image source={require("@/assets/images/icon.png")} style={styles.logo} /><Animated.View style={[styles.scanLine, { opacity: scan }]} /></View><Text style={styles.bootProduct}>PERSONNEL ACCESS & SITE SECURITY</Text><Text style={styles.bootStatus}>INITIALIZING SECURE TERMINAL</Text></Animated.View><View style={styles.bootFooter}><View style={styles.bootProgress}><View style={styles.progressFill} /></View><Text style={styles.bootFooterText}>PASS NODE 19.06 · ENCRYPTED LINK ESTABLISHED</Text></View></View></ScreenContainer>;
}

function AuthorizationScreen({ profile }: { profile: { designation: string; name: string; clearanceLevel: ClearanceLevel } }) {
  const config = {
    "Level 1": { name: "PERSONNEL ACCESS", detail: "General administrative and records access verified.", accent: palette.green, code: "AUTH-01" },
    "Level 2": { name: "RESEARCH ACCESS", detail: "Working research files and supervised records authorized.", accent: palette.blue, code: "AUTH-02" },
    "Level 3": { name: "CONTAINMENT ACCESS", detail: "Containment operations and classified research channels authorized.", accent: palette.amber, code: "AUTH-03" },
    "Level 4": { name: "SITE COMMAND", detail: "Command-restricted operational records authorized.", accent: "#C96E63", code: "AUTH-04" },
    "Level 5": { name: "OVERSIGHT ARCHIVE", detail: "Oversight-restricted archive path authorized.", accent: "#D5B46A", code: "AUTH-05" },
  }[profile.clearanceLevel];
  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="flex-1" containerClassName="bg-[#11100F]"><View style={styles.authorization}><View style={[styles.authorizationCircle, { borderColor: config.accent }]}><MaterialCommunityIcons name="shield-check-outline" color={config.accent} size={54} /></View><Text style={styles.authorizationCode}>{config.code} · {profile.clearanceLevel.toUpperCase()}</Text><Text style={styles.authorizationTitle}>{config.name}</Text><Text style={styles.authorizationName}>{profile.designation} {profile.name}</Text><Text style={styles.authorizationDetail}>{config.detail}</Text><View style={[styles.authorizationRule, { backgroundColor: config.accent }]} /></View></ScreenContainer>;
}

const styles = StyleSheet.create({
  boot: { flex: 1, backgroundColor: palette.canvas, padding: 28, justifyContent: "space-between" }, bootContent: { flex: 1, alignItems: "center", justifyContent: "center", marginTop: 12 }, iconHalo: { height: 256, width: 256, borderRadius: 128, borderColor: "#54312D", borderWidth: 1.5, justifyContent: "center", alignItems: "center", overflow: "hidden", backgroundColor: "#171514" }, logo: { height: 238, width: 238, resizeMode: "contain" }, scanLine: { position: "absolute", left: 0, right: 0, height: 2, backgroundColor: palette.blue, shadowColor: palette.blue, shadowOpacity: 1, shadowRadius: 12 }, bootProduct: { color: palette.ink, fontSize: 15, fontWeight: "900", letterSpacing: 1.7, marginTop: 28, textAlign: "center" }, bootStatus: { color: palette.muted, fontSize: 11, fontWeight: "800", letterSpacing: 1.2, marginTop: 10 }, bootFooter: { gap: 12 }, bootProgress: { height: 3, backgroundColor: "#332F2B", overflow: "hidden" }, progressFill: { height: "100%", width: "72%", backgroundColor: palette.blue }, bootFooterText: { color: "#A29A8C", fontSize: 9, fontWeight: "800", letterSpacing: 0.8, textAlign: "center" },
  credentialScreen: { flex: 1, backgroundColor: palette.canvas, paddingHorizontal: 26, paddingVertical: 24, justifyContent: "space-between" }, credentialHeader: { flexDirection: "row", alignItems: "center", gap: 10 }, headerMark: { height: 36, width: 36, borderRadius: 3, backgroundColor: "#3B1D1A", justifyContent: "center", alignItems: "center" }, headerText: { color: palette.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 }, credentialContent: { gap: 18, marginBottom: 8 }, eyebrow: { color: palette.blue, fontSize: 10, fontWeight: "900", letterSpacing: 1.4 }, credentialTitle: { color: palette.ink, fontSize: 36, fontWeight: "900", letterSpacing: -0.8, lineHeight: 43, marginTop: -10 }, credentialDetail: { color: palette.muted, fontSize: 16, lineHeight: 23, marginTop: -9 }, formCard: { backgroundColor: palette.panel, borderColor: palette.line, borderWidth: 1, borderRadius: 3, padding: 20, gap: 20 }, fieldBlock: { gap: 12 }, fieldLabel: { color: palette.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1 }, identityLine: { minHeight: 62, borderBottomColor: palette.line, borderBottomWidth: 1, flexDirection: "row", alignItems: "center", gap: 10 }, designationSelect: { flexDirection: "row", alignItems: "center", gap: 4, paddingRight: 6, minHeight: 52, maxWidth: "55%" }, selectedDesignation: { color: palette.blue, fontSize: 20, fontWeight: "900", flexShrink: 1 }, nameInput: { color: palette.ink, fontSize: 20, flex: 1, minWidth: 0, paddingVertical: 9 }, divider: { height: 1, backgroundColor: palette.line }, clearanceRow: { flexDirection: "row", gap: 8, justifyContent: "space-between" }, clearance: { flex: 1, minHeight: 68, borderRadius: 3, borderWidth: 1, borderColor: palette.line, backgroundColor: "#141312", justifyContent: "center", alignItems: "center", gap: 2 }, clearanceActive: { backgroundColor: "#3B1D1A", borderColor: "#7A2A26" }, clearanceNumber: { color: palette.muted, fontSize: 23, fontWeight: "900" }, clearanceNumberActive: { color: palette.blue }, clearanceLabel: { color: "#A29A8C", fontSize: 8, fontWeight: "900", letterSpacing: 0.6 }, clearanceLabelActive: { color: "#E2B1A8" }, accessButton: { minHeight: 62, borderRadius: 4, backgroundColor: "#A8332E", borderWidth: 1, borderColor: "#D15B54", elevation: 2, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10 }, accessButtonText: { color: "#FFF7EE", fontSize: 14, fontWeight: "900", letterSpacing: 1 }, localNote: { color: "#A29A8C", fontSize: 11, lineHeight: 16, textAlign: "center", marginTop: -5 }, footer: { color: "#A29A8C", fontSize: 9, letterSpacing: 0.9, fontWeight: "800", textAlign: "center" },
  modalBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.78)", padding: 14 }, dismissArea: { ...StyleSheet.absoluteFillObject }, designationSheet: { position: "relative", backgroundColor: palette.panelRaised, borderColor: "#6D4A44", borderWidth: 1, borderRadius: 4, padding: 12, maxHeight: "72%", elevation: 8 }, sheetHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingLeft: 8, marginBottom: 8 }, sheetLabel: { color: palette.muted, fontSize: 10, letterSpacing: 1, fontWeight: "900" }, sheetClose: { height: 40, width: 40, borderWidth: 1, borderColor: palette.line, borderRadius: 3, justifyContent: "center", alignItems: "center" }, designationScroll: { maxHeight: 320 }, designationGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, paddingBottom: 2 }, sheetItem: { width: "48.6%", minHeight: 58, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 3, borderWidth: 1, borderColor: palette.line, backgroundColor: "#141312" }, sheetItemActive: { backgroundColor: "#3B1D1A", borderColor: "#9D3E38" }, sheetItemText: { color: palette.slate, fontSize: 15, fontWeight: "900" }, sheetItemTextActive: { color: palette.blue },
  authorization: { flex: 1, backgroundColor: palette.canvas, alignItems: "center", justifyContent: "center", paddingHorizontal: 34, gap: 14 }, authorizationCircle: { height: 160, width: 160, borderRadius: 80, borderWidth: 2.5, justifyContent: "center", alignItems: "center", backgroundColor: "#1B1715", marginBottom: 12 }, authorizationCode: { color: palette.muted, fontSize: 11, fontWeight: "900", letterSpacing: 1.3 }, authorizationTitle: { color: palette.ink, fontSize: 30, lineHeight: 36, fontWeight: "900", letterSpacing: 0.4, textAlign: "center" }, authorizationName: { color: palette.blue, fontSize: 16, fontWeight: "800", textAlign: "center" }, authorizationDetail: { color: palette.muted, fontSize: 16, lineHeight: 23, textAlign: "center", marginTop: 5 }, authorizationRule: { width: 100, height: 4, borderRadius: 0, marginTop: 16 }, pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});
