# PASS / Keycard Authority & Route Assessment

## Current PASS foundation

PASS already has the fields needed to express a realistic model: department, position, departmental clearance, access categories, special permissions, restrictions, role, division, site, information clearance, access status, and authorized zones. The Site-19 route map gives those fields a physical meaning. The system should be clarified, not replaced by one generic card level.

## The proposed separation

| Dimension | Question it answers | Proposed form | Why it stays separate |
|---|---|---|---|
| **Research Authority** | What anomalous research, testing, documentation, and research compartment work may this person perform or read? | A defined authority level aligned to the personnel record’s research/information clearance. | A researcher can be trusted with a particular class of research without being a guard, armory user, or universal gate holder. |
| **Security Authority** | What weapons, response equipment, security posts, custody controls, and tactical response functions may this person use? | A defined security authority level or role-bound security grant. | Security authority concerns force and response responsibility, not scientific work or every building route. |
| **Facility Access** | Which specific divisions, zones, gates, lift families, and routes may this person physically use? | Explicit division/zone grants, route grants, access conditions, and restrictions. | It is the actual physical door decision. It must not be a single universal “Access Clearance” number. |
| **Clinical Authorization** | Which clinical tasks, patient data, controlled medication, isolation, and patient-transfer functions may this person perform? | Qualification-and-assignment model plus narrow special permissions. | Medicine is professional scope of practice, not a general site-power ladder. |

## Recommendation on “Access Clearance”

The user’s current idea is correct in purpose but the name and form should change. **Do not keep a numbered “Access Clearance” category.** Rename it to **Facility Access** and model it as a list of physical grants:

| Facility Access element | Example |
|---|---|
| **Site** | Site-19 only, or temporary multi-site assignment. |
| **Division grant** | `S19-L3-03 Research, Analysis & Interview Division`. |
| **Zone grant** | `S19-L3-03-B` only. |
| **Route grant** | Personnel Core, Clinical Transfer Core, Freight Core, or Heavy Access Core. |
| **Condition** | Unescorted, escort required, work-order-only, incident-only, or medical hold. |
| **Restriction** | Explicit denial that overrides a grant. |

This is more realistic than hiding every gate inside Research or Security. A researcher may have high Research Authority but only L2/L3 Facility Access. A security officer may have strong Security Authority but no L2 records grant. A maintenance engineer may have service-core access without a research or armory grant.

## Recommendation on medical authority

There is no strong reason to create a generic **Medical Clearance Level 1–5**. The site instead needs a clinical professional model:

| Clinical element | How PASS should express it without a new numbered ladder |
|---|---|
| Routine clinical work | Department: Clinical Services; position/qualification; L2 Clinical Services facility grant. |
| Patient record access | Clinical assignment plus need-to-know and record scope. |
| Clinical isolation | L2-03-D division/zone grant and relevant infection/exposure training. |
| Controlled medication or medical-anomalous custody | Narrow special permission with authority, purpose, and audit record. |
| Protected L3/L4 patient retrieval | Clinical Transfer Core route grant plus current assignment/incident authority. |

This respects why medical does not appear as a generic game clearance: clinicians need controlled professional authority, but not a broad numerical power scale equivalent to research or security.

## Decision model at a gate or controlled system

The physical decision should be read in this order:

1. **Credential status:** is it Active rather than Restricted or Suspended?
2. **Explicit restriction:** does a restriction deny this person now?
3. **Facility Access grant:** does the person have this division, zone, or route under its required condition?
4. **Role and assignment:** are they on normal duty, a valid work order, a clinical transfer, or an authorised incident task?
5. **Research, Security, or Clinical authority:** if this division’s task requires a professional authority, does the person hold it?
6. **Special permission:** does a narrower compartment or temporary authorization apply?

No one attribute overrides the rest. This turns the existing keycard dossier into an understandable system that fits the Site-19 routes without making the app simulate every door immediately.
