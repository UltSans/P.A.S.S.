# PASS / Site-19 — Master Operating Plan

## Status and design premise

**Discussion draft only.** This is a PASS-local reimagining of Site-19 as a real, operating Foundation installation. It replaces the earlier sparse sector list with a working model of how people, patients, materials, records, containment assets, and authority move through the site.

It does not claim to be a canonical floor plan or reproduce any external game layout. It uses the fixed five-level structure selected for PASS:

| Level | Fixed identity | Core question it answers |
|---|---|---|
| **L1** | Surface | How does the site control the outside world before anything reaches operations? |
| **L2** | Administration | How does the site run as an institution without routine containment contact? |
| **L3** | Light Containment Zone | How does the site sustain daily lower-risk containment, research, custody, and shift work? |
| **L4** | Heavy Containment Zone | How does the site isolate high-consequence operations and response capability? |
| **L5** | Heavy Storage Zone | How does the site keep long-hold assets, critical systems, and rare-use material controlled? |

> **A level is not a theme. It is a working environment with a mission, compatible traffic, support needs, boundaries, and defined exceptions.**

## Whole-site operating model

Site-19 is organized around five kinds of work that must coexist without being mixed carelessly: **governance**, **people and healthcare**, **research and containment**, **logistics and maintenance**, and **incident isolation**. The five levels separate those conditions while still permitting authorized connections.

| Operating system | Main home | Where it must connect | What cannot be assumed |
|---|---|---|---|
| **Governance and records** | L2 | Every division through controlled information and authorization channels. | Database access does not create physical access. |
| **Routine staff care** | L2, with L3 shift support | All staffed levels through approved clinical and welfare routes. | A general clinic is not an exposure-isolation unit. |
| **Daily containment and research** | L3 | L2 approval/briefing, L4 specialist isolation, L5 controlled storage. | “Low risk” does not mean unrestricted traffic. |
| **High-consequence containment** | L4 | L3 heavy-gate transfer, restricted response, clinical stabilization, critical utilities. | HCZ cannot be a shortcut between lower levels. |
| **Long-hold storage and infrastructure** | L5 | Screened logistics, maintenance, and purpose-limited retrieval. | Storage clearance does not provide general site authority. |

The Master Plan is deliberately more detailed than a list of four cards per level, but it remains a **facility map**, not a tactical plan. PASS will ultimately show functions, boundaries, routes, access posture, and administrative context—not chamber blueprints, weapon procedures, vulnerabilities, or response instructions.

---

## L1 — Surface Operations and Controlled Entry

### Mission

L1 protects the boundary between Site-19 and the outside world. It maintains the site cover, receives people and deliveries, verifies identity, screens what enters, and prevents public or unscreened movement from reaching the underground facility.

### Divisions

| Division | What it does | Who works there | Why it is on L1 | Key boundary |
|---|---|---|---|---|
| **Cover Operations Division** | Maintains the civilian-facing identity, approved public-facing work, controlled appointments, and outward site appearance. | Cover staff, reception personnel, selected administrators. | It is the layer through which ordinary outside contact is managed. | Internal Access Door into the secure arrival system; no public route continues below L1. |
| **Personnel Arrival & Screening Division** | Processes scheduled staff arrival, approved visitors, credential verification, personal-item control, and entry screening. | Access-control officers, security staff, arrival personnel. | Every person must be resolved before they enter the internal site environment. | Controlled Door to the L2 staff-access hub; visitors move only under escort. |
| **Vehicle, Receiving & Freight Division** | Receives deliveries, inspects vehicles, separates ordinary supplies from controlled material, and hands cleared freight to the logistics system. | Logistics staff, vehicle inspectors, security personnel. | Freight needs vehicle access and screening before it reaches any lower-level work area. | Logistics-only Controlled Door and freight lift; no personnel shortcut through receiving. |
| **Surface Security & Perimeter Division** | Monitors the perimeter, manages surface incidents, and controls protected external access points. | Surface security, communications liaison, response support. | Perimeter security must remain close to the area it protects. | Separate security route; does not merge with public reception or L2 offices. |
| **External Training Annex Interface** | Connects Site-19 administratively to the separate Foundation-controlled security academy, range, or secure training annex. It handles assignments, qualification records, and authorized transport—not drills. | Training administration, security coordination, transport liaison. | Security recruit training must be external, but assignments and qualification control still need a Site-19 handoff. | Information and scheduled transport interface only; no internal weapons training floor. |

### L1 logic

L1 is not merely “the surface.” It is a succession of decisions: whether a person is expected, whether an item is permitted, which internal route is justified, and whether anything needs to be turned away before it enters the site. Personnel, visitors, freight, and perimeter security are adjacent only where coordination requires it; they do not share uncontrolled circulation.

---

## L2 — Administration, Clinical Services, and Controlled Applied Work

### Mission

L2 runs Site-19 as an institution and supports staff who do not require routine containment contact. It contains leadership, records, personnel administration, broad clinical care, assignment preparation, security administration, and carefully justified controlled anomalous applications that are compatible with a low-anomaly-contact environment.

### Divisions

| Division | What it does | Who works there | Why it is on L2 | Key boundary |
|---|---|---|---|---|
| **Command & Site Coordination Division** | Houses the Site Director’s office, executive workrooms, secure meetings, department coordination, and an incident-coordination function. | Site Director, department heads, authorized coordination staff. | Leadership needs central information access without being embedded in a containment zone. | Controlled Door; incident coordination is not tactical staging. |
| **Personnel, Credentials & Records Division** | Maintains personnel files, posting, access review, credential administration, document routing, redaction review, and PASS-style records operations. | Personnel officers, credential staff, records officers. | These functions serve the whole site but require privacy and stable administrative access. | Controlled doors between personnel/credentials and records work; database authority does not create sector access. |
| **Clinical Services Division** | Provides broad physical medicine, mental-health and psychological care, diagnostics, treatment, rehabilitation, pharmacy control, and routine occupational health. | Physicians, nurses, psychologists, psychiatrists, diagnostics and pharmacy staff. | The site’s primary general clinical capability should be accessible before workers enter containment shift routes. | Clinical controlled doors and patient privacy zones; active anomalous exposure is stabilized through controlled L3/L4 points before transfer. |
| **Briefing, Policy & Assignment Division** | Handles orientation administration, pre-shift briefing, policy refreshers, approved meetings, access briefings, and post-incident administrative debriefs. | Assigned staff, supervisors, policy personnel. | Staff need a place to prepare for controlled work that is neither an office corridor nor a containment checkpoint. | Internal access boundary; it is not a drill floor or weapons-training area. |
| **Security Administration Division** | Manages access authorization, guard assignment, internal security records, and administrative incident coordination. | Security coordinators, credential officers, approved supervisors. | It belongs near leadership and personnel records but is functionally separate from L1 perimeter work and L4 response staging. | Controlled Door; no casual link to HCZ routes. |
| **Applied Anomalous Systems Annex** | Hosts limited, scheduled anomalous applications that have a defensible administrative/research value and can be isolated from ordinary L2 traffic. | Vetted researchers, applied-systems staff, approved clinical/engineering support. | Some assets may support staff care, training observation, or controlled applied research better near supervision and administrative research support than in an LCZ containment ring. | Containment Door and dedicated material handoff; never open from ordinary office circulation. |
| **Staff Access & Internal Communications Division** | Controls the staff transition from L1, schedules internal movement, supports secure communications, and manages office services. | Access personnel, communications staff, administrative support. | A single controlled internal hub prevents every L2 division or lower-level route from becoming its own open entry point. | Light Gate before approved L3 personnel circulation. |

### Controlled anomalous applications on L2

L2 is not a hidden LCZ. It can hold **limited, purpose-justified exceptions** inside the Applied Anomalous Systems Annex or Clinical Services Division. Those exceptions are controlled assets, not casual office amenities.

| Example function | Plausible L2 placement | Why it can fit | Non-negotiable condition |
|---|---|---|---|
| **SCP-914 applied systems work** | Applied Anomalous Systems Annex, adjacent to research oversight and administrative preparation. | It can support scheduled engineering evaluation, controlled observation for vetted junior researchers, and supervised material work. | The asset uses a dedicated containment sector and material handoff; office workers cannot simply walk in. |
| **SCP-500 controlled clinical reserve** | Clinical Services pharmacy custody. | It is a clinical asset whose use requires medical authorization, records control, and secure inventory. | It is not routine medicine, and its stock/use remain restricted and logged. |
| **Anomalous beverage service asset** | Staff-services observation alcove or Applied Annex, according to output risk. | A low-impact asset can support supervised welfare or research observation. | It remains controlled, logged, and relocatable to L3 if its input/output creates research or containment risk. |

### L2 logic

L2 keeps office staff, patients, and ordinary site governance away from routine containment traffic. It also prevents the opposite mistake: treating every anomalous item as though it must sit in an LCZ cell block even when its real work is clinical or applied research. The deciding rule is not convenience; it is whether the asset can be supervised, supplied, isolated, and recovered without compromising L2’s core administrative environment.

---

## L3 — Light Containment Zone and Daily Operational Core

### Mission

L3 sustains the daily operational life of Site-19: lower-risk containment, research, interviews, scheduled testing, D-Class custody and dispatch, controlled material intake, long-shift staff support, and the primary physical boundary before heavy containment.

### Divisions

| Division | What it does | Who works there | Why it is on L3 | Key boundary |
|---|---|---|---|---|
| **LCZ Access & Duty Control Division** | Receives authorized staff from L2, confirms LCZ assignment, tracks controlled movement, and separates daily LCZ circulation from administrative routes. | Access officers, LCZ security, duty coordinators. | L3 must not be an open continuation of L2. | Light Gate from L2; a Heavy Gate controls HCZ transfer separately. |
| **Light Containment Division** | Operates Safe and suitable Euclid containment clusters, observation spaces, and routine containment support. | Containment technicians, researchers, security escorts, maintenance teams. | These assets require regular scheduled work but not the isolation posture of HCZ. | Containment Doors between staff circulation and each cluster. |
| **Research, Interview & Testing Division** | Hosts scheduled laboratories, interview rooms, analysis spaces, and supervised testing related to LCZ-compatible assets. | Researchers, analysts, authorized D-Class escorts, clinical/security support. | It needs close controlled access to LCZ assets while remaining separate from ordinary containment corridors. | Containment Door and assigned test routes; no open path from D-Class housing. |
| **D-Class Custody & Dispatch Division** | Manages secure arrival, intake, clinical/psychological screening, housing, welfare administration, holding, and escorted dispatch to approved tests. | Custody staff, clinical staff, security, assigned research liaisons. | D-Class movement is a custody-and-logistics system, not ordinary staff traffic or a random corridor. | Separate containment transfer route; no open connection to research or cafeteria circulation. |
| **Material Intake & Controlled Transfer Division** | Receives screened material from logistics, prepares authorized test material, and directs approved transfers to research, containment, L4, or L5. | Logistics technicians, material-control staff, containment escorts. | It prevents freight and controlled material from travelling through staff services or offices. | Logistics boundary, material inspection point, and designated containment transfer paths. |
| **Shift Services & Welfare Division** | Provides cafeteria, sanitation, rest areas, lockers, uniform/service support, and staff welfare for long LCZ shifts. | All authorized L3 shift staff; service personnel. | A large below-ground operational population needs food, rest, and hygiene near its work without making return trips through L2. | Buffered service spine; does not open directly into containment, D-Class custody, or HCZ transfer. |
| **LCZ Clinical Response & Transfer Division** | Provides immediate controlled stabilization and handoff for routine work injuries or exposure concerns before transfer to the L2 clinical department or specialist isolation. | Clinical response staff, security, assigned containment personnel. | An L3 event cannot safely travel unprepared through normal service or office spaces. | Clinical transfer route; not a substitute for the broad L2 medical department. |
| **HCZ Transition Division** | Controls authorization and transfer from LCZ to L4. | Authorized HCZ personnel, containment/security escorts, controlled transfer staff. | HCZ entry must be a deliberate, logged, destination-specific decision. | Heavy Gate to the L4 transfer elevator; no casual through traffic. |

### L3 logic

L3 is the busiest underground level because it is where daily containment work meets human needs. It needs more than cells and labs: it needs controlled custody, material flow, health response, sanitation, food, rest, security, and a hard boundary to HCZ. The cafeteria belongs here for that reason, but it is a **service spine**, not a public square placed beside containment rooms.

---

## L4 — Heavy Containment Zone and Isolated Specialist Operations

### Mission

L4 is where Site-19 performs work that cannot reasonably share LCZ traffic: high-consequence containment, specialist isolation, restricted recovery support, and controlled response readiness. It is a low-traffic operating environment; its design minimizes the number of people, materials, and routes that cross its boundaries.

### Divisions

| Division | What it does | Who works there | Why it is on L4 | Key boundary |
|---|---|---|---|---|
| **HCZ Transfer & Access Control Division** | Receives approved arrivals from the L3 heavy-gate route, verifies destination authority, and directs personnel/materials to HCZ divisions. | HCZ access staff, security, authorized escorts. | A lift arrival cannot open directly into the containment core. | Heavy Gate from L3 and controlled internal routes onward. |
| **Heavy Containment Division** | Operates high-risk containment clusters and their associated controlled support functions. | Specialist containment teams, researchers, security, maintenance personnel. | These assets require the strongest routine operational separation. | Heavy containment doors and isolated internal sector boundaries. |
| **Specialist Research & Recovery Division** | Performs restricted research, post-incident recovery support, and work that cannot safely occur in L3. | Cleared specialist researchers, recovery personnel, clinical/security support. | It needs proximity to HCZ assets and controlled response capability. | Controlled internal route; no general laboratory access. |
| **Decontamination & Clinical Isolation Division** | Provides controlled decontamination, high-risk exposure isolation, and clinical stabilization before authorized transfer. | Specialist clinical teams, response staff. | High-risk exposure care must not be routed through L2 medical waiting or office traffic. | Clinical isolation boundary and dedicated controlled transfer path. |
| **Incident Response Support Division** | Holds protective equipment, incident coordination support, recovery staging, and restricted response logistics. | Authorized response personnel and support staff. | It must be close to HCZ without becoming the site’s general security office. | Restricted response route; not a routine staff service. |
| **Deep Isolation Division — SCP-682** | Maintains the separate high-consequence containment asset registered as SCP-682. | Explicitly authorized containment and incident personnel. | Its isolation need exceeds even normal HCZ sector separation. | Dedicated deep route and isolation-gate pair; no chamber plan or procedure appears in PASS. |

### L4 logic

L4 is not “L3 but with more dangerous SCPs.” Its whole operating model changes: fewer people, narrower routes, stronger compartmentalization, specialist care, and purpose-specific access. The L3 heavy gate is the administrative and physical break between normal containment work and this environment. A further isolation sequence protects the deep sector from ordinary HCZ movement.

---

## L5 — Heavy Storage Zone, Protected Infrastructure, and Rare-Use Assets

### Mission

L5 protects what should not move often: long-hold anomalous assets, controlled evidence and physical records, site-critical infrastructure, specialized maintenance systems, and strategic contingency assets. It is purpose-limited rather than empty; it has its own logistics, maintenance, and retrieval discipline.

### Divisions

| Division | What it does | Who works there | Why it is on L5 | Key boundary |
|---|---|---|---|---|
| **Long-Hold Anomalous Storage Division** | Stores packaged, inert, inactive, rare-use, or scheduled-retrieval anomalous assets. | Storage custodians, authorized retrieval teams, containment/logistics staff. | These assets need stable, low-traffic custody rather than daily research circulation. | Secure logistics access, inventory control, and compartmented storage sectors. |
| **Evidence, Archive & Physical Records Division** | Holds redundant physical records, controlled evidence, sealed samples, and recovery material. | Archive custodians, records officers with purpose-specific authorization. | It protects material records that should not sit in an ordinary L2 records office. | Controlled archive boundary; document access does not grant vault entry. |
| **Critical Infrastructure Division** | Supports protected utilities, systems resilience, monitored technical spaces, and restricted maintenance functions. | Approved engineering and maintenance teams. | Some site-support systems require deep protection and reduced public/operational traffic. | Maintenance route; no unrestricted access from storage sectors. |
| **Maintenance & Deep Logistics Division** | Moves approved equipment and service teams to L5 systems and scheduled storage retrieval points. | Maintenance teams, logistics personnel, escorts as required. | Deep storage and infrastructure cannot depend on ordinary personnel lift circulation. | Dedicated logistics/maintenance route with destination controls. |
| **Omega Contingency Division** | Records the existence and governance state of a highly restricted strategic contingency asset. | Only specifically authorized custody and governance personnel. | It is a rare-use, high-authority asset that must remain removed from daily operations. | Isolation gate and purpose-limited record; PASS shows no coordinates, activation logic, technical details, or procedures. |

### L5 logic

L5 is not a forgotten basement. It is a managed custodial environment. Its important question is not “what is stored here?” but “why must this asset be stable, logged, compartmented, and deliberately retrieved rather than constantly available?” That logic applies equally to anomalous storage, physical evidence, infrastructure, and strategic contingencies.

---

## Cross-level circulation and access boundaries

The finished map should show why a valid route exists, not merely draw a generic elevator between every level.

| Flow | Normal path | Boundary logic |
|---|---|---|
| **Administrative staff** | L1 Personnel Arrival → L2 Staff Access Hub → assigned L2 division. | They do not need to pass the L3 Light Gate. |
| **LCZ shift worker** | L1 Personnel Arrival → L2 briefing/medical as needed → L2 Staff Access → L3 Light Gate → assigned L3 division. | LCZ entry is deliberate and assignment-based. |
| **HCZ worker** | L1/L2 approved access → L3 Light Gate → L3 HCZ Transition → Heavy Gate → L4 Transfer & Access Control → assigned L4 division. | HCZ requires a second, destination-specific boundary beyond LCZ clearance. |
| **D-Class movement** | Controlled external or internal custody handoff → L3 D-Class Custody & Dispatch → escorted approved test/containment route. | D-Class never use staff welfare, research, or general personnel circulation as free movement. |
| **Routine patient** | Assigned level → approved clinical route → L2 Clinical Services. | Normal care is broad but protected from administrative traffic. |
| **High-risk exposure patient** | L3/L4 response point → controlled clinical isolation/stabilization → authorized transfer. | No unprepared route through L2 public-facing administrative functions. |
| **Freight** | L1 Vehicle & Receiving → controlled logistics handoff → L3 Material Intake or L5 Deep Logistics. | Freight does not share routine staff lifts or pass through administrative offices. |
| **Deep storage retrieval** | Authorized request → L5 Maintenance & Deep Logistics → specific storage/archive sector. | Storage retrieval is purpose-limited and logged, not a general L5 tour. |
| **Emergency evacuation** | Nearest approved emergency barrier/egress core → surface safe egress. | Emergency infrastructure is never a daily route around access gates. |

## What the rebuilt PASS Facility Records experience should eventually answer

The app should not show a stack of detached cards. For each level, a reader should be able to open a division and see: its mission, sectors, normal personnel, adjacent support systems, boundary type, authorized route types, and administrative access status. A selected sector should then show its function, appropriate SCP placement patterns, and related records when the active session is allowed to see them.

| Reader question | Expected answer in PASS |
|---|---|
| “Why is this SCP in L2 rather than L3?” | Its operational role, supervision model, boundary, and compatibility with L2 functions. |
| “What does the Heavy Gate on L3 protect?” | The HCZ transfer route and the fact that L4 needs destination-specific authority. |
| “Where does a D-Class go?” | D-Class Custody & Dispatch, then only an escorted approved route. |
| “How does a clinician handle an exposure?” | The relevant controlled stabilization and clinical transfer pathway, without tactical detail. |
| “Where do researchers eat or recover during a shift?” | The buffered L3 Shift Services & Welfare Division. |
| “What is in L5?” | Custodial divisions and purpose-limited assets, not a generic list of hidden rooms. |

## Decisions to make together before implementation

1. **Confirm the scale.** This plan treats each level as a network of six to eight divisions rather than four generic sectors. Is this the right baseline detail for PASS?
2. **Confirm the L2 exception model.** Is the controlled Applied Anomalous Systems Annex the right way to allow justified items such as SCP-914 near administration/research oversight without turning L2 into a second LCZ?
3. **Choose the next focus.** We can now deepen one level at a time—most naturally L2 and L3—or we can first refine the cross-level gate/lift network.

