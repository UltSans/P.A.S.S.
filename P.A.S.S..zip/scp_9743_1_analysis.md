# SCP-9743-1: Classification and Containment Analysis

## Scope and method

This analysis treats the supplied twelve chapters and your existing profile as the working canon for **SCP-9743-1 — “The Vessel.”** It does not alter the story or presume that every element must fit a single standard ACS dropdown. The purpose is to identify what the text already establishes, where your current profile is strongly supported, and where the record needs an explicit explanation so that its classification is credible to a Foundation reader.

The central finding is that SCP-9743-1 is not one simple containment subject. The record contains at least three operational layers: **Raziel/UltSans as a cooperative but psychologically fragile individual; Hatred as an autonomous or semi-autonomous catastrophic manifestation; and a personal void/pocket-dimension system that permits controlled or uncontrolled spatial movement.** The Foundation would need to document the relationship between those layers rather than treat them as a single power set.

## What the chapters establish

| Record dimension | Evidence from the supplied chapters | Operational consequence |
|---|---|---|
| **Mobility** | SCP-9743-1 opens portals, accesses a personal void, teleports, and moves people or objects between locations. | A conventional cell cannot constitute reliable physical containment. |
| **Destructive ceiling** | The opening incident depicts Hatred surviving conventional response, causing mass casualties, destroying infrastructure, absorbing matter, and deploying large-scale tentacular effects. | Emergency response must treat a hostile manifestation as a major site, city, and potentially wider-scale incident. |
| **Autonomy and state change** | Raziel has memory gaps, dissociation, panic, and incomplete awareness during Hatred activity. Hatred speaks, judges, acts independently, and can emerge following emotional or moral triggers. | The file must distinguish the cooperative subject from the manifestation; agreement from Raziel is not an unconditional guarantee of Hatred’s behavior. |
| **Containment sensitivity** | Coercion, dehumanization, physical restraint, hostile interrogation, and perceived abuse appear to worsen instability. Calm conversation, consent, social support, meaningful activity, and trusted relationships repeatedly correlate with cooperation. | The practical containment method is a negotiated care-and-engagement protocol, with limits and monitoring—not permissive “freedom” without controls. |
| **Utility** | The chapters show healing, material creation, pocket-dimension logistics, communication/technology, and anomalous intervention against dangerous entities. The SCP-682 event supports an argument for Foundation use. | Thaumiel-like status is plausible only as a conditional authorization for specific approved operations, not as a description of being powerful or helpful. |
| **Veil exposure** | The initial public urban incident includes witnesses, recordings, emergency response, aircraft, infrastructure destruction, and overt anomalous effects. | A standing Disruption Class of Dark is difficult to support unless the record explains why this event is atypical and how the Veil was fully restored. |

## Classification assessment

> **Important distinction:** an ACS label should describe the anomaly’s containment reality and effects, not reward or punish the subject. The file can recognize Raziel’s cooperation while still documenting the consequences of a Hatred manifestation.

### 1. Containment Class: Ticonderoga

Your use of **Ticonderoga** has a clear *story logic*: conventional containment is not realistically available because of portals, the personal void, broad destructive capability, and the potential for a manifestation that cannot be reliably held by a normal Foundation facility. The story also shows that trying to treat SCP-9743-1 as an ordinary prisoner materially increases risk.

However, the strict current wiki definition of Ticonderoga also says the anomaly **does not need to be contained**. Your text does not support simple non-intervention. It supports **non-physical, cooperative containment**: the Foundation still needs trauma-informed engagement rules, behavioral observation, emergency separation procedures, limits on triggering information, and formal authorization for high-risk access.

The strongest solution is not to discard your designation. It is to write it precisely as an **Extended / Custom ACS Containment Designation**:

> **Ticonderoga (Extended):** Physical containment is not feasible and is assessed as counterproductive. SCP-9743-1 is managed through voluntary residence, negotiated support protocols, controlled access, and continuous assessment of manifestation indicators.

That wording makes the designation intelligible. It also avoids incorrectly suggesting that the Foundation simply ignores the risk.

### 2. Secondary Class: Thaumiel

**Thaumiel** is defensible, but it must be conditional. The chapters establish a potential Foundation asset: healing capacity, anomalous construction, pocket-dimension logistics, and capability against severe anomalies including SCP-682. A credible Foundation record would phrase this as an operational status with safeguards:

> **Thaumiel (Conditional):** Authorized for use in approved containment-support, medical-support, and anomaly-neutralization operations only when the subject is clinically stable, informed, and voluntarily participating.

This matters because “Thaumiel” should not mean “the Foundation owns or may deploy him whenever it wants.” That interpretation directly clashes with the story’s trigger pattern. In your narrative, coercive deployment increases the risk of Hatred, which makes a consent-based authorization requirement part of the containment logic.

### 3. Disruption Class: Dark

This is the least supported current field. **Dark** is normally appropriate when an anomaly has little expected impact on the Veil or public order. The first chapter shows the opposite during a hostile manifestation: an open-city event, visible destruction, civilian witnesses, emergency response, and sustained combat activity.

You can still retain Dark only if the profile explicitly limits it to the **baseline cooperative state** and explains that the opening event was an exceptional escalation that was fully covered up. If the classification describes the anomaly’s actual plausible worst operational state, a higher disruption class is more credible. The story text most clearly supports a higher class because one manifestation can produce broad public exposure and major infrastructure damage.

Rather than changing this now, the record should contain a decision note:

| Option | When it is credible |
|---|---|
| **Dark** | Only for a narrowly scoped cooperative-state assessment with a documented Veil-restoration explanation for the opening incident. |
| **Higher disruption classification** | If the record classifies the full SCP-9743-1/Hatred system and recognizes that similar incidents could recur outside a secured site. |

### 4. Risk Class: Danger

**Danger** captures severe direct harm, but the supplied incident includes mass casualties, extreme structural damage, resilient hostile effects, and loss of control. The text therefore creates an arguable case for **Critical** risk when Hatred is active. It is reasonable to preserve Danger only if the profile explicitly separates two states:

| State | More defensible risk framing |
|---|---|
| **Raziel cooperative / supported** | Danger may be workable because capabilities remain potentially harmful but are not actively hostile. |
| **Hatred manifested / control failure** | Critical is more consistent with the demonstrated casualty and damage potential. |

PASS should eventually support this through a **baseline class plus escalation condition** rather than forcing one label to describe both an ordinary cooperative session and a city-scale manifestation.

### 5. Document Clearance: Level 3

Level 3 can work for the ordinary research and care record, especially if the file is used by a defined Site-19 team. But the chapters also include cross-dimensional information, sensitive internal identities, operational use against high-risk anomalies, and potential information hazards. A grounded file could split access:

| File segment | Suggested handling |
|---|---|
| **General clinical and containment profile** | Level 3, for the assigned research, medical, and containment team. |
| **Hatred manifestation history, personal-void intelligence, and Thaumiel authorization** | Restricted addendum; higher need-to-know access or a separate authorization list. |
| **Emergency response protocol** | Available to relevant security/response staff, but with trigger-sensitive information minimized. |

This does **not** mean the subject’s personal keycard clearance must rise. Document clearance, departmental authority, and physical access permissions should remain independent in PASS.

## Keycard and access-control assessment

The proposed personnel profile is a useful starting point, but several items should be reorganized to read as a real access record.

| Current note | Better record treatment | Reason |
|---|---|---|
| **Department: Research** | Research assignment with named supervising program or liaison. | The chapters show research, medicine, ethics, containment support, and paratechnology involvement; a single generic department is too narrow. |
| **Clearance: 1** | Departmental research authority, separate from document clearance. | Keep it separate from the SCP file’s Level 3 document classification. |
| **LCZ** | Baseline location permission only. | It conflicts with the proposed routine access to SCP-049, SCP-914, and other areas unless escorted or individually approved. |
| **“Roam around alone” under Restrictions** | Move to a movement permission: `Unescorted transit: approved routes only`, if that is your intent. | It is a permission, not a restriction. |
| **Euclid / Keter under Restrictions** | State exactly whether this means no unsupervised access, no file access, or no contact. | “Euclid” and “Keter” are classes, not locations; the operational control needs to be specific. |
| **SCP-049 / SCP-914 chamber access** | Object-specific access with a purpose, an escort rule, and revocation criteria. | The story supports specific relationships and research value, but unrestricted access would be hard to justify. |

A more grounded access card would read like this:

> **Baseline access:** Assigned residential/research suite and approved Light Containment routes.  
> **Conditional access:** SCP-049 medical consultation; SCP-914 supervised research; approved personal-void transition point.  
> **Restricted access:** Unsupervised contact with high-risk or psychologically provocative anomalies; dissemination of trigger-sensitive records; independent deployment during active distress.  
> **Emergency status:** Suspend nonessential access when manifestation indicators are observed; activate negotiated de-escalation protocol before armed intervention whenever feasible.

## The essential record design: two-state containment

The chapters support a two-state record better than a one-word class.

```text
BASELINE STATE — Raziel cooperative
  • Voluntary Site residence and support
  • Research / medical / authorized containment support
  • Observed mental-health and manifestation indicators

ESCALATION STATE — Hatred manifestation
  • Treat as catastrophic containment incident
  • Prioritize evacuation, Veil protection, and de-escalation
  • Do not rely on conventional force as the primary plan
  • Avoid known provocation patterns and unauthorized coercion
```

This does not weaken your story. It gives the Foundation a realistic reason to classify him as unusually difficult: they are not containing an object in a room; they are managing a relationship with a vulnerable person whose internal system can produce an existentially dangerous manifestation.

## Recommended working profile — for review only

This is not a replacement for your profile. It is the clearest grounded version of what the chapters currently support.

| Field | Working recommendation |
|---|---|
| **Designation** | SCP-9743-1 — *The Vessel* |
| **ACS mode** | Custom / Extended ACS, documented in the file |
| **Containment Designation** | Ticonderoga (Extended Cooperative Containment) |
| **Secondary Class** | Thaumiel (Conditional / consent-based operational use) |
| **Disruption Class** | Requires your decision after defining whether the opening urban event is baseline capability or exceptional escalation; Dark needs an explicit narrow-scope rationale. |
| **Risk Class** | Danger at baseline may be defensible; Critical during Hatred manifestation is supported by the supplied incident. |
| **Document Clearance** | Level 3 main profile with restricted addenda for manifestation history and operational authorization. |
| **Core containment method** | Voluntary residence, support protocol, monitored access, trigger minimization, and negotiated de-escalation. |

## Questions to resolve before any profile change

1. Is the open-city Hatred event an exceptional first-contact incident, or can it plausibly happen again whenever the subject is destabilized? This determines whether Dark is still usable.
2. Does the Foundation have a proven way to prevent or stop Hatred, or only a way to reduce its probability through cooperation? This determines how strongly the file can use Ticonderoga.
3. Is Thaumiel status intended to mean “the Foundation may ask for help,” or “the Foundation can formally deploy him as a containment asset”? The chapters strongly support the first; the second needs consent and safety limits.
4. Is SCP-3114 still anatomically integral after the skeleton replacement, or is it a historical/associated-anomaly relationship? This should be written in an associated-entities field rather than buried in the physical description.

## References

[1] [SCP Wiki — Object Classes](https://scp-wiki.wikidot.com/object-classes)  
[2] [SCP Wiki — Anomaly Classification System Guide](https://scp-wiki.wikidot.com/anomaly-classification-system-guide)  
[3] [SCP Wiki — Anomaly Classification Bar for ACS](https://scp-wiki.wikidot.com/component:anomaly-class-bar)  
[4] [SCP Wiki — Customizable ACS Add-On Guide](https://scp-wiki.wikidot.com/component:customizable-acs-guide)
