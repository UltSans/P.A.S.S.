import { useState } from "react";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";

import { Eyebrow, Panel, PrimaryButton, palette } from "@/components/registry-ui";
import { ScreenContainer } from "@/components/screen-container";
import { haptic } from "@/lib/haptics";
import { canPerformAction } from "@/lib/access-permissions";
import { useRegistry } from "@/lib/registry-store";
import { canAccessClearance } from "@/lib/registry-utils";
import { useSession } from "@/lib/session-store";

export default function EntryFolderScreen() {
  const { ownerType, ownerId } = useLocalSearchParams<{ ownerType: "scp" | "personnel"; ownerId: string }>();
  const router = useRouter(); const { upsertEntryFolder, scps, personnel } = useRegistry(); const { profile } = useSession(); const [name, setName] = useState(""); const scpOwner = scps.find((item) => item.id === ownerId); const personnelOwner = personnel.find((item) => item.id === ownerId); const ownerClearance = ownerType === "personnel" ? personnelOwner?.clearanceLevel : scpOwner?.minimumClearanceLevel; const permitted = canPerformAction(profile.clearanceLevel, "create-folder") && Boolean(ownerClearance && canAccessClearance(profile.clearanceLevel, ownerClearance));
  const save = () => { if (!permitted) { Alert.alert("Authority required", "Folder creation is not available in this reader session."); return; } if (!name.trim()) { haptic.warning(); Alert.alert("Folder name required", "Enter a name for the document folder."); return; } upsertEntryFolder({ ownerType: ownerType === "personnel" ? "personnel" : "scp", ownerId, name: name.trim() }); haptic.success(); router.back(); };
  if (!permitted) return <ScreenContainer className="items-center justify-center p-8" containerClassName="bg-[#11100F]"><MaterialCommunityIcons name="shield-lock-outline" color={palette.amber} size={36} /><Text style={styles.restricted}>Folder creation restricted.</Text><PrimaryButton label="Return" icon="arrow-left" onPress={() => router.back()} /></ScreenContainer>;
  return <ScreenContainer className="flex-1" containerClassName="bg-[#11100F]"><View style={styles.topbar}><Pressable onPress={() => router.back()} style={({ pressed }) => [styles.back, pressed && styles.pressed]}><MaterialCommunityIcons name="close" color={palette.ink} size={21} /></Pressable><View><Eyebrow>DOCUMENT LIBRARY</Eyebrow><Text style={styles.title}>New folder</Text></View></View><View style={styles.content}><Panel style={styles.panel}><Text style={styles.label}>FOLDER NAME</Text><TextInput value={name} onChangeText={setName} placeholder="Containment reviews" placeholderTextColor="#8D857B" style={styles.input} autoCapitalize="words" returnKeyType="done" onSubmitEditing={save} /><Text style={styles.note}>Folders exist only inside this {ownerType === "personnel" ? "personnel" : "SCP"} file and keep its documents organized.</Text></Panel><PrimaryButton label="Create folder" icon="folder-plus-outline" onPress={save} /></View></ScreenContainer>;
}
const styles = StyleSheet.create({ topbar: { paddingHorizontal: 20, paddingTop: 8, flexDirection: "row", alignItems: "center", gap: 12 }, back: { height: 42, width: 42, borderRadius: 2, backgroundColor: palette.panelRaised, borderColor: palette.line, borderWidth: 1, justifyContent: "center", alignItems: "center" }, title: { color: palette.ink, fontSize: 21, fontWeight: "900", marginTop: 2 }, content: { padding: 20, gap: 18 }, panel: { gap: 12, borderRadius: 2 }, label: { color: palette.muted, fontSize: 9, fontWeight: "900", letterSpacing: 0.9 }, input: { minHeight: 48, borderRadius: 2, borderColor: palette.line, borderWidth: 1, backgroundColor: "#141312", paddingHorizontal: 12, color: palette.ink, fontSize: 14 }, note: { color: palette.muted, fontSize: 12, lineHeight: 18 }, restricted: { color: palette.ink, fontSize: 18, fontWeight: "800", marginVertical: 14 }, pressed: { opacity: 0.65, transform: [{ scale: 0.97 }] } });
