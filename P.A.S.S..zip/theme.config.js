/** @type {const} */
const themeColors = {
  primary: { light: '#B33B35', dark: '#B33B35' },
  background: { light: '#11100F', dark: '#11100F' },
  surface: { light: '#191817', dark: '#191817' },
  foreground: { light: '#E9E4D9', dark: '#E9E4D9' },
  muted: { light: '#A29A8C', dark: '#A29A8C' },
  border: { light: '#413C35', dark: '#413C35' },
  success: { light: '#778D67', dark: '#778D67' },
  warning: { light: '#BD8740', dark: '#BD8740' },
  error: { light: '#D15B54', dark: '#D15B54' },
};

module.exports = { themeColors };
