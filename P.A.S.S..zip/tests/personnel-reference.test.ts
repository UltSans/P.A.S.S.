import { describe, expect, it } from "vitest";

import { PERSONNEL_REFERENCE_AUDIT, SITE19_PERSONNEL_ID_FORMAT, formatSite19PersonnelId } from "../lib/personnel-reference";

describe("personnel reference", () => {
  it("covers every current Department and Position/Rank suggestion", () => {
    expect(PERSONNEL_REFERENCE_AUDIT.missingDepartments).toEqual([]);
    expect(PERSONNEL_REFERENCE_AUDIT.missingPositions).toEqual([]);
  });

  it("creates stable Site-19 personnel serial IDs", () => {
    expect(SITE19_PERSONNEL_ID_FORMAT).toBe("S19-0001");
    expect(formatSite19PersonnelId(247)).toBe("S19-0247");
  });
});
