import { describe, expect, it } from "vitest";

import { incidentCanClose, incidentRequiredClearance, nextIncidentStatus, uniqueEntryReferences, uniqueIncidentIds } from "../lib/incident-utils";

describe("Incident Report relationship rules", () => {
  it("deduplicates selected record identifiers and supporting Entry references", () => {
    expect(uniqueIncidentIds(["scp-1", "scp-1", "", "scp-2"])).toEqual(["scp-1", "scp-2"]);
    expect(uniqueEntryReferences([{ ownerType: "scp", entryId: "entry-1" }, { ownerType: "scp", entryId: "entry-1" }, { ownerType: "personnel", entryId: "entry-1" }])).toEqual([{ ownerType: "scp", entryId: "entry-1" }, { ownerType: "personnel", entryId: "entry-1" }]);
  });

  it("raises report clearance to the highest protected linked SCP, Personnel, or Project", () => {
    expect(incidentRequiredClearance({ scps: [{ id: "scp-1", minimumClearanceLevel: "Level 4" }] as any, personnel: [{ id: "per-1", clearanceLevel: "Level 3" }] as any, projects: [{ id: "project-1", minimumClearanceLevel: "Level 5" }] as any, selectedScpIds: ["scp-1"], selectedPersonnelIds: ["per-1"], selectedProjectId: "project-1" })).toBe("Level 5");
  });

  it("permits only the approved forward status sequence and requires documented closure", () => {
    expect(nextIncidentStatus("Draft")).toBe("Active");
    expect(nextIncidentStatus("Active")).toBe("Resolved");
    expect(nextIncidentStatus("Resolved")).toBe("Closed");
    expect(nextIncidentStatus("Closed")).toBeUndefined();
    expect(incidentCanClose({ status: "Resolved", resolutionSummary: "Containment re-established.", closureRationale: "No further immediate action is required." })).toBe(true);
    expect(incidentCanClose({ status: "Resolved", resolutionSummary: "", closureRationale: "Missing resolution." })).toBe(false);
  });
});
