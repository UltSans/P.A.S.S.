# PASS / Site-19 Facility Structure Model

## Scope

This model maps **the Site itself**. It names fixed levels, divisions, services, boundaries, and routes. It deliberately does not name, locate, or describe individual SCP contents. Those assignments belong in individual dossiers and can change without requiring a site map rewrite.

## Site-wide operating logic

Site-19 is not five stacked “zones.” It is a vertical facility with separate flows for people, custody, cargo, clinical transfer, maintenance, and emergency egress. A division exists because it does a defined job. A gate exists because two flows must not mix. A lift exists because one flow has to move without passing through another level’s work area.

| Level | Fixed purpose | Normal population | What it deliberately excludes |
|---|---|---|---|
| **L1 — Surface Operations** | Protect the underground facility’s physical interface with the outside world. | Surface security, cleared arrivals, logistics personnel, air/vehicle crews, infrastructure technicians. | Routine offices, normal clinical work, containment, public access. |
| **L2 — Administration & Clinical Services** | Run the site, care for its personnel, and manage small controlled support work. | Site leadership, administration, records/access staff, clinicians, psychologists, approved researchers, assigned security. | D-Class custody, general containment corridors, heavy response staging, public training. |
| **L3 — Light Containment Operations** | Perform the site’s daily lower-risk containment, research, custody, and shift-support workload. | Containment staff, assigned researchers, security, D-Class under escort, sanitation, food and support teams. | General administration, uncontrolled deep-containment movement, long-term strategic storage. |
| **L4 — Heavy Containment Operations** | Operate high-risk containment under restricted traffic, specialist work, and rapid isolation. | Specially assigned containment/security teams, specialist researchers, decontamination and response staff. | Routine site traffic, ordinary services, open staff movement, general custody. |
| **L5 — Heavy Storage & Critical Custody** | Hold long-term restricted material, protected records, reserve assets, and limited critical infrastructure. | Restricted custody, archive, logistics, and maintenance personnel. | Daily workspaces, routine research, ordinary staff facilities. |

## Level 1 — Surface Operations

Level 1 is a remote, restricted surface compound. It is not a campus, visitor centre, or office floor. It permits the underground site to receive staff, freight, custody transfers, and rare aircraft movements without exposing lower operations.

| Division | Function | Boundary relationship |
|---|---|---|
| **Perimeter & Approach Control** | Controls the restricted land, approach road, exterior monitoring, and first response to an unexplained approach. | The outer boundary; it separates the reservation from every internal activity. |
| **Personnel Entry & Screening** | Verifies cleared personnel, screens carried items, provides lockers, and feeds the personnel lift group. | Does not share a route with freight, custody transfers, or aircraft arrivals. |
| **Vehicle & Freight Transfer** | Inspects vehicles and cargo before a controlled handoff to the underground freight system. | Drivers do not pass into inner facility operations. |
| **Custody Transfer Port** | Receives controlled human transfers through a discrete, secure route to L3. | Entirely separated from L2 staff entry and normal freight. |
| **Air Operations Pad** | Supports pre-authorized helicopter landing, rapid deployment, controlled transfer, and evacuation. | Uses a secure handoff point; it is not a public terminal. |
| **Surface Security & Infrastructure** | Runs entrance control, exterior response, communications, ventilation interfaces, water/power interface, and surface maintenance. | It supports the site but does not expose lower level plans. |
| **Emergency Egress Network** | Provides sealed surface exit points from lower levels into the reservation. | Exit-only in normal conditions; not an ordinary entrance. |

## Level 2 — Administration & Clinical Services

Level 2 is the site’s controlled institutional core. It is where the site is governed, documented, staffed, medically supported, and given stable daily direction. It receives the normal personnel lift from L1, but it is not a shortcut into containment.

| Division | Function | Why it belongs on L2 |
|---|---|---|
| **Site Command & Administration** | Site Director’s suite, duty coordination, departmental administration, scheduling, controlled briefings, and operational record oversight. | These functions need site-wide awareness without routine anomaly exposure. |
| **Personnel, Credentials & Records** | Personnel processing, access administration, secure records, assignment control, and internal document custody. | It is the institutional boundary between authorised staff and deeper operational access. |
| **Clinical Services Division** | Full physical care, diagnostics, treatment, behavioural health, psychological assessment, pharmacy, occupational medicine, rehabilitation, and clinical isolation. | It serves the entire staff population and must be accessible before deeper operational boundaries. |
| **Clinical Transfer & Stabilization Interface** | Receives controlled patient transfers from L3/L4 without routing high-risk cases through administration. | It connects clinical care to operational levels while preserving separation. |
| **Controlled Applied Anomalies Annex** | A separately secured group of small support/research cells for approved low-traffic anomalous work. | It is close to research governance and clinical oversight but isolated from both ordinary offices and main clinical circulation. |
| **Staff Briefing & Qualification Centre** | Controlled briefings, policy refreshers, credentials, procedural instruction, and assignment preparation for qualified personnel. | It is not a recruit academy or weapons range; those stay outside the facility. |
| **L2 Operations Control** | Monitors Level 2 access, internal communications, and transfers to the L3 checkpoint. | It prevents administration from becoming an uncontrolled route toward containment. |

## Level 3 — Light Containment Operations

Level 3 is the largest day-to-day working level. It handles the continuous work created by lower-risk containment, research support, custody operations, and the population that must stay near those functions through long shifts. It is reached from L2 only through a controlled operational checkpoint; custody and freight have separate vertical routes.

| Division | Function | Required separation |
|---|---|---|
| **LCZ Access & Operations Control** | Receives cleared staff through the L2 checkpoint, manages local assignment access, and directs response to routine incidents. | Separates L2 institutional work from L3 containment operations. |
| **Light Containment Division** | Operates grouped lower-risk containment sectors and their service corridors. | Keeps normal staff circulation out of active containment service paths. |
| **Research, Analysis & Interview Division** | Hosts approved research work, evidence examination, observation, interview, and report production related to L3 operations. | It is near containment without sitting inside the general cell/service corridors. |
| **Custody Processing & D-Class Division** | Receives controlled transfers, maintains housing and welfare, conducts staging/escort coordination, and returns people through controlled routes. | It has a dedicated surface-to-L3 custody path and never feeds through L2 offices. |
| **Shift Support Division** | Cafeteria, sanitation, changing rooms, rest areas, supply issue, and other services needed by staff working long operational shifts. | Buffered from custody housing and containment corridors. |
| **LCZ Medical Stabilization Point** | Provides immediate stabilization and protected transfer to L2 Clinical Services. | It is not a substitute for L2’s full medical department. |
| **Materials & Service Intake** | Receives cleared materials from freight lifts, manages local stores, waste segregation, and controlled delivery to work sectors. | Keeps cargo out of personnel and custody movement. |

## Level 4 — Heavy Containment Operations

Level 4 is a restricted operational level, not a larger version of L3. It exists for high-risk containment, specialist access, decontamination, and rapid local isolation. Entry is deliberate, not incidental.

| Division | Function | Required separation |
|---|---|---|
| **HCZ Transition Control** | Controls the heavy-gated change from L3 operations to L4 restricted work, verifies assignment, and manages the dedicated heavy-access lift. | No casual transit, routine staff circulation, or mixed cargo movement. |
| **Heavy Containment Division** | Operates high-risk containment sectors with internal service spines and restricted response access. | Work sectors remain compartmentalized from each other and from the main approach. |
| **Deep Isolation Division** | Holds the site’s most isolated, highest-consequence containment capability. | Reached only through a separate restrictive path after HCZ transition control. |
| **Specialist Research & Observation** | Supports high-risk work that cannot be conducted in L3 or L2. | It uses controlled observation and service interfaces, not open research corridors. |
| **Decontamination & Medical Stabilization** | Stabilizes personnel and prepares protected clinical transfer where ordinary L2 movement would be unsafe. | It is a protected transfer function, not a general medical department. |
| **Containment Response Support** | Holds response equipment, controlled staging, and local command support for an L4 incident. | It must reach work sectors without becoming a through-route for ordinary traffic. |
| **HCZ Service & Waste Control** | Handles restricted maintenance, material intake, and contained waste movement. | It uses a separated service route to avoid contaminating staff paths. |

## Level 5 — Heavy Storage & Critical Custody

Level 5 is the site’s low-traffic reserve and custody level. It preserves things that should be kept, not frequently used. It is intentionally sparse in population and does not function as an ordinary workplace.

| Division | Function | Required separation |
|---|---|---|
| **Heavy Storage Division** | Long-term controlled storage, reserve supplies, non-routine logistics, and compartmented physical custody. | Access is scheduled and duty-based, not walk-in. |
| **Restricted Item & Medical Custody** | Holds scarce, high-authority, or medically sensitive assets awaiting controlled release. | Kept separate from daily clinical treatment and general storage. |
| **Secure Archive & Evidence Custody** | Protects restricted physical records, sensitive evidence, sealed files, and historical material. | It is not the routine L2 document office. |
| **Critical Maintenance & Utility Reserve** | Supports protected plant access, reserve equipment, and deep maintenance interfaces. | Maintenance personnel enter only with defined work orders. |
| **Omega Contingency Vault** | Preserves the site’s limited, separately authorised last-resort contingency capability. | It is segregated from storage and daily maintenance, with no normal circulation through it. |
| **L5 Logistics Control** | Manages scheduled movement through deep freight/service lifts and custody handoffs. | Prevents L5 from becoming a shortcut between L3 and L4. |

## The facility is defined by separation

The core realism rule is not “put more rooms on each level.” It is that no one can use the wrong route just because it is shorter:

| Movement type | Normal route | Must not merge with |
|---|---|---|
| Personnel | L1 Personnel Entry → L2 → L3 checkpoint / assigned deeper route | Custody, freight, unrestricted containment access. |
| Custody | L1 Custody Transfer → dedicated L3 Processing & D-Class Division | L2 staff entry, cafeteria, standard personnel lifts. |
| Freight | L1 Vehicle & Freight Transfer → freight lifts → L3 intake or L5 storage | Personnel and custody routes. |
| Clinical | L2 Clinical Services ↔ protected L3/L4 transfer interfaces | General administration circulation and uncontrolled operational corridors. |
| Maintenance | Surface infrastructure / L5 reserve → controlled service spines | Normal staff corridors where possible. |
| Emergency exit | Lower-level egress → sealed L1 surface points | Normal entry routes. |

The next design step is to turn these divisions into an understandable gate, lift, and route system—still without naming individual SCP contents.
