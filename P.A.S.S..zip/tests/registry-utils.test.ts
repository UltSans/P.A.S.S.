import { describe, expect, it } from "vitest";

import { accessZonesForClearance, canAccessClearance, compareScpItemNumbers, recordDetailPath, recordId, scpItemNumberRank } from "../lib/registry-utils";

describe("registry access rules", () => {
  it("expands authorized zones as clearance increases", () => {
    expect(accessZonesForClearance("Level 1")).toEqual(["Personnel Commons", "Records Annex"]);
    expect(accessZonesForClearance("Level 4")).toEqual([
      "Personnel Commons",
      "Records Annex",
      "Research Wing",
      "Containment Corridor",
      "Site Command",
    ]);
    expect(accessZonesForClearance("Level 5")).toContain("O5 Archive");
  });

  it("creates a prefixed unique record identifier", () => {
    const id = recordId("scp");
    expect(id).toMatch(/^scp-\d+-[a-z0-9]{5}$/);
  });

  it("builds concrete post-save detail paths for every record registry", () => {
    expect(recordDetailPath("scp", "scp-01/A")).toBe("/scp/scp-01%2FA");
    expect(recordDetailPath("personnel", "per-17")).toBe("/personnel/per-17");
    expect(recordDetailPath("team", "team-01")).toBe("/teams/team-01");
  });

  it("blocks records above the session clearance", () => {
    expect(canAccessClearance("Level 2", "Level 1")).toBe(true);
    expect(canAccessClearance("Level 3", "Level 3")).toBe(true);
    expect(canAccessClearance("Level 2", "Level 3")).toBe(false);
    expect(canAccessClearance("Level 4", "Level 5")).toBe(false);
  });

  it("orders SCP identifiers by their parsed item number rather than creation order", () => {
    expect(scpItemNumberRank("SCP-000")).toBe(0);
    expect([{ itemNumber: "SCP-097" }, { itemNumber: "SCP-032" }, { itemNumber: "SCP-000" }].sort(compareScpItemNumbers).map((record) => record.itemNumber)).toEqual(["SCP-000", "SCP-032", "SCP-097"]);
  });
});
