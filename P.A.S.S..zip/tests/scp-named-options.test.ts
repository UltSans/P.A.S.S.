import { describe, expect, it } from "vitest";

import { createEmptyScpNamedClassificationOptions, mergeScpNamedClassificationOptions, namedOptionsFromScp, visibleNamedOptions } from "../lib/scp-named-options";
import { NOT_LISTED_SPECIFY } from "../lib/registry-types";

describe("field-scoped named SCP classification options", () => {
  it("keeps names scoped to their classification field and removes duplicate spellings", () => {
    const first = createEmptyScpNamedClassificationOptions();
    first.containmentClass = ["  Anomalous Transit  "];
    first.custody = ["External Stewardship"];
    const second = createEmptyScpNamedClassificationOptions();
    second.containmentClass = ["anomalous transit", "Open Transit"];
    const merged = mergeScpNamedClassificationOptions(first, second);
    expect(merged.containmentClass).toEqual(["anomalous transit", "Open Transit"]);
    expect(merged.custody).toEqual(["External Stewardship"]);
    expect(merged.operationalRole).toEqual([]);
  });

  it("adds only an actual named fallback from an SCP to the matching field", () => {
    const options = namedOptionsFromScp({ containmentClass: NOT_LISTED_SPECIFY, customContainmentClass: "Anomalous Transit", custody: "Foundation Custody" } as any);
    expect(options.containmentClass).toEqual(["Anomalous Transit"]);
    expect(options.custody).toEqual([]);
  });

  it("shows reusable names before the fallback control without duplicating built-ins", () => {
    expect(visibleNamedOptions(["Safe", "Euclid", NOT_LISTED_SPECIFY], ["Anomalous Transit", "safe", "anomalous transit"])).toEqual(["Safe", "Euclid", "anomalous transit", NOT_LISTED_SPECIFY]);
  });
});
