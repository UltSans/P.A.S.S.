# SCP Wiki Research Notes

## Sources consulted

| Source | URL | Relevant findings |
|---|---|---|
| Security Clearance Levels | https://scp-wiki.wikidot.com/security-clearance-levels | Treats a clearance level as the highest information access that may be granted, not a blanket entitlement; access remains need-to-know. It distinguishes Levels 0–5 from personnel Classes A–E, which are based on proximity to anomalous risk, and separately lists occupational titles. |
| Anomaly Classification System Guide | https://scp-wiki.wikidot.com/anomaly-classification-system-guide | Describes ACS as an optional extension to Object Class. The profile fields include Clearance Level, Containment Class, Secondary Class, Disruption Class, and Risk Class. |
| Expanded Security Clearance Codes | https://scp-wiki.wikidot.com/expanded-security-clearance-codes | Provides a useful extended model that separates personnel class, a global clearance, a division clearance, and local access to particular documents. It emphasizes that a clearance threshold alone does not establish access; a relevant assignment or need-to-know is also needed. |
| Foundation Departments | https://scp-wiki.wikidot.com/departments | Frames departments as specialist organizational units, with RAISA maintaining and controlling classified records. It stresses that the listed departments are not exhaustive. |

## Product implications to discuss with the user

1. The app should represent **job title/designation**, **personnel class**, **information clearance**, **departmental operating authority**, and **physical keycard permissions** as separate concepts rather than collapsing them into one level.
2. The current launch screen remains unchanged by user instruction, while staff profiles can use a more complete operational keycard model.
3. SCP profiles can provide a stable core record structure while treating ACS fields as optional or available only when a record needs them.
4. Document access should be sensitive to a reader’s clearance and a need-to-know/assignment rule, even where the user’s fictional expansion supplies the detailed operating logic.
