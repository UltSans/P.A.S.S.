import type { ClearanceLevel, IncidentEntryReference, IncidentReport, IncidentStatus, PersonnelRecord, ProjectRecord, ResearchTeam, SCPEntry, SCPRecord, PersonnelEntry } from "./registry-types";
import { highestClearanceLevel } from "./registry-utils";

export function uniqueIncidentIds(ids: string[]) { return [...new Set(ids.filter(Boolean))]; }

export function uniqueEntryReferences(references: IncidentEntryReference[]) {
  const seen = new Set<string>();
  return references.filter((reference) => {
    const key = `${reference.ownerType}:${reference.entryId}`;
    if (!reference.entryId || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export function incidentRequiredClearance({ scps, personnel, projects, selectedScpIds, selectedPersonnelIds, selectedProjectId }: { scps: SCPRecord[]; personnel: PersonnelRecord[]; projects: ProjectRecord[]; selectedScpIds: string[]; selectedPersonnelIds: string[]; selectedProjectId?: string; }) {
  const levels: ClearanceLevel[] = [
    ...scps.filter((record) => selectedScpIds.includes(record.id)).map((record) => record.minimumClearanceLevel),
    ...personnel.filter((record) => selectedPersonnelIds.includes(record.id)).map((record) => record.clearanceLevel),
    ...projects.filter((record) => record.id === selectedProjectId).map((record) => record.minimumClearanceLevel),
  ];
  return highestClearanceLevel(levels);
}

export function incidentEntryExists(reference: IncidentEntryReference, personnelEntries: PersonnelEntry[], scpEntries: SCPEntry[]) {
  return reference.ownerType === "personnel" ? personnelEntries.some((entry) => entry.id === reference.entryId) : scpEntries.some((entry) => entry.id === reference.entryId);
}

export function visibleIncidentLinks(incident: IncidentReport, visibleScps: SCPRecord[], visiblePersonnel: PersonnelRecord[], visibleTeams: ResearchTeam[], visibleProjects: ProjectRecord[]) {
  return { scpIds: incident.scpIds.filter((id) => visibleScps.some((record) => record.id === id)), personnelIds: incident.personnelIds.filter((id) => visiblePersonnel.some((record) => record.id === id)), teamIds: incident.teamIds.filter((id) => visibleTeams.some((record) => record.id === id)), projectId: visibleProjects.some((record) => record.id === incident.projectId) ? incident.projectId : undefined };
}

export function nextIncidentStatus(status: IncidentStatus): IncidentStatus | undefined {
  return status === "Draft" ? "Active" : status === "Active" ? "Resolved" : status === "Resolved" ? "Closed" : undefined;
}

export function incidentCanClose(report: Pick<IncidentReport, "status" | "resolutionSummary" | "closureRationale">) {
  return report.status === "Resolved" && Boolean(report.resolutionSummary?.trim()) && Boolean(report.closureRationale?.trim());
}
