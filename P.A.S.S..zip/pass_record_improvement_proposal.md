# PASS Record-Context Improvement Proposal

**Status:** Proposed for approval. This document does not change the app.

## The correct direction

PASS does not need a large encyclopedia of Groups of Interest. It needs better answers to the questions a realistic Foundation record asks:

> **What is this anomaly’s origin? Who made, supplied, recovered, or transferred it? What work does each person actually do? What kind of document is this, who produced it, and what evidence supports it? Who and what were involved in an incident?**

External organizations should therefore be a **supporting reference vocabulary**, not the centre of the feature. The existing Team, SCP, Personnel, Entry, Project, and Incident systems remain the centre of PASS.

The research supports this approach. The SCP Wiki describes a broad range of Foundation departments and specialized work rather than a research-only workforce.[1] Its clearance guidance separately describes researchers, containment specialists, security officers, tactical response officers, field agents, task-force operatives, and site leadership.[2] The personnel dossier also demonstrates that meaningful personnel records combine role, specialty, assignment, prior affiliation, and documented history instead of using a single generic job field.[3]

## What PASS already has

PASS already has a strong fixed structure. SCPs have a complete PASS classification layer, custody, site, clearance, procedures, description, and research lead. Personnel have class, department, position, role, division, site, clearance, access, permissions, restrictions, and auditable Entries. Teams, Projects, structured documents, and general Incident Reports already create the relationship system.

The improvement should **extend these fixed structures**, not replace them or make them rearrangeable.

| Existing PASS record | Current strength | Missing contextual detail |
|---|---|---|
| SCP profile | Classification, custody, containment, description | Origin, source, acquisition, provenance confidence, relevant expertise |
| Personnel dossier | Class, access, department, role, entries | Occupational family, specialty, duty status, service relationship, supervisor/assignment context |
| Team | Lead, members, objective, one linked SCP | Operational posture, multiple SCP scope, external liaison context |
| Entry | Owner, folder, title, category, blocks, typeface | Document function, author/source, evidence posture, related Incident or Project |
| Project | Mandate, linked SCPs/personnel/Teams | Project type, external stakeholder context, operational phase |
| Incident Report | General class, severity, summary, linked records | Structured involvement roles and evidence-aware external-party claims |

## 1. SCP profiles: add a fixed Origin & Provenance section

An SCP’s classification must stay independent from who created or supplied it. A product created by Dr. Wondertainment can still be Safe, Keter, Ticonderoga, or something else; its provenance should never distort PASS ACS.

The dossier should gain one fixed section placed after **PASS Classification** and before **Containment Procedures**.

| Field | Controlled approach | Example for the user’s case |
|---|---|---|
| **Origin classification** | Manifested; discovered in situ; recovered from external custody; manufactured / created; inherited legacy record; unknown; custom | Manufactured / created |
| **Originating person or organization** | Optional controlled reference or free-text custom name | Dr. Wondertainment |
| **Acquisition pathway** | Field recovery; voluntary transfer; seizure; purchase / liquidation; inherited transfer; cooperative handover; unknown | Recovered from a retail distribution site |
| **Provenance confidence** | Confirmed; corroborated; assessed; disputed; unknown | Confirmed |
| **Origin note** | Short narrative, not a second Description | Packaging and product records attribute manufacture to Dr. Wondertainment |
| **Primary specialist domains** | Optional tags, with custom values | Child-safety review; anomalous consumer products; memetics |

This is more realistic than writing “Dr. Wondertainment” somewhere inside an unstructured description. The vendor becomes searchable across SCPs, Entries, Projects, and Incidents, while the free-text note preserves uncertainty. It also reflects that entities such as Dr. Wondertainment, Prometheus Labs, Anderson Robotics, and MC&D are useful as **provenance or supply-chain context**, not automatically as hostile actors.[4] [5] [6] [7]

## 2. Personnel: separate job, specialty, status, and relationship

The current `department`, `position`, `role`, and `division` fields overlap too much. A realistic dossier should distinguish **what a person does**, **where they are assigned**, and **what special context applies to their service**.

The existing Personnel Class must remain a separate safety/exposure classification. A Class C person may be a researcher, medic, containment technician, security officer, archivist, engineer, or janitor; no job should imply a personnel class or a clearance level.[2]

### Fixed Personnel service section

| Field | Purpose | Example values |
|---|---|---|
| **Occupational family** | Broad duty family for directory filtering | Administration; Research & Analysis; Containment Operations; Security & Response; Medical & Psychological; Field Operations; Information & Records; Infrastructure & Logistics; Specialist Services; Support Services; Custom |
| **Position title** | The actual job, kept editable | Anomalous Psychiatrist; Tactical Forensics Lead; Paratechnology Specialist |
| **Specialty tags** | Narrow expertise, optionally multiple | Thaumaturgy; pathology; tactical forensics; applied occultism; records security; animal care |
| **Duty status** | Present service condition, separate from access status | Active; assigned off-site; temporary restriction; quarantine; leave; missing; separated; deceased; custom |
| **Reporting relationship** | Supervisor or command lead, optional local personnel link | Reports to Dr. Alexander Grimm |
| **Service relationship** | Foundation employee; liaison; contractor; former affiliate; person of interest; detainee; unknown | Former affiliate — GOC |
| **Associated organization** | Optional supporting reference only | FBI UIU; GOC; Dr. Wondertainment |
| **Relationship confidence** | Stops allegations from becoming fact | Confirmed; assessed; self-reported; disputed; unknown |

The directory should receive **Occupational Family** and **Duty Status** filters beside the existing Personnel Class filter. This would make it possible to find all medical personnel, all security personnel, all containment staff, all records staff, or all quarantined people without confusing role with Class A–E.

This makes the user’s Team notes work naturally. Dr. Sofia Adler becomes `Medical & Psychological → Anomalous Psychiatrist`; Agent Peter Klein becomes `Field Operations → Tactical Forensics Lead`; Agent William Strong becomes `Security & Response → High-Security Containment Officer`; and Specialist Tobias Lane becomes `Specialist Services → Paratechnology Specialist`. The names remain user-created data; PASS does not pre-populate them.

## 3. Teams: turn a simple member list into an operational unit record

The existing Team record is the correct home for the five groups supplied by the user. They should **not** become external-organization entries and should not ship as default data.

| New fixed Team field | Purpose | Example |
|---|---|---|
| **Operational posture** | What the Team is built to do | Research; investigation; response; containment support; analysis; liaison; custom |
| **Command lead** | Rename the existing lead in the interface, not the underlying meaning | Dr. Alexander Grimm |
| **Primary specialist domains** | Explains why the members belong together | Psychiatry; pathology; anomalous medicine |
| **Assigned SCP scope** | Replace the one-SCP limit with a clearance-filtered multi-SCP list | Several SCP files, or none |
| **External interface** | Optional organization relationship only when relevant | UIU liaison; GOC deconfliction |
| **Readiness posture** | Operational availability separate from Team Status | Routine; on-call; activated; restricted |

The five suggested Teams can then be made exactly as local data:

| User Team | PASS operational posture | Suggested domains |
|---|---|---|
| SCP Research Team | Research | Research coordination; psychiatry; pathology |
| Investigation Task Force | Investigation | Tactical forensics; materials analysis; site liaison |
| SCP Anomaly Response Unit | Response | Security; containment support; emergency command |
| Omega Research Unit Task Force | Analysis | Thaumaturgy; anomalous energy; ethics liaison |
| SCP Containment & Analysis Group | Containment support | High-security containment; paratechnology |

## 4. Entries: make documents traceable rather than merely categorized

Entries already support folders, document blocks, custom typefaces, PDF/TXT export, and owner-specific libraries. The missing improvement is **document context**, not another visual editor.

### Entry metadata

| Field | Controlled values | Why it improves realism |
|---|---|---|
| **Document function** | Internal memorandum; research record; containment log; interview; medical / psychological evaluation; security report; recovered document; external correspondence; amendment; incident attachment; custom | An Entry can explain what it is beyond a generic category. |
| **Prepared by** | Optional readable Personnel link, otherwise active session credential | Establishes an author without inventing a profile. |
| **Source / origin** | Internal; recovered; external correspondence; system-generated; unknown | Distinguishes Foundation writing from a found document. |
| **External reference** | Optional organization/person source | A recovered product manual can cite Dr. Wondertainment. |
| **Information confidence** | Confirmed; corroborated; assessed; alleged; disputed; unknown | Makes uncertain claims legible. |
| **Related Incident / Project** | Optional clearance-filtered link | Keeps a document discoverable from operational records. |
| **Effective date** | Optional event/document date separate from creation time | Lets a historical document be recorded honestly. |

The owner record remains the access boundary. An Entry should inherit the SCP or Personnel file’s clearance unless an explicit future document-clearance feature is approved; otherwise a hidden document-level access system would create unnecessary complexity.

## 5. Projects: record the type of work, not only the linked objects

Projects already have the correct relationship lists. They need a small fixed **Operational Context** block.

| Field | Values |
|---|---|
| **Project type** | Research; containment modernization; recovery; incident remediation; liaison; procurement review; information-security review; custom |
| **External stakeholders** | Optional organization relationship with cooperative, monitored, adverse, disputed, or unknown posture |
| **External purpose** | Liaison; monitoring; recovery provenance; acquisition review; deconfliction; counter-intelligence; custom |
| **Phase** | Planning; active; paused; closed; inherited from current Project Status where possible |

This lets a Project coordinate a team, several SCPs, personnel, and an external context without describing every relationship in a free-text mandate.

## 6. Incident Reports: replace flat involvement lists with roles and evidence

Incident Reports are already general enough. The important next step is making their links meaningful.

| Relationship | New role field | Example values |
|---|---|---|
| **SCP involvement** | SCP role | Primary subject; affected anomaly; recovered material; containment asset; mentioned only |
| **Personnel involvement** | Personnel role | Reporter; witness; affected person; responder; subject; supervisor; medical reviewer |
| **Team involvement** | Team role | Response owner; investigating unit; containment support; medical support; liaison |
| **External involvement** | External role and evidence status | Confirmed actor; suspected actor; claimant; source; victim; partner; observer; unknown |
| **Entry link** | Record function | Initial report; evidence attachment; interview; medical follow-up; closure memorandum |

The current single `externalInvolvement` narrative should remain as an optional **narrative note**, but the structured relationship should be the searchable source of truth. For example, a Chaos Insurgency breach can be recorded as `Suspected actor — assessed`, while a Dr. Wondertainment manufacturing origin belongs to the SCP’s provenance—not automatically the incident’s actor.

## The small supporting organization vocabulary

Only after these field improvements should PASS include a controlled reference vocabulary. It does not need a dedicated encyclopedic workflow in the first release. It is a compact selector used by the fields above, with user-created fallback.

| Initial reference type | Example use |
|---|---|
| **Manufacturer / supplier** | Dr. Wondertainment; Prometheus Labs; Anderson Robotics; MC&D |
| **Government / treaty body** | GOC; FBI UIU; GRU Division “P”; Horizon Initiative |
| **Network / movement** | Chaos Insurgency; Serpent’s Hand; AWCY?; Gamers Against Weed |
| **Ideological tradition / sect** | Church of the Broken God; Sarkic traditions; Fifth Church |
| **Custom external entity** | The user’s own organization, a specific cell, a local agency, or a canon-variant group |

No SCP, Personnel profile, Team, Entry, Project, or Incident will be created automatically. The selector exists only when the user chooses a relationship. This respects the blank registry requirement.

## Recommended build order

| Stage | Scope | Why it comes first |
|---|---|---|
| **1. Personnel and Teams** | Occupational families, specialties, duty status, service relationship; Team posture, multi-SCP scope | Immediately makes the user’s notes usable. |
| **2. SCP provenance** | Origin, creator/source, acquisition, confidence, specialist domains | Directly supports creator cases such as Dr. Wondertainment. |
| **3. Entries** | Document function, source, author, evidence status, Project/Incident link | Gives the world-building a reliable documentary form. |
| **4. Incidents and Projects** | Structured involvement roles and external stakeholder links | Makes operational records searchable and grounded. |
| **5. Supporting vocabulary** | Curated organizations and custom entries | Supports the above fields without taking over the app. |

## Approval requested

Before implementation, please approve or change these three choices:

1. Should PASS start with **Personnel & Teams** as the first implemented stage, or should **SCP provenance** come first because you already have creator-origin SCPs?
2. Should the initial supporting vocabulary contain **only the organizations you personally plan to use**, or the broader curated reference list with a custom option?
3. For external relationships, should `alleged` and `disputed` be available as evidence states, or should PASS use only `confirmed`, `assessed`, and `unknown` to keep the interface simpler?

## References

[1]: https://scp-wiki.wikidot.com/departments "SCP Wiki — Foundation Departments"
[2]: https://scp-wiki.wikidot.com/security-clearance-levels "SCP Wiki — Security Clearance Levels"
[3]: https://scp-wiki.wikidot.com/personnel-and-character-dossier "SCP Wiki — Personnel and Character Dossier"
[4]: https://scp-wiki.wikidot.com/dr-wondertainment-hub "SCP Wiki — Dr. Wondertainment Hub"
[5]: https://scp-wiki.wikidot.com/prometheus-labs-hub "SCP Wiki — Prometheus Labs Hub"
[6]: https://scp-wiki.wikidot.com/anderson-robotics-hub "SCP Wiki — Anderson Robotics Hub"
[7]: https://scp-wiki.wikidot.com/marshall-carter-and-dark-hub "SCP Wiki — Marshall, Carter and Dark Hub"
