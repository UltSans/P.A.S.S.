import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, PropsWithChildren, useContext, useEffect, useMemo, useState } from "react";

import type { ClearanceLevel } from "@/lib/registry-types";
import { normalizeClearanceLevel } from "@/lib/registry-utils";

const SESSION_KEY = "pass.session-profile.v1";

export type Designation = "Dr." | "Researcher" | "Agent" | "SCP-" | "O5-" | "Administrator";
export type SessionStage = "booting" | "credential" | "authorizing" | "authorized";

export interface SessionProfile {
  designation: Designation;
  name: string;
  clearanceLevel: ClearanceLevel;
}

interface SessionContextValue {
  profile: SessionProfile;
  hydrated: boolean;
  stage: SessionStage;
  showCredential: () => void;
  requestAccess: (profile: SessionProfile) => void;
  finishAuthorization: () => void;
  endSession: () => void;
}

const defaultProfile: SessionProfile = { designation: "Dr.", name: "", clearanceLevel: "Level 1" };
const SessionContext = createContext<SessionContextValue | null>(null);

export function normalizeSessionProfile(value: unknown): SessionProfile {
  const candidate = value && typeof value === "object" ? value as Partial<SessionProfile> : {};
  const designation: Designation = candidate.designation === "Researcher" || candidate.designation === "Agent" || candidate.designation === "SCP-" || candidate.designation === "O5-" || candidate.designation === "Administrator" ? candidate.designation : "Dr.";
  return { designation, name: typeof candidate.name === "string" ? candidate.name : "", clearanceLevel: normalizeClearanceLevel(candidate.clearanceLevel) };
}

export function SessionProvider({ children }: PropsWithChildren) {
  const [profile, setProfile] = useState<SessionProfile>(defaultProfile);
  const [hydrated, setHydrated] = useState(false);
  const [stage, setStage] = useState<SessionStage>("booting");

  useEffect(() => {
    AsyncStorage.getItem(SESSION_KEY)
      .then((saved) => {
        if (saved) setProfile(normalizeSessionProfile(JSON.parse(saved)));
      })
      .catch(() => undefined)
      .finally(() => setHydrated(true));
  }, []);

  const value = useMemo<SessionContextValue>(() => ({
    profile,
    hydrated,
    stage,
    showCredential: () => setStage("credential"),
    requestAccess: (nextProfile) => {
      setProfile(nextProfile);
      void AsyncStorage.setItem(SESSION_KEY, JSON.stringify(nextProfile));
      setStage("authorizing");
    },
    finishAuthorization: () => setStage("authorized"),
    endSession: () => setStage("credential"),
  }), [profile, hydrated, stage]);

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession() {
  const context = useContext(SessionContext);
  if (!context) throw new Error("useSession must be used inside SessionProvider");
  return context;
}
