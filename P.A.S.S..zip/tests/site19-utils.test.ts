import { describe, expect, it } from "vitest";

import { SITE19_PERSONNEL_ROUTES, SITE19_SECTORS } from "../lib/site19-registry";
import { isSite19Address, visibleFacilitySectors } from "../lib/site19-utils";

describe("Site-19 Facility Records", () => {
  it("shows Level 3 divisions to a Level 3 reader without exposing Level 4 or Level 5 detail", () => {
    const visible = visibleFacilitySectors("Level 3", SITE19_SECTORS);
    expect(visible.some((division) => division.id === "l3-research")).toBe(true);
    expect(visible.some((division) => division.id === "l4-isolation")).toBe(false);
    expect(visible.some((division) => division.id === "l5-contingency")).toBe(false);
  });

  it("permits only division designations with an optional large-zone suffix", () => {
    expect(isSite19Address("S19-L3-03")).toBe(true);
    expect(isSite19Address("S19-L3-03-B")).toBe(true);
    expect(isSite19Address("S19-L3-3-B")).toBe(false);
    expect(isSite19Address("S19-L6-03-B")).toBe(false);
    expect(isSite19Address("S19-L3-03-B-R14")).toBe(false);
  });

  it("registers the approved facility-only division count for each level", () => {
    const count = (level: string) => SITE19_SECTORS.filter((division) => division.level === level).length;
    expect(count("L1")).toBe(6);
    expect(count("L2")).toBe(6);
    expect(count("L3")).toBe(7);
    expect(count("L4")).toBe(7);
    expect(count("L5")).toBe(6);
  });

  it("keeps REF-05 free of individual SCP names and room-level content", () => {
    const facilityText = JSON.stringify(SITE19_SECTORS);
    expect(facilityText).not.toContain("SCP-");
    expect(SITE19_SECTORS.every((division) => division.zones.length >= 3)).toBe(true);
    expect(SITE19_SECTORS.every((division) => /^S19-L[1-5]-\d{2}$/.test(division.code))).toBe(true);
  });

  it("keeps custody, research, and security personnel movement on separate purpose-built routes", () => {
    const custody = SITE19_PERSONNEL_ROUTES.find((route) => route.id === "custody");
    const research = SITE19_PERSONNEL_ROUTES.find((route) => route.id === "research");
    const security = SITE19_PERSONNEL_ROUTES.find((route) => route.id === "security");
    expect(custody?.normalRoute).toContain("Custody Core");
    expect(custody?.exclusion).toContain("No L2 staff arrival");
    expect(research?.controlledTransition).toContain("Heavy Gate");
    expect(security?.exclusion).toContain("does not open research cells");
  });
});
