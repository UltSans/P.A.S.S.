# PASS Terminal and Projects Proposal

## Decision summary

The Terminal should become a **secure operational jump point**, not a dashboard full of passive numbers. Its purpose is to tell the authenticated user that the local system is available, then send them to a specific system.

The proposed revision removes **Containment Register** and **Recently Accessed**. Neither changes a decision, grants useful context, nor offers a direct workflow. The Script Library also stops showing visible usage counts; that information remains an internal deletion safeguard only.

The new practical capability is **Projects**. It is intentionally separate from Teams:

| Entity | What it represents | Example |
|---|---|---|
| **Personnel** | An individual and their credentials. | Dr. Amina Rahal. |
| **Team** | A working group of people with a local mandate. | Project Hallow research team. |
| **Project** | A controlled multi-record program that can involve several SCPs, people, and teams. | Project Pneuma. |

## Sparse Terminal

| Terminal element | Keep or remove | Reason |
|---|---|---|
| Session clearance and system state | **Keep, compactly** | Confirms the reader’s current authorization context and that the local registry is available. |
| Database | **Keep** | Opens the controlled reference system. |
| Script Library | **Keep** | Opens local document-typeface administration. |
| Projects | **Add** | Opens active operational programs that cut across the registries. |
| Containment Register bar | **Remove** | A passive count of managed records does not tell the user what to do next. |
| Recently Accessed list | **Remove** | A local record app should not invent “recent activity” as an operational feature. |
| Generic activity feed | **Do not add** | Only real approval, review, or deadline events should ever appear here later. |

The first version of Terminal should therefore show only the compact system-status block and three clear destinations: **Database**, **Script Library**, and **Projects**.

## Script Library correction

The Script Library should show a typeface’s name, source filename, format, local preview, and management actions. It should **not** display how many Entry blocks use it. A language is not a resource whose popularity needs to be measured.

| Situation | Correct behavior |
|---|---|
| View library | Show the local typeface catalog, preview, and import control. |
| Assign typeface in a document | The selected script is available as a rendering choice. |
| Attempt removal | PASS privately checks whether Entry blocks reference the typeface. |
| Typefaces are referenced | Show only the consequence: the preserved Unicode text will fall back to Foundation Standard. Do not expose a numeric usage count. |

This retains the safety feature without turning the library into an analytics screen.

## Projects model

A Project is a controlled, long-running program. It does not replace any linked record. It gives the Foundation an operational frame around related work.

| Project field | Purpose | Required in first version? |
|---|---|---|
| **Project code** | Stable internal identifier, such as `PN-01` or `PNEUMA-19`. | Yes |
| **Project title** | Human-readable program name, such as `Project Pneuma`. | Yes |
| **Status** | Planning, Active, Review Hold, Suspended, or Closed. | Yes |
| **Project clearance** | Minimum reader clearance required to view the project overview. | Yes |
| **Mandate** | What the project exists to investigate, contain, recover, or coordinate. | Yes |
| **Project brief** | The current controlled summary, scope, and known limits. | Yes |
| **Linked SCP files** | Zero or more anomaly files covered by the program. | Yes |
| **Assigned personnel** | Individual participants whose involvement must be visible even when they belong to different teams. | Yes |
| **Assigned teams** | One or more teams carrying out parts of the work. | Yes |
| **Review date** | Formal next review or authorization date. | Yes |
| **Project entries / folders** | Program-level briefs, meeting records, milestones, or approval documents. | Later, after the core project profile works. |

### Access and realism rules

1. A Project link **does not grant access** to an SCP, person, team, or location. The user must still satisfy that record’s own clearance rules.
2. A Project may reference multiple SCPs and teams. This is why it is not merely a renamed team.
3. A person can be assigned directly to a Project without being a member of every linked team.
4. A Project profile should read like a controlled program file, not a generic productivity board.
5. Closed projects retain their record, relationships, and brief for audit history.

## Project Pneuma example

| Field | Example use |
|---|---|
| Project code | `PNEUMA-19` |
| Status | Active |
| Mandate | Coordinate investigation of related anomalous phenomena and their effects on personnel. |
| Linked SCPs | Several SCP files, each retaining its own containment and access rules. |
| Assigned personnel | Selected researchers, medical staff, and security liaison roles. |
| Assigned teams | More than one team, each with a defined workstream. |
| Brief | A current scope statement and authorized research boundaries. |

## Recommended implementation order

| Stage | Change | Why this comes first |
|---|---|---|
| **1** | Remove the Terminal containment and recent-activity sections; add the Projects destination. | Restores Terminal’s purpose immediately. |
| **2** | Remove visible Script Library usage counts while preserving the deletion fallback warning. | Corrects the library without affecting stored typefaces or documents. |
| **3** | Add Project data contracts, local persistence migration, project directory, and project profile. | Establishes the core system. |
| **4** | Add a project creation/editor workflow with SCP, personnel, and team selectors. | Makes the model usable. |
| **5** | Add project-level entries and folders only after the base relationship model is stable. | Avoids duplicating document systems prematurely. |

## Approval question

If approved, the first implementation milestone will include Stages 1–4 only. Project-level Entries and folders will remain deferred, and Site-19 mapping will remain untouched.
