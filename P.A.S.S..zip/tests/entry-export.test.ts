import { describe, expect, it } from "vitest";

import { entryBlocks, pdfHtml, plainTextExport } from "../lib/entry-export";
import type { TypefaceRecord } from "../lib/registry-types";

const typeface: TypefaceRecord = { id: "typeface-enchanting", displayName: "Enchanting Table", fileName: "enchanting-table.ttf", fileUri: "file:///font.ttf", fontFamily: "PASS-typeface-enchanting", format: "ttf", createdAt: "2026-08-19T00:00:00.000Z" };

describe("PASS Entry export", () => {
  it("preserves structured Unicode source text in a UTF-8 TXT export", () => {
    const entry = { title: "Interview <01>", category: "Interview", updatedAt: "2026-08-19T00:00:00.000Z", document: "fallback", documentBlocks: [{ id: "one", kind: "Transcript" as const, speaker: "Interviewer", text: "State your designation." }, { id: "two", kind: "Recovered Script" as const, speaker: "Entity", text: "𐌀𐌁 ᚠᚢᚦ" }] };
    const exported = plainTextExport("SCP-049 — Plague Doctor", entry);
    expect(exported).toContain("𐌀𐌁 ᚠᚢᚦ");
    expect(exported).toContain("Entity:");
    expect(entryBlocks(entry)).toHaveLength(2);
  });

  it("falls back to a legacy document when an Entry has no structured blocks", () => {
    const entry = { title: "Legacy", category: "Administrative", updatedAt: "2026-08-19T00:00:00.000Z", document: "Preserved legacy body." };
    expect(entryBlocks(entry)).toEqual([{ id: "legacy-export", kind: "Paragraph", text: "Preserved legacy body." }]);
  });

  it("embeds only referenced reusable typefaces and escapes exported HTML", () => {
    const entry = { title: "<Unsafe & Title>", category: "Interview", updatedAt: "2026-08-19T00:00:00.000Z", document: "", documentBlocks: [{ id: "english", kind: "Paragraph" as const, text: "Plain English." }, { id: "script", kind: "Recovered Script" as const, typefaceId: typeface.id, text: "<glyph & script>" }] };
    const rendered = pdfHtml("SCP-049", entry, [typeface], { [typeface.id]: "Zm9udA==" });
    expect(rendered).toContain("@font-face");
    expect(rendered).toContain("PASS-typeface-enchanting");
    expect(rendered).toContain("&lt;glyph &amp; script&gt;");
    expect(rendered).toContain("&lt;Unsafe &amp; Title&gt;");
  });
});
