# PASS / Site-19 — Level 1 Reassessment

## What was wrong with the earlier model

The earlier L1 model treated a civilian-facing cover operation, visitor processing, and ordinary external liaison as default functions. That was a generic secure-campus idea, not a Foundation-first decision.

The Foundation is clandestine. The facility reference permits public Sites, disguised Locations, and remote Areas, but does not require a public interface. Its doctrine of compartmentalization, disinformation, evidence control, and need-to-know argues for **minimizing exposure before it happens**, not accepting routine public contact and cleaning it up afterward. [1] [2] [3] [4]

> **Corrected principle:** Level 1 is not a lobby. It is the outer security and transfer layer of a hidden containment complex.

## The three possible surface models

| Model | What it means | Fit for a large, mixed-risk Site-19 | Decision |
|---|---|---|---|
| **Open civilian cover operation** | A genuinely customer-facing or visitor-facing business/office facility with routine outsiders. | Poor. It creates unnecessary witnesses, ordinary traffic, records, and physical observation. | **Reject.** |
| **Disguised institutional compound** | The public may know a restricted government/corporate/industrial site exists, but its real purpose is hidden. External contact is pre-cleared and never reaches internal operations. | Possible, especially where logistics or large surface infrastructure must be explained. | Viable only as a minimal surface explanation, not as an operational public business. |
| **Remote restricted reservation** | The real site is placed within a Foundation-controlled restricted area whose location, access, and public records are tightly managed or obscured. | Strongest default for a huge site that combines active containment, research, deep storage, and high-consequence isolation. | **Recommended baseline.** |

The recommended baseline is therefore a **remote restricted reservation**. It does not require a public-facing organization at the gate. It may use false registries, sealed land access, controlled contractors, and external cover narratives when needed, but those are managed to keep outsiders away—not to invite them in.

## Reassessing every prior L1 function

| Earlier function | Foundation-first reassessment | Retain, remove, or replace |
|---|---|---|
| Public Cover and External Liaison | A public-facing office is unjustified. Site-level external contact should be minimal; broader disinformation is a Foundation service, not a public desk at Site-19. | **Replace** with a restricted **Cover-Control and External Handoff Cell**. |
| Personnel Arrival and Visitor Processing | Routine visitors are incompatible with the site. Foundation staff still need a secure arrival point; rare outside arrivals need pre-clearance and immediate escort/containment of their exposure. | **Replace** with a **Cleared Personnel and Restricted Arrival Gate**. |
| Vehicle and Loading Control | A major underground site still requires people, equipment, food, fuel, medical supplies, and controlled transfers. The need is real, but drivers/cargo must not enter operational routes. | **Retain, reshape** as a **Secure Receiving and Transfer Bay**. |
| Surface Security | Essential, but it should not look like a conventional security desk. Its job is to deny approach, identify intrusion, control the reservation boundary, and contain/redirect any exposure. | **Retain** as **Perimeter Security and Surface Control**. |
| Surface Technical Support | Essential for roads, power interfaces, communications, access barriers, drainage/ventilation interfaces, and concealed infrastructure. | **Retain** as **Surface Infrastructure Support**. |
| Visitor route | No ordinary visitor route should exist. | **Remove.** |
| Public lobby / ordinary reception | No operational reason; it creates exposure. | **Remove.** |

## Corrected Level 1 mission

> **L1 exists to deny, filter, and compartmentalize contact between the outside world and Site-19.**

It must receive only pre-cleared Foundation personnel, secured freight, authorized custody transfers, and exceptional controlled arrivals. It must then place each into a separate internal route. Any outside contact that does not meet those conditions is stopped at the reservation boundary and handled through the appropriate Foundation cover or information-control channel.

## Proposed Level 1 divisions

| Division | Necessary work | Who uses it | What it never does |
|---|---|---|---|
| **Reservation Perimeter and Surface Control** | Monitors the restricted area, controls physical approaches, detects intrusion, maintains access barriers, and manages surface emergency boundaries. | Surface security and authorized response personnel. | It never serves as a public security office or normal site reception. |
| **Cleared Personnel Access Gate** | Confirms identity and current authorization of arriving Foundation personnel, separates personal items/unauthorized material before entry, and directs staff to internal access. | Pre-cleared Foundation staff only. | It does not manage walk-ins or send people directly to containment levels. |
| **Restricted Arrival Hold** | Holds rare pre-approved contractors, government/cover contacts, or exceptional external arrivals until a named escort/owner assumes responsibility. | Rare authorized external arrivals; designated escorts. | It does not function as visitor services or allow self-directed access. |
| **Secure Receiving and Transfer Bay** | Accepts cargo and controlled transfers at an outer boundary, verifies records, moves cleared material into sealed internal logistics, and keeps external drivers away from the actual site. | Foundation logistics personnel; externally controlled delivery handoff. | It does not share routes with staff arrival or L2/L3 personnel lifts. |
| **Custody Transfer Gate** | Receives authorized custody transfers—including future D-Class or other controlled transfers—into an isolated internal chain. | Authorized custody/security teams. | It never connects to ordinary staff, freight, or clinical circulation. |
| **Surface Infrastructure Support** | Maintains surface utilities, communications interfaces, road/approach control, ventilation/power interfaces, and concealment-critical infrastructure. | Cleared technical staff. | It does not grant general technical access to lower-level containment functions. |
| **Cover-Control and External Handoff Cell** | Maintains the minimum records and controlled contact needed for the chosen surface story; routes incidents/evidence/exposure to the appropriate central Foundation function. | A very small site-authorized administration/security group. | It does not run an open business, public-relations desk, or general disinformation bureau. |

## Corrected Level 1 routes

| Route | Origin → destination | Why it exists | Boundary |
|---|---|---|---|
| **Staff arrival route** | Cleared Personnel Access Gate → L2 Staff Access. | Lets authenticated Foundation staff enter the institutional core. | Staff checkpoint; no direct L3/L4/L5 entry. |
| **Freight route** | Secure Receiving Bay → sealed logistics route → L3 Material Intake or L5 Deep Logistics. | Supplies active operations and long-hold custody without exposing staff routes. | Freight gate and internal material control. |
| **Custody-transfer route** | Custody Transfer Gate → dedicated secure internal chain → L3 custody receiving. | Prevents controlled subjects/transfers from entering normal staff or logistics spaces. | Heavy custody boundary. |
| **Restricted-arrival route** | Restricted Arrival Hold → named escort → approved L2 destination only. | Allows an exceptional needed external contact while constraining its knowledge and movement. | Escort-controlled boundary; no self-navigation. |
| **Surface egress route** | Internal emergency core → protected surface egress. | Moves people out during an authorized emergency. | Egress-only; never a daily entry shortcut. |

## The unresolved decision

The model deliberately does **not** choose Site-19’s public story. The facility can either be remote enough to need no active public explanation, or maintain a minimal disguised institutional identity to explain staff, logistics, and infrastructure. That decision should be made only after the user decides whether Site-19 is meant to be geographically remote, adjacent to a populated area, or embedded behind another restricted institution.

Until then, the real, functional Level 1 is clear: **restricted reservation, surface control, pre-cleared entry, separated staff/freight/custody routes, and no ordinary public contact.**

## References

[1] [SCP Foundation Main Page](https://scp-wiki.wikidot.com/)  
[2] [Foundation Facilities](https://scp-wiki.wikidot.com/secure-facilities-locations)  
[3] [Amnestic Use Guide](https://scp-wiki.wikidot.com/amnestic-orientation-manual)  
[4] [Disinformation Bureau Orientation](https://scp-wiki.wikidot.com/disinformation-bureau-orientation)
