import { describe, expect, it } from "vitest";

import { defaultFacilityAssignment } from "../lib/personnel-profile-utils";

describe("defaultFacilityAssignment", () => {
  it("preserves a recorded Site-19 division assignment", () => {
    expect(defaultFacilityAssignment({ site: "Site-19", facilityAssignment: "S19-L3-03 / Research, Analysis & Interview Division" })).toBe("S19-L3-03 / Research, Analysis & Interview Division");
  });

  it("migrates legacy Site-19 personnel without inventing a division", () => {
    expect(defaultFacilityAssignment({ site: "Site-19" })).toBe("No current Site-19 division assignment recorded");
  });

  it("does not imply a Site-19 assignment for another site", () => {
    expect(defaultFacilityAssignment({ site: "Site-64" })).toBe("Not assigned to Site-19");
  });
});
