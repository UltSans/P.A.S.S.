import { describe, expect, it } from "vitest";

import { isManagedTypefaceUri, typefaceRemovalMessage } from "../lib/typeface-cleanup";

describe("typeface cleanup", () => {
  it("only treats PASS document-directory copies as removable local assets", () => {
    expect(isManagedTypefaceUri("file:///data/user/0/pass/files/pass-typefaces/typeface-1.ttf", "file:///data/user/0/pass/files/", "pass-typefaces")).toBe(true);
    expect(isManagedTypefaceUri("content://downloads/example.ttf", "file:///data/user/0/pass/files/", "pass-typefaces")).toBe(false);
  });

  it("describes immediate, deferred, and unmanaged cleanup accurately", () => {
    expect(typefaceRemovalMessage("removed")).toContain("local file");
    expect(typefaceRemovalMessage("queued")).toContain("next PASS launch");
    expect(typefaceRemovalMessage("not-managed")).toContain("external copy");
  });
});
