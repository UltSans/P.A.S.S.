# PASS ACS Taxonomy Audit — Draft v1.1

## The classification problem

The current ACS component is a **presentation format**, not a complete operational taxonomy. It puts diverse terms into one optional “Secondary Class” slot even when they answer fundamentally different questions. That is why Ticonderoga and Thaumiel conflict in the component despite describing different facts about an anomaly.

PASS should not solve this by treating every label as interchangeable or by turning every specialist term into a main-button option. Its stable internal standard should apply one rule:

> **Each classification field answers one operational question only. A term belongs in the field that matches its actual meaning, not the field where a current icon set happens to display it.**

This follows the Classification Committee Memo’s distinction between containment challenge, public disruption, immediate personnel risk, and auxiliary information. It is also consistent with the Object Classes guide, which explicitly says object classes measure containment difficulty rather than inherent danger. [1] [2]

## PASS record structure

| PASS field | Operational question | Examples |
|---|---|---|
| **Containment Class** | What is the Foundation’s actual ability and obligation to contain this anomaly? | Safe, Euclid, Keter, Ticonderoga, Archon, Cernunnos |
| **Terminal Escalation** | Has the anomaly reached a terminal containment condition or generated a credible catastrophic scenario? | Apollyon condition; one or more named K-Class scenarios |
| **Custody** | Who is presently responsible for containment? | Foundation, external custodian/Argus, joint custody, unassigned |
| **Operational Role** | Does the anomaly have an approved strategic function? | None, Thaumiel, custom role |
| **Response Posture** | Does response require an exceptional departure from ordinary covert practice? | Standard covert response, Tiamat, custom posture |
| **Containment Configuration** | Is containment dependent on a special system relationship rather than a single procedure? | Standard, Hiemal, custom configuration |
| **Lifecycle Status** | What is the anomaly’s current administrative or ontological state? | Active, Pending, Uncontained, Neutralized, Explained, Decommissioned |
| **Disruption Class** | How widely can the anomaly disturb normalcy or the Veil if uncontrolled? | Dark through Amida |
| **Risk Class** | How severe and recoverable are its effects on an affected individual? | Notice through Critical |
| **Custom Designation** | What needed fact cannot be expressed by the stable vocabulary? | A documented custom value in any field |

## 1. Containment Class

This is the primary classification axis. It concerns containment feasibility and purpose only; it is not a danger score.

| Class | PASS meaning | Why it belongs here |
|---|---|---|
| **Safe** | Reliable, routine containment is available. | Measures low containment difficulty. |
| **Euclid** | Containment is possible but needs active resources, further knowledge, or management of uncertainty. | Measures active but achievable containment difficulty. |
| **Keter** | Consistent containment is exceptionally difficult, costly, or unreliable. | Measures severe containment difficulty. |
| **Archon** | Containment is technically possible, but imposing it would create a worse result. | Measures a deliberate containment decision. |
| **Cernunnos** | Functional containment is possible, but its logistical or ethical costs outweigh the benefit. | Measures a deliberate containment decision. |
| **Ticonderoga** | The anomaly cannot be contained with current means and does not require conventional containment. | Measures a non-physical containment relationship. |
| **Custom Containment** | No core class accurately describes the feasible containment relationship. | Preserves rigor without forcing a false label. |

### Why Ticonderoga must stay here

Ticonderoga answers the same question as Safe, Euclid, and Keter: **what containment is possible and appropriate?** The Object Classes guide describes it as an anomaly that cannot be contained but does not need containment, often because it is ubiquitous or beyond current reach. It does not describe a secondary use, a damage level, a custody arrangement, or a response policy. Therefore PASS places it under **Containment Class**.

Ticonderoga is not a “low threat” label. A non-containable anomaly may still require high risk or disruption values; those are measured separately. It simply means that conventional physical containment is not the right operational answer.

## 2. Terminal Escalation

Terminal Escalation is a separately protected **exception layer**, not a default severity slider. It captures two linked but different facts: the Foundation’s terminal containment outlook and the civilization-scale or reality-scale event that might result. The SCP Wiki itself associates Apollyon with world-ending threats or a K-Class Scenario while separately defining K-Class scenarios as hypothetical situations with drastic effects on normality or reality. [1] [5]

| Terminal designation | PASS meaning | Mandatory companion record |
|---|---|---|
| **None / Not Triggered** | No terminal condition or credible K-Class scenario has been designated. | None. |
| **Apollyon Condition** | Containment is no longer viable and terminal-scale failure is expected, imminent, or already progressing. | A documented basis, projected horizon, responsible authority, and response plan. |
| **K-Class Scenario** | A named catastrophic scenario is credible, imminent, or manifest. This identifies the possible outcome, not an object class. | One or more scenario identifiers, definitions, evidence, scope, and current event state. |
| **Apollyon Condition + K-Class Scenario** | The anomaly is judged terminally uncontainable and is linked to a specified catastrophic outcome. | Both documentation sets above; neither value substitutes for the other. |

PASS deliberately makes the K-Class identifier **structured but non-prescriptive**. The reference list stresses that K-Class definitions do not have one fixed canon and documents usage rather than enforcing it. PASS may provide common identifiers such as XK only as referenced vocabulary, while requiring the file itself to define its selected scenario. [5]

This distinction prevents two errors. An anomaly may be Apollyon without an approved named K-Class designation if its terminal outcome is still under analysis. Conversely, a credible K-Class scenario can be generated by several anomalies, a conflict, or a Foundation failure without making any single source anomaly Apollyon.

## 3. Custody

**Argus is not a containment difficulty.** It states that another trusted organization has custody and the expertise to contain the anomaly. PASS therefore treats Argus as a custody state rather than forcing it into containment or a secondary slot. [1]

| Custody state | Meaning |
|---|---|
| **Foundation Custody** | The Foundation directly manages containment. |
| **External Custody — Argus** | A specified trusted organization is the active custodian. |
| **Joint Custody** | Containment responsibility is contractually shared. |
| **Unassigned / Disputed** | No recognized effective custodian exists. |

## 4. Operational Role

**Thaumiel** belongs here. It means the Foundation specifically uses the anomaly to contain, support, or protect against other anomalies. It does not explain whether the anomaly is itself easy to contain. [1]

| Role | Meaning |
|---|---|
| **None** | No approved anomaly-support role exists. |
| **Thaumiel** | Authorized containment-support or strategic use under explicit conditions. |
| **Custom Operational Role** | A defined, reviewed role not represented by the standard vocabulary. |

A Thaumiel record must name the authorization scope, use conditions, revocation conditions, and responsible authority. This prevents “Thaumiel” from becoming a vague synonym for “useful.”

## 5. Response Posture

**Tiamat** is best treated as a response posture. Its defining idea is that the anomaly poses an immediate threat that can only be addressed through Veil-breaking action. That tells responders what may be required; it does not itself describe containment feasibility. [3]

| Posture | Meaning |
|---|---|
| **Standard Covert Response** | Normal concealment and covert containment remain feasible. |
| **Tiamat** | Effective emergency response requires controlled, overt, Veil-breaking action. |
| **Custom Response Posture** | A documented nonstandard response requirement. |

## 6. Containment Configuration

**Hiemal** describes a containment arrangement in which interrelated anomalies keep one another in check. It does not replace the underlying containment class; it tells staff that the system, rather than any single object, is the containment mechanism. [4]

| Configuration | Meaning |
|---|---|
| **Standard** | The file’s procedures apply to one anomaly or ordinary linked components. |
| **Hiemal** | A specified set of anomalies or conditions mutually maintain containment. |
| **Custom Configuration** | A defined system dependency not represented above. |

## 7. Lifecycle Status

Pending, Uncontained, Neutralized, Explained, and Decommissioned should not compete with active containment classes. They describe **current status or outcome**, not a continuing theory of containment.

| Status | Meaning |
|---|---|
| **Active / Managed** | The anomaly remains active under approved procedures. |
| **Pending** | Evidence is insufficient for final classification. |
| **Uncontained / Active Incident** | Effective containment has not been established or has failed. |
| **Neutralized** | Anomalous properties have ceased. |
| **Explained** | The apparent anomaly has a complete non-anomalous explanation. |
| **Decommissioned** | The Foundation formally ended the anomaly or its containment program through authorized action. |

This resolves a major confusion in the standard lists. An anomaly can be **Keter + Uncontained** or **Ticonderoga + Managed**, but it should not be forced to choose between an operational class and a current status.

## 8. Disruption and Risk

The standard ACS scales remain intact because they answer clear, distinct questions.

| Scale | PASS use |
|---|---|
| **Disruption: Dark → Vlam → Keneq → Ekhi → Amida** | Estimate speed, reach, and recoverability of societal/Veil disruption if control fails. [2] |
| **Risk: Notice → Caution → Warning → Danger → Critical** | Estimate severity, immediacy, and recoverability of effects on an affected individual. [2] |

The values must be assessed against the **credible failure state**, not merely the anomaly’s best behavior. PASS permits a baseline and escalation assessment where an anomaly has distinct states.

## 9. Specialist and custom classes

The SCP Wiki’s esoteric-class resource explicitly warns that many esoteric labels are rare and not viable as routine documentation. PASS should therefore not claim that an ever-changing list of hundreds of narrative terms belongs in one default selector. [6]

Instead, it uses a **Classification Registry**:

| Registry layer | What it contains |
|---|---|
| **PASS Core** | The definitions in this document. These are default editor options. |
| **PASS Specialist** | Researched terms with a definition, source, mapped field, use criteria, and misuse warning. |
| **File Custom** | A record-specific designation with a mandatory rationale and approval note. |

Every custom designation—containment, terminal escalation, custody, role, response, configuration, disruption, risk, or status—must define its meaning and state why the stable alternatives do not fit.

## Proposed decision rule

Before choosing a label, the user asks these questions in order:

1. **Can and should the Foundation contain it?** Choose Containment Class.
2. **Is there a terminal containment condition or a credible catastrophic event?** Designate Terminal Escalation only when formally supported.
3. **Who actually holds containment responsibility?** Choose Custody.
4. **Does it have one formal strategic role?** Choose Operational Role.
5. **Does response require an exceptional open or system-dependent posture?** Choose Response Posture or Configuration.
6. **What is its present state?** Choose Lifecycle Status.
7. **If control fails, how broad is the Veil/public impact and how severe is individual harm?** Choose Disruption and Risk.

## References

[1] [SCP Wiki — Object Classes](https://scp-wiki.wikidot.com/object-classes)  
[2] [SCP Wiki — Anomaly Classification System Guide](https://scp-wiki.wikidot.com/anomaly-classification-system-guide)  
[3] [SCP Wiki — SCP-5866 and Tiamat rationale](https://scp-wiki.wikidot.com/scp-5866)  
[4] [SCP Wiki — SCP-3240 and Hiemal usage](https://scp-wiki.wikidot.com/scp-3240)  
[5] [SCP Wiki — A Comprehensive List of K-Class Scenarios](https://scp-wiki.wikidot.com/k-class-complete-list)  
[6] [SCP Wiki — A Comprehensive List of Esoteric Classes](https://scp-wiki.wikidot.com/esoteric-classes-complete-list)  
[7] [SCP Wiki — Classification Committee Memo](https://scp-wiki.wikidot.com/classification-committee-memo)
