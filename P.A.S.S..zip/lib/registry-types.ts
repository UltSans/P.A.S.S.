export const NOT_LISTED_SPECIFY = "Not Listed — Specify" as const;
export const SCP_CLASSIFICATION_OPTION_FIELDS = ["containmentClass", "custody", "operationalRole", "responsePosture", "containmentConfiguration", "lifecycleStatus", "terminalEscalation", "disruptionClass", "riskClass"] as const;
export type ScpClassificationOptionField = typeof SCP_CLASSIFICATION_OPTION_FIELDS[number];
export type ScpNamedClassificationOptions = Record<ScpClassificationOptionField, string[]>;
export type ContainmentClass = "Safe" | "Euclid" | "Keter" | "Ticonderoga" | "Archon" | "Cernunnos" | typeof NOT_LISTED_SPECIFY;
export type Custody = "Foundation Custody" | "External Custody — Argus" | "Joint Custody" | "Unassigned / Disputed" | typeof NOT_LISTED_SPECIFY;
export type OperationalRole = "No Formal Role" | "Thaumiel" | typeof NOT_LISTED_SPECIFY;
export type ResponsePosture = "Standard Covert Response" | "Tiamat" | typeof NOT_LISTED_SPECIFY;
export type ContainmentConfiguration = "Standard Configuration" | "Hiemal" | typeof NOT_LISTED_SPECIFY;
export type LifecycleStatus = "Active / Managed" | "Pending" | "Uncontained / Active Incident" | "Neutralized" | "Explained" | "Decommissioned" | typeof NOT_LISTED_SPECIFY;
export type TerminalEscalation = "None / Not Triggered" | "Apollyon Condition" | "K-Class Scenario" | "Apollyon Condition + K-Class Scenario" | typeof NOT_LISTED_SPECIFY;
export type DisruptionClass = "Dark" | "Vlam" | "Keneq" | "Ekhi" | "Amida" | typeof NOT_LISTED_SPECIFY;
export type RiskClass = "Notice" | "Caution" | "Warning" | "Danger" | "Critical" | typeof NOT_LISTED_SPECIFY;
export type ClearanceLevel = "Level 1" | "Level 2" | "Level 3" | "Level 4" | "Level 5";
export type AccessStatus = "Active" | "Restricted" | "Suspended";
export type TeamStatus = "Active" | "Observation" | "Standby";
export type ProjectStatus = "Planning" | "Active" | "Review Hold" | "Suspended" | "Closed";
export type IncidentReportClass = "Containment Breach" | "Security Incident" | "External Hostile Activity" | "Exposure / Quarantine" | "Research / Testing Incident" | "Facility / Systems Failure" | "Information Security / Disclosure" | "Other Operational Incident";
export type IncidentSeverity = "Advisory" | "Significant" | "Major" | "Critical";
export type IncidentStatus = "Draft" | "Active" | "Resolved" | "Closed";
export type PersonnelClass = "A" | "B" | "C" | "D" | "E";
export type PersonnelEntryCategory = "Administrative" | "Clearance Amendment" | "Access Amendment" | "Assignment" | "Disciplinary" | "Medical / Quarantine" | "Training & Certification" | "Performance Evaluation" | "Security Review" | "Psychological Evaluation" | "Incident Involvement" | "Transfer / Reassignment" | "Promotion / Demotion" | "Leave / Restricted Duty" | "Separation / Termination" | "External Liaison Note";
export type SCPEntryCategory = "Administrative" | "Containment Log" | "Incident Report" | "Research Log" | "Interview" | "Reclassification" | "Acquisition / Recovery Report" | "Initial Containment Report" | "Testing Log" | "Observation Log" | "Analysis Report" | "Procedure Revision" | "Risk Assessment" | "Transfer / Custody Record" | "Recovered Document" | "External Correspondence" | "Termination / Neutralization Record";
export type EntryOwnerType = "scp" | "personnel";
export type EntryBlockKind = "Paragraph" | "Quotation" | "Transcript" | "Recovered Script";

export interface DocumentBlock { id: string; kind: EntryBlockKind; text: string; speaker?: string; typefaceId?: string; }
export interface TypefaceRecord { id: string; displayName: string; fileName: string; fileUri: string; fontFamily: string; format: "ttf" | "otf"; size?: number; createdAt: string; }

export interface SCPRecord {
  id: string;
  itemNumber: string;
  designation: string;
  containmentClass: ContainmentClass;
  custody: Custody;
  operationalRole: OperationalRole;
  responsePosture: ResponsePosture;
  containmentConfiguration: ContainmentConfiguration;
  lifecycleStatus: LifecycleStatus;
  terminalEscalation: TerminalEscalation;
  terminalScenario?: string;
  terminalRationale?: string;
  disruptionClass: DisruptionClass;
  riskClass: RiskClass;
  customContainmentClass?: string;
  customCustody?: string;
  customOperationalRole?: string;
  customResponsePosture?: string;
  customContainmentConfiguration?: string;
  customLifecycleStatus?: string;
  customTerminalEscalation?: string;
  customDisruptionClass?: string;
  customRiskClass?: string;
  classificationNote?: string;
  site: string;
  minimumClearanceLevel: ClearanceLevel;
  containmentProcedures: string;
  description: string;
  researchLeadId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PersonnelRecord {
  id: string; personnelId: string; designation: string; name: string; personnelClass: PersonnelClass; department: string; position: string; departmentalClearance: string; facilityAssignment: string; accessCategories: string[]; specialPermissions: string[]; restrictions: string[]; role: string; division: string; site: string; clearanceLevel: ClearanceLevel; accessStatus: AccessStatus; authorizedZones: string[]; createdAt: string; updatedAt: string;
}
export interface EntryFolder { id: string; ownerType: EntryOwnerType; ownerId: string; name: string; createdAt: string; updatedAt: string; }
export interface PersonnelEntry { id: string; personnelId: string; folderId?: string; title: string; category: PersonnelEntryCategory; document: string; documentBlocks?: DocumentBlock[]; createdAt: string; updatedAt: string; }
export interface SCPEntry { id: string; scpId: string; folderId?: string; title: string; category: SCPEntryCategory; document: string; documentBlocks?: DocumentBlock[]; createdAt: string; updatedAt: string; }
export interface ResearchTeam { id: string; name: string; code: string; objective: string; status: TeamStatus; leadPersonnelId?: string; memberIds: string[]; linkedScpId?: string; reviewDate: string; createdAt: string; updatedAt: string; }
export interface ProjectRecord { id: string; code: string; title: string; status: ProjectStatus; minimumClearanceLevel: ClearanceLevel; mandate: string; brief: string; reviewDate: string; scpIds: string[]; personnelIds: string[]; teamIds: string[]; createdAt: string; updatedAt: string; }
export interface IncidentEntryReference { ownerType: EntryOwnerType; entryId: string; }
export interface IncidentReport { id: string; reportNumber: string; title: string; reportClass: IncidentReportClass; severity: IncidentSeverity; status: IncidentStatus; minimumClearanceLevel: ClearanceLevel; site: string; occurredAt: string; reportedByPersonnelId?: string; discoveryMethod: string; initialNotification: string; situationSummary: string; externalInvolvement?: string; immediateMeasures: string; impactAssessment: string; responseOwnerTeamId?: string; projectId?: string; resolutionSummary?: string; closureRationale?: string; scpIds: string[]; personnelIds: string[]; teamIds: string[]; entryReferences: IncidentEntryReference[]; createdAt: string; updatedAt: string; }
export interface RegistryData { scps: SCPRecord[]; personnel: PersonnelRecord[]; entryFolders: EntryFolder[]; personnelEntries: PersonnelEntry[]; scpEntries: SCPEntry[]; typefaces: TypefaceRecord[]; teams: ResearchTeam[]; projects: ProjectRecord[]; incidents: IncidentReport[]; scpNamedClassificationOptions: ScpNamedClassificationOptions; }
export type RecordType = "scp" | "personnel" | "team";

export const CLEARANCE_LEVELS: ClearanceLevel[] = ["Level 1", "Level 2", "Level 3", "Level 4", "Level 5"];
export const CONTAINMENT_CLASSES: ContainmentClass[] = ["Safe", "Euclid", "Keter", "Ticonderoga", "Archon", "Cernunnos", NOT_LISTED_SPECIFY];
export const CUSTODY_OPTIONS: Custody[] = ["Foundation Custody", "External Custody — Argus", "Joint Custody", "Unassigned / Disputed", NOT_LISTED_SPECIFY];
export const OPERATIONAL_ROLE_OPTIONS: OperationalRole[] = ["No Formal Role", "Thaumiel", NOT_LISTED_SPECIFY];
export const RESPONSE_POSTURE_OPTIONS: ResponsePosture[] = ["Standard Covert Response", "Tiamat", NOT_LISTED_SPECIFY];
export const CONTAINMENT_CONFIGURATION_OPTIONS: ContainmentConfiguration[] = ["Standard Configuration", "Hiemal", NOT_LISTED_SPECIFY];
export const LIFECYCLE_STATUS_OPTIONS: LifecycleStatus[] = ["Active / Managed", "Pending", "Uncontained / Active Incident", "Neutralized", "Explained", "Decommissioned", NOT_LISTED_SPECIFY];
export const TERMINAL_ESCALATION_OPTIONS: TerminalEscalation[] = ["None / Not Triggered", "Apollyon Condition", "K-Class Scenario", "Apollyon Condition + K-Class Scenario", NOT_LISTED_SPECIFY];
export const DISRUPTION_CLASSES: DisruptionClass[] = ["Dark", "Vlam", "Keneq", "Ekhi", "Amida", NOT_LISTED_SPECIFY];
export const RISK_CLASSES: RiskClass[] = ["Notice", "Caution", "Warning", "Danger", "Critical", NOT_LISTED_SPECIFY];
export const ACCESS_STATUSES: AccessStatus[] = ["Active", "Restricted", "Suspended"];
export const TEAM_STATUSES: TeamStatus[] = ["Active", "Observation", "Standby"];
export const PROJECT_STATUSES: ProjectStatus[] = ["Planning", "Active", "Review Hold", "Suspended", "Closed"];
export const INCIDENT_REPORT_CLASSES: IncidentReportClass[] = ["Containment Breach", "Security Incident", "External Hostile Activity", "Exposure / Quarantine", "Research / Testing Incident", "Facility / Systems Failure", "Information Security / Disclosure", "Other Operational Incident"];
export const INCIDENT_SEVERITIES: IncidentSeverity[] = ["Advisory", "Significant", "Major", "Critical"];
export const INCIDENT_STATUSES: IncidentStatus[] = ["Draft", "Active", "Resolved", "Closed"];
export const PERSONNEL_CLASSES: PersonnelClass[] = ["A", "B", "C", "D", "E"];
export const PERSONNEL_ENTRY_CATEGORIES: PersonnelEntryCategory[] = ["Administrative", "Clearance Amendment", "Access Amendment", "Assignment", "Disciplinary", "Medical / Quarantine", "Training & Certification", "Performance Evaluation", "Security Review", "Psychological Evaluation", "Incident Involvement", "Transfer / Reassignment", "Promotion / Demotion", "Leave / Restricted Duty", "Separation / Termination", "External Liaison Note"];
export const SCP_ENTRY_CATEGORIES: SCPEntryCategory[] = ["Administrative", "Containment Log", "Incident Report", "Research Log", "Interview", "Reclassification", "Acquisition / Recovery Report", "Initial Containment Report", "Testing Log", "Observation Log", "Analysis Report", "Procedure Revision", "Risk Assessment", "Transfer / Custody Record", "Recovered Document", "External Correspondence", "Termination / Neutralization Record"];
export const ENTRY_BLOCK_KINDS: EntryBlockKind[] = ["Paragraph", "Quotation", "Transcript", "Recovered Script"];
