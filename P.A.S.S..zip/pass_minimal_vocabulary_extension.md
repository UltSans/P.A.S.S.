# PASS Minimal Vocabulary Extension

**Purpose:** Improve recognition of Foundation work without adding fields, screens, external-organization systems, automatic links, or pre-filled records.

## What stays exactly as it is

SCP profiles, Personnel dossiers, Teams, Entries, Projects, Incident Reports, clearance rules, and local blank defaults stay unchanged. A SCP’s origin remains in an **SCP Entry document**, exactly as the user requested. The improvement is only a stronger vocabulary for the fields and categories that already exist.

Personnel `Department` and `Position` are currently free text. The safe improvement is to add selectable **suggestion chips** above each existing text field. Selecting one fills the same field; the field remains editable, so custom roles always remain possible. This does not alter saved data or force any canon choice.

## Personnel: Department suggestions

The Foundation’s published department material shows a broad operational institution, including administration, records/information security, medical and psychological work, containment, field response, engineering, logistics, specialized research, and support functions.[1] [2]

| Suggested Department option | Covers |
|---|---|
| Administration & Oversight | Site administration, directors, executive support |
| Research Division | Laboratory and analytical research |
| Containment Operations | Containment procedure and chamber operations |
| Security & Tactical Response | Site security, guard force, emergency response |
| Medical & Psychological Services | Medical, psychiatric, pathology, quarantine work |
| Field Operations & Investigation | Agents, recovery, investigation, forensics |
| Records & Information Security | RAISA-style records, redaction, archives, information security |
| Engineering & Technical Services | Containment engineering, paratechnology, systems maintenance |
| Logistics, Procurement & Facilities | Transport, supply, storage, facilities, janitorial support |
| Ethics & Compliance | Ethics review, internal oversight, disciplinary review |
| Occult & Specialized Studies | Thaumaturgy, memetics, anomalous linguistics, folklore, biology |
| External Relations & Liaison | Controlled coordination with outside bodies |
| Custom Department | Existing free-text behavior remains available |

## Personnel: Position suggestions

The following are suggestions for the existing `Position` field. They do **not** imply a clearance level or Personnel Class. For example, a Class C member may be a researcher, medic, security officer, technician, or janitor; Class A–E remains the separate exposure/status system.[2]

| Work area | Suggested Position options |
|---|---|
| Administration | Site Director; Deputy Site Director; Department Head; Administrative Officer; Executive Assistant; Compliance Officer; Ethics Committee Liaison |
| Research | Research Assistant; Junior Researcher; Researcher; Senior Researcher; Lead Researcher; Research Analyst; Laboratory Technician |
| Containment | Containment Specialist; Containment Engineer; Containment Technician; Containment Operations Officer; Anomalous Entity Liaison |
| Security & response | Security Officer; Security Supervisor; Tactical Response Officer; Response Commander; Armory Custodian; Security Systems Analyst |
| Medical & psychological | Chief Medical Officer; Physician; Nurse; Paramedic; Anomalous Psychiatrist; Psychologist; Anomalous Pathologist; Quarantine Officer; Biohazard Specialist |
| Field & investigation | Field Agent; Investigative Agent; Recovery Specialist; Tactical Forensics Lead; Surveillance Officer; Evidence Custodian |
| Records & communications | Records Officer; Archivist; Redaction Specialist; Document Analyst; Information Security Analyst; Communications Monitor |
| Technical & logistical | Systems Engineer; Paratechnology Specialist; Facilities Technician; Logistics Coordinator; Procurement Officer; Transport Officer; Janitorial Services Officer |
| Specialist disciplines | Thaumaturgist; Occult Studies Specialist; Memetics Specialist; Antimemetics Specialist; Cryptozoologist; Linguist / Translator; Forensic Specialist; Anomalous Materials Researcher |
| Custom Position | Existing free-text behavior remains available |

The terms are grounded in the official staff-title and department references, while the user remains free to create local variants such as “Anomalous Material Researcher” or “High-Security Containment Officer.”[1] [2]

## SCP Entries: expand the existing category choices

The existing SCP Entry categories remain. The following new choices add useful document types without adding metadata or changing the document editor.

| Existing category | Add these options | Use |
|---|---|---|
| Administrative, Containment Log, Incident Report, Research Log, Interview, Reclassification | **Acquisition / Recovery Report** | Where the anomaly came from, who recovered it, or how it entered custody. This is where a Dr. Wondertainment-created SCP can record its origin. |
|  | **Initial Containment Report** | First containment and early stabilization record. |
|  | **Testing Log** | A controlled test, trial, or experiment. |
|  | **Observation Log** | Routine behavioral or environmental observation. |
|  | **Analysis Report** | Material, anomalous, forensic, medical, or technical analysis. |
|  | **Procedure Revision** | A change to containment procedures without changing classification. |
|  | **Risk Assessment** | Operational review of hazards, exposure, or failure modes. |
|  | **Transfer / Custody Record** | Movement, handover, or custody documentation. |
|  | **Recovered Document** | A document found with, produced by, or concerning the anomaly. |
|  | **External Correspondence** | A controlled letter, message, report, or contact from outside the Foundation. |
|  | **Termination / Neutralization Record** | A final state record when applicable. |

## Personnel Entries: expand the existing category choices

The existing Personnel categories remain. These additions cover routine Foundation employment history without creating separate profile fields.

| Existing category | Add these options | Use |
|---|---|---|
| Administrative, Clearance Amendment, Access Amendment, Assignment, Disciplinary, Medical / Quarantine | **Training & Certification** | Training completion, qualification, renewal, or failure. |
|  | **Performance Evaluation** | Routine appraisal, commendation, or corrective evaluation. |
|  | **Security Review** | Security suitability, access review, or compromise concern. |
|  | **Psychological Evaluation** | Mental-health or fitness-for-duty document distinct from quarantine. |
|  | **Incident Involvement** | A person’s factual involvement or follow-up in an incident. |
|  | **Transfer / Reassignment** | New site, department, Team, or position. |
|  | **Promotion / Demotion** | Change in role or professional standing. |
|  | **Leave / Restricted Duty** | Temporary work status without changing clearance. |
|  | **Separation / Termination** | End of service, retirement, removal, or status closure. |
|  | **External Liaison Note** | Documented contact with an outside group or agency. |

## Documents in general: no new system is needed

The structured document block editor, folders, typefaces, TXT/PDF export, and SCP/Personnel ownership are already appropriate. No provenance fields, external-organization selectors, or document-confidence system should be added. A writer can explain origin, source, uncertainty, claim, or outside involvement in the document itself, using the more precise category above.

## Incident Reports: no category change recommended now

The current Incident Report classes already cover containment, security, external hostile activity, exposure/quarantine, research/testing, facility/system failure, information disclosure, and an `Other Operational Incident` fallback. Adding more classes now would make the system less clear, not more realistic. Use the existing report narrative and links; add a related SCP or Personnel Entry for the detailed documentation.

## Implementation boundary

The entire change is limited to:

1. Static suggestion chips above the existing Personnel Department and Position text fields.
2. Additional union values and choice labels for existing SCP Entry and Personnel Entry categories.
3. A safe migration that leaves all saved records untouched and keeps custom free-text values valid.

## Approval requested

Please approve this exact minimal scope, or identify any suggested Department, Position, SCP Entry category, or Personnel Entry category you want removed or added before implementation.

## References

[1]: https://scp-wiki.wikidot.com/departments "SCP Wiki — Foundation Departments"
[2]: https://scp-wiki.wikidot.com/security-clearance-levels "SCP Wiki — Security Clearance Levels"
[3]: https://scp-wiki.wikidot.com/personnel-and-character-dossier "SCP Wiki — Personnel and Character Dossier"
