import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, PropsWithChildren, useContext, useEffect, useMemo, useState } from "react";

import { recordId } from "@/lib/registry-utils";
import { defaultFacilityAssignment } from "@/lib/personnel-profile-utils";
import { normalizeProjectLinks } from "@/lib/project-utils";
import { createEmptyRegistry } from "@/lib/registry-defaults";
import { createEmptyScpNamedClassificationOptions, mergeScpNamedClassificationOptions, namedOptionsFromScp } from "@/lib/scp-named-options";
import { NOT_LISTED_SPECIFY, type ContainmentClass, type DocumentBlock, type EntryFolder, type IncidentReport, type PersonnelEntry, type PersonnelRecord, type ProjectRecord, type RegistryData, type ResearchTeam, type SCPEntry, type SCPRecord, type TypefaceRecord } from "@/lib/registry-types";

const STORAGE_KEY = "pass.registry.v1";
const now = "2026-08-19T08:00:00.000Z";

const seedRegistry = createEmptyRegistry();

type SCPInput = Omit<SCPRecord, "id" | "createdAt" | "updatedAt">;
type PersonnelInput = Omit<PersonnelRecord, "id" | "createdAt" | "updatedAt">;
type PersonnelEntryInput = Omit<PersonnelEntry, "id" | "createdAt" | "updatedAt">;
type SCPEntryInput = Omit<SCPEntry, "id" | "createdAt" | "updatedAt">;
type EntryFolderInput = Omit<EntryFolder, "id" | "createdAt" | "updatedAt">;
type TeamInput = Omit<ResearchTeam, "id" | "createdAt" | "updatedAt">;
type ProjectInput = Omit<ProjectRecord, "id" | "createdAt" | "updatedAt">;
type IncidentInput = Omit<IncidentReport, "id" | "createdAt" | "updatedAt">;

interface RegistryContextValue extends RegistryData {
  hydrated: boolean;
  upsertScp: (input: SCPInput, id?: string) => string;
  upsertPersonnel: (input: PersonnelInput, id?: string) => string;
  upsertEntryFolder: (input: EntryFolderInput, id?: string) => string;
  upsertPersonnelEntry: (input: PersonnelEntryInput, id?: string) => string;
  upsertScpEntry: (input: SCPEntryInput, id?: string) => string;
  upsertTypeface: (typeface: TypefaceRecord) => void;
  removeTypeface: (id: string) => void;
  upsertTeam: (input: TeamInput, id?: string) => string;
  upsertProject: (input: ProjectInput, id?: string) => string;
  upsertIncident: (input: IncidentInput, id?: string) => string;
  archiveRecord: (type: "scp" | "personnel" | "team" | "project", id: string) => void;
}

const RegistryContext = createContext<RegistryContextValue | null>(null);

export function normalizePersonnel(record: PersonnelRecord): PersonnelRecord {
  return { ...record, designation: record.designation ?? "Personnel", personnelClass: record.personnelClass ?? "C", department: record.department ?? record.division ?? "Unassigned Department", position: record.position ?? record.role ?? "Unassigned Position", departmentalClearance: record.departmentalClearance ?? `${record.division ?? "Foundation"} Clearance ${record.clearanceLevel.replace("Level ", "")}`, facilityAssignment: defaultFacilityAssignment(record), accessCategories: record.accessCategories ?? record.authorizedZones ?? [], specialPermissions: record.specialPermissions ?? [], restrictions: record.restrictions ?? [] };
}
type LegacyScpRecord = Partial<SCPRecord> & { objectClass?: string; secondaryClass?: string; containmentStatus?: string };
function legacyContainment(objectClass?: string, secondaryClass?: string): ContainmentClass {
  const candidate = secondaryClass === "Ticonderoga" || secondaryClass === "Archon" || secondaryClass === "Cernunnos" ? secondaryClass : objectClass;
  return candidate === "Safe" || candidate === "Euclid" || candidate === "Keter" || candidate === "Ticonderoga" || candidate === "Archon" || candidate === "Cernunnos" ? candidate : "Euclid";
}
function normalizeScp(record: LegacyScpRecord): SCPRecord {
  const secondary = record.secondaryClass;
  const legacyNote = secondary === "Custom / Esoteric" || record.objectClass === "Esoteric" ? "Legacy esoteric designation — review required" : undefined;
  return {
    ...record,
    containmentClass: legacyFallback(record.containmentClass) ?? legacyContainment(record.objectClass, secondary),
    custody: legacyFallback(record.custody) ?? (secondary === "Argus" ? "External Custody — Argus" : "Foundation Custody"),
    operationalRole: legacyFallback(record.operationalRole) ?? (secondary === "Thaumiel" ? "Thaumiel" : "No Formal Role"),
    responsePosture: legacyFallback(record.responsePosture) ?? (secondary === "Tiamat" ? "Tiamat" : "Standard Covert Response"),
    containmentConfiguration: legacyFallback(record.containmentConfiguration) ?? (secondary === "Hiemal" ? "Hiemal" : "Standard Configuration"),
    lifecycleStatus: legacyFallback(record.lifecycleStatus) ?? (secondary === "Uncontained" || record.containmentStatus === "Breached" ? "Uncontained / Active Incident" : record.objectClass === "Neutralized" ? "Neutralized" : record.objectClass === "Explained" ? "Explained" : record.objectClass === "Pending" || record.containmentStatus === "Under Review" ? "Pending" : "Active / Managed"),
    terminalEscalation: legacyFallback(record.terminalEscalation) ?? (secondary === "Apollyon" ? "Apollyon Condition" : "None / Not Triggered"),
    disruptionClass: legacyFallback(record.disruptionClass) ?? "Dark",
    riskClass: legacyFallback(record.riskClass) ?? "Notice",
    classificationNote: record.classificationNote ?? legacyNote,
    site: record.site ?? "Unassigned Site",
    minimumClearanceLevel: record.minimumClearanceLevel ?? "Level 1",
    containmentProcedures: record.containmentProcedures ?? "No procedures entered.",
    description: record.description ?? "No description entered.",
    createdAt: record.createdAt ?? now,
    updatedAt: record.updatedAt ?? now,
  } as SCPRecord;
}
function legacyFallback(value: unknown) { return value === "Custom" ? NOT_LISTED_SPECIFY : value; }
function normalizeBlocks(document: string, blocks?: DocumentBlock[]): DocumentBlock[] {
  if (blocks?.length) return blocks.filter((block) => Boolean(block.text?.trim())).map((block, index) => ({ ...block, id: block.id || `legacy-block-${index}` }));
  return document.trim() ? [{ id: "legacy-block-1", kind: "Paragraph", text: document }] : [];
}
function normalizePersonnelEntry(entry: PersonnelEntry): PersonnelEntry { const blocks = normalizeBlocks(entry.document ?? "", entry.documentBlocks); return { ...entry, document: entry.document ?? blocks.map((block) => block.text).join("\n\n"), documentBlocks: blocks }; }
function normalizeScpEntry(entry: SCPEntry): SCPEntry { const blocks = normalizeBlocks(entry.document ?? "", entry.documentBlocks); return { ...entry, document: entry.document ?? blocks.map((block) => block.text).join("\n\n"), documentBlocks: blocks }; }
function normalizeIncident(report: IncidentReport): IncidentReport { return { ...report, reportClass: report.reportClass ?? "Other Operational Incident", severity: report.severity ?? "Significant", status: report.status ?? "Draft", minimumClearanceLevel: report.minimumClearanceLevel ?? "Level 1", site: report.site ?? "Unassigned Site", occurredAt: report.occurredAt ?? now, discoveryMethod: report.discoveryMethod ?? "Unspecified", initialNotification: report.initialNotification ?? "No initial notification entered.", situationSummary: report.situationSummary ?? "No situation summary entered.", immediateMeasures: report.immediateMeasures ?? "No measures recorded.", impactAssessment: report.impactAssessment ?? "Impact not yet assessed.", scpIds: [...new Set(report.scpIds ?? [])], personnelIds: [...new Set(report.personnelIds ?? [])], teamIds: [...new Set(report.teamIds ?? [])], entryReferences: (report.entryReferences ?? []).filter((reference) => Boolean(reference?.entryId)), createdAt: report.createdAt ?? now, updatedAt: report.updatedAt ?? now }; }

export function RegistryProvider({ children }: PropsWithChildren) {
  const [registry, setRegistry] = useState<RegistryData>(seedRegistry);
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => { AsyncStorage.getItem(STORAGE_KEY).then((value) => { if (!value) return; const saved = JSON.parse(value) as RegistryData; const scps = (saved.scps ?? []).map(normalizeScp); const savedNamedOptions = saved.scpNamedClassificationOptions ?? createEmptyScpNamedClassificationOptions(); setRegistry({ ...saved, scps, personnel: saved.personnel.map(normalizePersonnel), entryFolders: saved.entryFolders ?? [], personnelEntries: (saved.personnelEntries ?? []).map(normalizePersonnelEntry), scpEntries: (saved.scpEntries ?? []).map(normalizeScpEntry), typefaces: saved.typefaces ?? [], teams: saved.teams ?? [], projects: (saved.projects ?? []).map((project) => ({ ...project, ...normalizeProjectLinks(project) })), incidents: (saved.incidents ?? []).map(normalizeIncident), scpNamedClassificationOptions: mergeScpNamedClassificationOptions(savedNamedOptions, ...scps.map(namedOptionsFromScp)) }); }).catch(() => undefined).finally(() => setHydrated(true)); }, []);
  const commit = (next: RegistryData) => { setRegistry(next); void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next)); };
  const value = useMemo<RegistryContextValue>(() => ({
    ...registry, hydrated,
    upsertScp: (input, id) => { const timestamp = new Date().toISOString(); const existing = id ? registry.scps.find((record) => record.id === id) : undefined; const record: SCPRecord = { ...input, id: id ?? recordId("scp"), createdAt: existing?.createdAt ?? timestamp, updatedAt: timestamp }; commit({ ...registry, scps: existing ? registry.scps.map((item) => item.id === id ? record : item) : [record, ...registry.scps], scpNamedClassificationOptions: mergeScpNamedClassificationOptions(registry.scpNamedClassificationOptions, namedOptionsFromScp(record)) }); return record.id; },
    upsertPersonnel: (input, id) => { const timestamp = new Date().toISOString(); const existing = id ? registry.personnel.find((record) => record.id === id) : undefined; const record: PersonnelRecord = { ...input, id: id ?? recordId("per"), createdAt: existing?.createdAt ?? timestamp, updatedAt: timestamp }; commit({ ...registry, personnel: existing ? registry.personnel.map((item) => item.id === id ? record : item) : [record, ...registry.personnel] }); return record.id; },
    upsertEntryFolder: (input, id) => { const timestamp = new Date().toISOString(); const existing = id ? registry.entryFolders.find((folder) => folder.id === id) : undefined; const folder: EntryFolder = { ...input, id: id ?? recordId("folder"), createdAt: existing?.createdAt ?? timestamp, updatedAt: timestamp }; commit({ ...registry, entryFolders: existing ? registry.entryFolders.map((item) => item.id === id ? folder : item) : [folder, ...registry.entryFolders] }); return folder.id; },
    upsertPersonnelEntry: (input, id) => { const timestamp = new Date().toISOString(); const existing = id ? registry.personnelEntries.find((entry) => entry.id === id) : undefined; const entry: PersonnelEntry = { ...input, id: id ?? recordId("per-entry"), createdAt: existing?.createdAt ?? timestamp, updatedAt: timestamp }; commit({ ...registry, personnelEntries: existing ? registry.personnelEntries.map((item) => item.id === id ? entry : item) : [entry, ...registry.personnelEntries] }); return entry.id; },
    upsertScpEntry: (input, id) => { const timestamp = new Date().toISOString(); const existing = id ? registry.scpEntries.find((entry) => entry.id === id) : undefined; const entry: SCPEntry = { ...input, id: id ?? recordId("scp-entry"), createdAt: existing?.createdAt ?? timestamp, updatedAt: timestamp }; commit({ ...registry, scpEntries: existing ? registry.scpEntries.map((item) => item.id === id ? entry : item) : [entry, ...registry.scpEntries] }); return entry.id; },
    upsertTypeface: (typeface) => { commit({ ...registry, typefaces: registry.typefaces.some((item) => item.id === typeface.id) ? registry.typefaces.map((item) => item.id === typeface.id ? typeface : item) : [typeface, ...registry.typefaces] }); },
    removeTypeface: (id) => { commit({ ...registry, typefaces: registry.typefaces.filter((typeface) => typeface.id !== id) }); },
    upsertTeam: (input, id) => { const timestamp = new Date().toISOString(); const existing = id ? registry.teams.find((record) => record.id === id) : undefined; const record: ResearchTeam = { ...input, id: id ?? recordId("team"), createdAt: existing?.createdAt ?? timestamp, updatedAt: timestamp }; commit({ ...registry, teams: existing ? registry.teams.map((item) => item.id === id ? record : item) : [record, ...registry.teams] }); return record.id; },
    upsertProject: (input, id) => { const timestamp = new Date().toISOString(); const existing = id ? registry.projects.find((record) => record.id === id) : undefined; const record: ProjectRecord = { ...input, ...normalizeProjectLinks(input), id: id ?? recordId("project"), createdAt: existing?.createdAt ?? timestamp, updatedAt: timestamp }; commit({ ...registry, projects: existing ? registry.projects.map((item) => item.id === id ? record : item) : [record, ...registry.projects] }); return record.id; },
    upsertIncident: (input, id) => { const timestamp = new Date().toISOString(); const existing = id ? registry.incidents.find((record) => record.id === id) : undefined; const record: IncidentReport = { ...input, id: id ?? recordId("incident"), createdAt: existing?.createdAt ?? timestamp, updatedAt: timestamp }; commit({ ...registry, incidents: existing ? registry.incidents.map((item) => item.id === id ? record : item) : [record, ...registry.incidents] }); return record.id; },
    archiveRecord: (type, id) => { if (type === "scp") commit({ ...registry, scps: registry.scps.filter((item) => item.id !== id) }); if (type === "personnel") commit({ ...registry, personnel: registry.personnel.filter((item) => item.id !== id) }); if (type === "team") commit({ ...registry, teams: registry.teams.filter((item) => item.id !== id) }); if (type === "project") commit({ ...registry, projects: registry.projects.filter((item) => item.id !== id) }); },
  }), [registry, hydrated]);
  return <RegistryContext.Provider value={value}>{children}</RegistryContext.Provider>;
}
export function useRegistry() { const context = useContext(RegistryContext); if (!context) throw new Error("useRegistry must be used inside RegistryProvider"); return context; }
