# PASS / Site-19 — SCP Dossier Location Notation

## Purpose

Facility Records cannot list every contained asset. This notation lets each SCP dossier state a meaningful Site-19 assignment without turning the map into thousands of chamber cards.

The notation is **administrative location data**, not a tactical map. It identifies the level and the operating division that owns the record. It does not publish chamber geometry, patrol details, emergency procedures, vulnerabilities, or an exact route through restricted space.

## The five required questions

Every Site-19 SCP dossier should answer these questions:

| Field | Question | Example |
|---|---|---|
| **Assigned Site** | Which Foundation site normally owns the asset? | `Site-19` |
| **Operating Level** | In which operating environment does normal custody occur? | `L3 — Light Containment & Research` |
| **Division / Cluster** | Which facility function owns the asset? | `Light Containment Cluster` or `Research & Engineering` |
| **Local Assignment** | What named cell, vault group, custody file, or confidential local reference applies? | `Cell 109-B` or `Vault Group M-2` |
| **Access Condition** | What special condition applies beyond ordinary sector authority? | `Escorted; scheduled operation only` |

The full human-readable form is:

> **Site-19 / L3 — Light Containment & Research / Research & Engineering / Research Cell 109-B / Escorted, Site Command-approved operation**

## Controlled division and cluster labels

The first implementation should use a small controlled vocabulary. A dossier may carry a confidential local assignment, but must not invent a vague level name such as “somewhere in L3.”

| Operating level | Approved division / cluster labels | Typical use |
|---|---|---|
| **L1** | Surface Evidence Holding; Controlled Arrival Custody; External Transfer Hold | Only short, screened, or transfer-related custody; not routine anomaly housing. |
| **L2** | Applied Research Annex; Clinical Services Controlled Treatment; Records Evidence Review | Exceptional placements whose ordinary work is truly administrative, clinical, or controlled applied research. |
| **L3** | Light Containment Cluster; Research & Engineering; Interview and Observation; D-Class Test Support; Material Intake Quarantine | Routine active Safe/appropriate Euclid custody, non-biological research, controlled testing support, and day-to-day work. |
| **L4** | Heavy Containment Cluster; Specialist Research Isolation; Decontamination/Recovery Custody; Deep Isolation | High-consequence custody or research where L3 traffic is unsuitable. |
| **L5** | Long-Hold Anomalous Storage; Medical-Anomalous Custody; Evidence and Physical Archive; Protected Infrastructure Custody | Rare retrieval, package/stable storage, scarce custodial assets, evidence, and protected site systems. |
| **External / Joint** | External Custody; Joint Custody; Field Assignment; Pending Transfer | Assets Site-19 does not physically house as normal custody. |

## Local-assignment rules

| Local assignment type | When to use it | Example |
|---|---|---|
| **Named cell** | An active containment/research asset has a meaningful controlled cell. | `Research Cell 109-B` |
| **Cluster and confidential local reference** | The asset is in a generic containment cluster, but exact location should not appear in broad Facility Records. | `LCZ Cluster C / Local Ref: 17` |
| **Vault group** | The asset is packaged, scarce, inert, or retrieved only through custody control. | `Medical-Anomalous Vault / Group M-2` |
| **Project suite** | The location exists only because a current approved Project owns the work. | `Project Nereid Suite / Access by linked Project authority` |
| **No fixed cell** | A field, external, mobile, uncontained, or disputed-custody asset is not safely expressed as a room. | `No fixed Site-19 location — Joint Custody` |

## Access-condition values

Access Condition must state the *operational rule*, not merely repeat a Level number. It uses the existing PASS distinction between standing access categories, special permissions, and restrictions.

| Condition | Meaning |
|---|---|
| **Standing sector authority** | Approved personnel may conduct routine work in the division/cluster. |
| **Escorted entry** | A qualified escort or custody team is required for the local assignment. |
| **Scheduled operation only** | Entry/use needs an authorized testing, treatment, retrieval, or maintenance window. |
| **Project authority required** | The asset is reachable only through an active approved Project or tasking. |
| **Custodial release required** | A physical asset can leave its vault/cluster only through documented custody transfer. |
| **Clinical authorization required** | Treatment/administration requires a patient-specific clinical approval. |
| **Emergency authority only** | The route or asset is not available during ordinary work. |
| **No unescorted access** | A direct restriction that overrides ordinary sector authority. |

## Examples

| SCP / asset pattern | Dossier location notation | Why it works |
|---|---|---|
| **SCP-914** | `Site-19 / L3 / Research & Engineering / Research Cell 109-B / Escorted; scheduled Site Command-approved operation` | It expresses guarded active research and avoids exposing a route map. |
| **SCP-500** | `Site-19 / L5 / Medical-Anomalous Custody / Vault Group M-2 / Custodial release and clinical authorization required` | It separates rare-stock custody from L2 clinical treatment. |
| **Generic Safe item** | `Site-19 / L3 / Light Containment Cluster / Cluster C — Local Ref 17 / Standing sector authority` | The Facility Records map needs only the cluster; the dossier retains the specific assignment. |
| **High-consequence non-anchor asset** | `Site-19 / L4 / Heavy Containment Cluster / Cluster H — Local Ref 04 / No unescorted access` | It records the operating environment without pretending every HCZ record requires a named guide entry. |
| **External asset** | `External / Joint Custody / Pending Transfer / No fixed Site-19 location / Project authority required` | It avoids inventing a Site-19 cell for something the site does not house. |

## What must not be stored in the broad location field

The user-facing docket should not carry exact underground coordinates, gate sequences, security posture, response procedures, containment vulnerabilities, weapons details, or continuously changing personnel assignments. Those belong in restricted procedure documents where appropriate—not a searchable profile location field.

## Proposed implementation boundary

This is a **design proposal only**. The eventual app change would add structured location fields to SCP dossiers and migrate the current single `site` value safely. It should happen only after the user approves the labels, location notation, and access-condition vocabulary.
