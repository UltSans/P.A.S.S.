import type { ClearanceLevel } from "./registry-types";
import { canAccessClearance } from "./registry-utils";

export type PassAction =
  | "create-scp" | "amend-scp" | "create-personnel" | "amend-personnel"
  | "create-team" | "amend-team" | "create-project" | "amend-project" | "create-incident" | "amend-incident"
  | "create-entry" | "create-folder" | "export-entry" | "import-typeface" | "remove-typeface";

export const PASS_ACTION_REQUIREMENTS: Record<PassAction, ClearanceLevel> = {
  "create-scp": "Level 3", "amend-scp": "Level 3", "create-personnel": "Level 4", "amend-personnel": "Level 4",
  "create-team": "Level 3", "amend-team": "Level 3", "create-project": "Level 3", "amend-project": "Level 3",
  "create-incident": "Level 3", "amend-incident": "Level 3",
  "create-entry": "Level 2", "create-folder": "Level 2", "export-entry": "Level 3", "import-typeface": "Level 2", "remove-typeface": "Level 4",
};

export const PASS_ACTION_LABELS: Record<PassAction, string> = {
  "create-scp": "create SCP files", "amend-scp": "amend SCP files", "create-personnel": "register personnel", "amend-personnel": "amend personnel profiles",
  "create-team": "create research teams", "amend-team": "amend research teams", "create-project": "create Projects", "amend-project": "amend Projects",
  "create-incident": "file Incident Reports", "amend-incident": "amend Incident Reports",
  "create-entry": "create record Entries", "create-folder": "create Entry folders", "export-entry": "export Entries", "import-typeface": "import local typefaces", "remove-typeface": "remove local typefaces",
};

export function canPerformAction(readerLevel: ClearanceLevel, action: PassAction) {
  return canAccessClearance(readerLevel, PASS_ACTION_REQUIREMENTS[action]);
}

/** Requires both the action authority and the ability to read the target record. */
export function canPerformRecordAction(readerLevel: ClearanceLevel, action: PassAction, recordClearance: ClearanceLevel) {
  return canPerformAction(readerLevel, action) && canAccessClearance(readerLevel, recordClearance);
}

export function canAssignClearance(readerLevel: ClearanceLevel, targetLevel: ClearanceLevel) {
  return canAccessClearance(readerLevel, targetLevel);
}

export function availableClearanceLevels(readerLevel: ClearanceLevel): ClearanceLevel[] {
  const levels: ClearanceLevel[] = ["Level 1", "Level 2", "Level 3", "Level 4", "Level 5"];
  return levels.filter((level) => canAssignClearance(readerLevel, level));
}

export function actionRequirement(action: PassAction) {
  return PASS_ACTION_REQUIREMENTS[action];
}
