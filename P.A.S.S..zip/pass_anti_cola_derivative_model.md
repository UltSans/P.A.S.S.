# PASS / Proposed Local Derivative Record — Anti-Cola

## What can be accepted now

Anti-Cola can be treated as a **Site-19 local derivative hypothesis**, inspired by the Secret Laboratory item and by the proven precedent that SCP-914 cross-testing can produce standalone assets such as SCP-427. It must not be recorded as SCP-207-JP, and it must not be presented as a universally canonical SCP object.

## Proposed local identity

| Field | Proposed record | Why |
|---|---|---|
| **Provisional operational label** | Anti-Cola | Preserves the familiar user-facing name. |
| **Local derivative register** | `S19-DER-914-207-A` | Distinguishes a Site-19 derivative from an independently numbered SCP record. The identifier can change later if the user creates a different PASS convention. |
| **Parent inputs** | One documented source unit of SCP-207 and one SCP-914 run. | Prevents the derivative from becoming an unexplained convenience item. |
| **Machine setting** | `1:1` only if this is the user-selected local continuity. | The Secret Laboratory identity connects Anti-Cola to a 914/207 cross-test, but PASS must record its own actual chosen setting rather than claim a universal canon fact. |
| **Status** | Provisional clinical-research derivative. | It is not released as a normal security consumable merely because a game item has effects. |

## Required provenance record

Before the derivative can be issued, PASS should require a closed experiment record containing:

1. Parent container and source-bottle/lot identifier for SCP-207.
2. SCP-914 work order, active researcher, supervising authority, date, machine setting, and input/output mass record.
3. Output batch count, sample integrity, and immediate hazard-screen result.
4. Initial clinical observation and a defined adverse-effect review period.
5. PASS classification decision and custody location.

This is the difference between a real Foundation-derived asset and an unexplained game pickup.

## Proposed use model

The user’s instinct is useful, but the operational use should be narrower than “guards drink it before fighting.” A grounded first model is **controlled emergency stabilization or withdrawal support** after a clinical risk review. It may be considered when preserving an injured or exposed authorized person is operationally necessary and normal treatment is insufficient or unavailable.

It must not be self-issued, used as a routine combat enhancement, or kept in ordinary guard lockers. The exact effect remains unapproved until the user chooses a PASS-local clinical result and its consequences are documented.

## Placement if approved

| Function | Proposed location | Reason |
|---|---|---|
| **Initial study and emergency release** | L2 Clinical Services / Medical-Anomalous Therapeutics Cell | The derivative’s main unanswered question is biological effect and adverse consequence; medical supervision belongs here. |
| **Long-term reserve custody** | L5 Medical-Anomalous Custody | Retains scarcity and denies casual use. |
| **SCP-914 generation** | L2 Applied Engineering Cell | The cross-test occurs only in the existing controlled machine cell, then leaves through a sealed output route. |

## Release authority

| Situation | Minimum release decision |
|---|---|
| Research sample | Lead researcher + Clinical Services representative + Level 4 work order. |
| Emergency clinical use | On-duty senior clinician + Site Command emergency authority, with retrospective review. |
| Field deployment | Not approved until a separate field-effect and accountability protocol exists. |

## Not yet decided

The user must decide whether PASS-local Anti-Cola actually has a healing/regenerative effect, a protective/resilience effect, a speed cost, another drawback, or fails unpredictably. PASS should not borrow a game-stat sheet as if it were clinical evidence. Once the effect is chosen, we can decide whether the derivative remains an L2 clinical asset, moves to L5-only custody, or is rejected.

## References

[1] [SCP-427](https://scp-wiki.wikidot.com/scp-427)  
[2] [Experiment Log 914](https://scp-wiki.wikidot.com/experiment-log-914)  
[3] [SCP-207](https://scp-wiki.wikidot.com/scp-207)  
[4] [Anti-Cola — SCP: Secret Laboratory Official Wiki](https://en.scpslgame.com/index.php?title=Anti-Cola)
