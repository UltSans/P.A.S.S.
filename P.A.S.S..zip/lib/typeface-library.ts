import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Font from "expo-font";

import { recordId } from "@/lib/registry-utils";
import { isManagedTypefaceUri, type TypefaceFileRemovalStatus } from "@/lib/typeface-cleanup";
import type { TypefaceRecord } from "@/lib/registry-types";

const MAX_TYPEFACE_BYTES = 8 * 1024 * 1024;
const TYPEFACE_DIRECTORY = "pass-typefaces";
const TYPEFACE_REMOVAL_QUEUE_KEY = "pass.typeface-removal-queue.v1";

function extensionFor(fileName: string) { return fileName.split(".").pop()?.toLowerCase(); }
function safeName(value: string) { return value.replace(/[^a-z0-9_-]+/gi, "-").replace(/^-+|-+$/g, "") || "typeface"; }

export async function importTypeface(): Promise<TypefaceRecord | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: ["font/ttf", "font/otf", "application/font-sfnt", "application/octet-stream"], copyToCacheDirectory: true, multiple: false });
  if (result.canceled) return null;
  const asset = result.assets[0]; const format = extensionFor(asset.name);
  if (format !== "ttf" && format !== "otf") throw new Error("PASS accepts only .ttf and .otf typeface files.");
  if (asset.size && asset.size > MAX_TYPEFACE_BYTES) throw new Error("Typeface is larger than the 8 MB local library limit.");
  const id = recordId("typeface"); const fontFamily = `PASS-${id}`; const displayName = asset.name.replace(/\.(ttf|otf)$/i, "").replace(/[_-]+/g, " ");
  let fileUri = asset.uri;
  if (Platform.OS !== "web") {
    if (!FileSystem.documentDirectory) throw new Error("Local document storage is unavailable.");
    const directory = `${FileSystem.documentDirectory}${TYPEFACE_DIRECTORY}/`; await FileSystem.makeDirectoryAsync(directory, { intermediates: true });
    fileUri = `${directory}${safeName(id)}.${format}`; await FileSystem.copyAsync({ from: asset.uri, to: fileUri });
  }
  try { await Font.loadAsync(fontFamily, fileUri); } catch { throw new Error("PASS could not register this file as a usable typeface."); }
  return { id, displayName, fileName: asset.name, fileUri, fontFamily, format, size: asset.size, createdAt: new Date().toISOString() };
}

async function pendingRemovalUris() {
  try {
    const saved = await AsyncStorage.getItem(TYPEFACE_REMOVAL_QUEUE_KEY);
    const parsed = saved ? JSON.parse(saved) : [];
    return Array.isArray(parsed) ? parsed.filter((uri): uri is string => typeof uri === "string") : [];
  } catch { return []; }
}
async function savePendingRemovalUris(uris: string[]) {
  if (!uris.length) { await AsyncStorage.removeItem(TYPEFACE_REMOVAL_QUEUE_KEY); return; }
  await AsyncStorage.setItem(TYPEFACE_REMOVAL_QUEUE_KEY, JSON.stringify([...new Set(uris)]));
}
async function queueTypefaceRemoval(fileUri: string) {
  try { await savePendingRemovalUris([...(await pendingRemovalUris()), fileUri]); } catch { return; }
}
export async function flushPendingTypefaceRemovals() {
  if (Platform.OS === "web") return;
  const unresolved: string[] = [];
  for (const fileUri of await pendingRemovalUris()) {
    try { await FileSystem.deleteAsync(fileUri, { idempotent: true }); } catch { unresolved.push(fileUri); }
  }
  try { await savePendingRemovalUris(unresolved); } catch { return; }
}
export async function loadTypefaces(typefaces: TypefaceRecord[]) { await flushPendingTypefaceRemovals(); await Promise.all(typefaces.map(async (typeface) => { if (Font.isLoaded(typeface.fontFamily)) return; try { await Font.loadAsync(typeface.fontFamily, typeface.fileUri); } catch { return; } })); }
export async function typefaceBase64(typeface: TypefaceRecord) { if (Platform.OS === "web") return null; try { return await FileSystem.readAsStringAsync(typeface.fileUri, { encoding: FileSystem.EncodingType.Base64 }); } catch { return null; } }
export async function deleteTypefaceFile(typeface: TypefaceRecord): Promise<TypefaceFileRemovalStatus> {
  if (Platform.OS === "web") return "removed";
  if (!isManagedTypefaceUri(typeface.fileUri, FileSystem.documentDirectory, TYPEFACE_DIRECTORY)) return "not-managed";
  try { await FileSystem.deleteAsync(typeface.fileUri, { idempotent: true }); return "removed"; }
  catch { await queueTypefaceRemoval(typeface.fileUri); return "queued"; }
}
