export type TypefaceFileRemovalStatus = "removed" | "queued" | "not-managed";

export function isManagedTypefaceUri(fileUri: string, documentDirectory: string | null, directoryName: string) {
  return Boolean(documentDirectory && fileUri.startsWith(`${documentDirectory}${directoryName}/`));
}

export function typefaceRemovalMessage(status: TypefaceFileRemovalStatus) {
  if (status === "removed") return "The local file and registry entry were removed. Referenced document text remains preserved.";
  if (status === "queued") return "The registry entry was removed. Local file cleanup is queued for the next PASS launch because the typeface is still active in this session.";
  return "The registry entry was removed. PASS did not own the original source file, so its external copy was left untouched.";
}
