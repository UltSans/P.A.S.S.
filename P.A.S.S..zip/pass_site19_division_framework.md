# PASS / Site-19 Division & Zone Framework

## What the map is identifying

The Facility Records map stops at the **division** and **zone** level. It does not list rooms, individual SCP contents, or staff by name. This keeps the map useful as Site-19 changes while still showing how the physical site actually functions.

| Map unit | Meaning | When it exists |
|---|---|---|
| **Level** | One major vertical operating environment: Surface, Administration & Clinical, Light Containment, Heavy Containment, or Heavy Storage. | Fixed by the approved five-level site model. |
| **Division** | A major, accountable operating area with a distinct function, population, access boundary, and internal support requirement. | It handles a whole category of work—not a single room, item, or vehicle. |
| **Zone** | A large sub-area inside a division, normally defined by a route, a function, or a different access condition. | It contains multiple rooms/local spaces but does not need its own independent administration. |
| **Local point** | A room, lift, gate, bay, clinic room, control post, store, or other navigational feature. | It is recorded only in the local division record when needed; it is not a new REF-05 map division. |

## Designation format

> **Division:** `S19-L[level]-[two-digit division]`  
> **Zone:** `S19-L[level]-[two-digit division]-[letter]`

Examples use format only; they are not final placement decisions.

| Example | Meaning |
|---|---|
| `S19-L1-01` | The first major division on Level 1. |
| `S19-L1-01-A` | Zone A within that Level 1 division. |
| `S19-L3-04-C` | Zone C within the fourth major division on Level 3. |

The designation is deliberately neutral. It tells the reader where a record belongs without inventing a dramatic name. The functional title beside it explains what the division does.

## Numbering rules

1. Division numbers are sequential **within each level**, beginning at `01`.
2. Zone letters are sequential **within their division**, beginning at `A`.
3. A division number is not reused after retirement; its record remains historically traceable.
4. New divisions receive the next available number rather than renumbering existing records.
5. Local points do not receive a REF-05 designation unless they grow into a true division or zone.

## The division test

An activity becomes a division only if it passes all four tests:

| Test | Required question |
|---|---|
| **Function** | Does it perform a distinct continuous site function? |
| **Population** | Does it have its own assigned personnel, controlled visitors, or accountable shift responsibility? |
| **Boundary** | Does it need a defined access condition, checkpoint, or separation from neighbouring work? |
| **Scale** | Does it contain multiple local spaces/zones and require its own support route or local control point? |

If the answer is no, it is a local point or room—not a division. A helicopter operation, for example, could qualify as a division only because it can involve landing, secure transfer, crew control, service, emergency handoff, and a defined perimeter; one landing pad alone would not qualify.

## Minimum map record for every division

Every REF-05 division should eventually state the following, in a compact record:

| Field | What it tells the reader |
|---|---|
| **Designation** | Its neutral Site-19 location code. |
| **Functional title** | The work it exists to perform. |
| **Purpose** | The operational reason it is part of the site. |
| **Primary population** | Who normally works there or enters under assignment. |
| **Zones** | The large internal sub-areas recorded at map level. |
| **Boundary** | The relevant door, gate, checkpoint, or route condition. |
| **Interfaces** | The divisions/cores it normally connects to. |

This framework lets the finished map be detailed enough to understand Site-19 as a place, but controlled enough that it never becomes a random room catalogue or an SCP list.
