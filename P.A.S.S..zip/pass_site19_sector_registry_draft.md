# PASS / Site-19 Facility Sector Registry — Draft

## Purpose and scope

This is a **user-defined PASS local configuration**, not a claim to be the one universal SCP Site-19 floor plan. It takes broad spatial inspiration from containment-game environments while avoiding copied layouts, assets, room-by-room replication, or claims of canon.

The registry replaces a literal mega-map with a controlled operational model:

> **Level → Sector → Function → Access boundary → Approved connectors.**

This is the right level of detail for an internal database. It tells a user where a function belongs and how it connects without pretending to draw every corridor in an exceptionally large site.

## Site model at a glance

| Level | Primary mission | Access character | Principal exception |
|---|---|---|---|
| **L1 / Surface & Entry** | Cover, arrival, delivery, vehicle control, screening. | Controlled but non-containment. | No uncontrolled movement toward lower levels. |
| **L2 / Administration & Services** | Command, records, medical, support operations, staff workspaces. | Credentialed work area. | Medical and security functions require their own protected sectors. |
| **L3 / Light Containment & Research** | Routine low-to-moderate containment, laboratories, interviews, staff services. | Controlled containment zone. | Cafeteria sits in a protected service sector, not among containment suites. |
| **L4 / Heavy Containment & Isolation** | High-risk containment, tactical response, hard isolation. | Escorted/restricted. | SCP-682 is in an isolated deep sector with its own connector. |
| **L5 / Deep Storage & Contingency** | Inert storage, vaults, long-term archive caches, critical infrastructure. | Minimal traffic; purpose-limited. | Omega Contingency Vault is listed only as a restricted strategic asset. |

## Level 1 — Surface & Entry

| Sector | Function | What belongs here | What does not belong here |
|---|---|---|---|
| **L1-A / Public Cover** | Maintain the site’s civilian-facing identity. | Cover offices, outward-facing lobby, perimeter appearance. | Open access to the operational site. |
| **L1-B / Personnel Arrival** | Process staff entry and scheduled visitors. | Credential verification, screening, controlled turnstiles, personal-item lockers. | Direct elevators to containment. |
| **L1-C / Vehicle & Loading Control** | Screen freight, service vehicles, and deliveries. | Receiving bay, vehicle inspection, controlled freight handoff. | Unscreened supply movement to L3–L5. |
| **L1-D / Surface Security** | Protect the perimeter and respond to surface incidents. | Guard post, surveillance, surface-response staging. | Routine administration or low-risk containment. |

**Boundary rule:** L1 has no ordinary public-to-containment route. A cleared user passes from L1 into a controlled staff connector; freight is handed into a separate screened logistics route.

## Level 2 — Administration & Services

| Sector | Function | Notes |
|---|---|---|
| **L2-A / Command & Administration** | Site Director, departmental coordination, controlled meetings, budget and personnel administration. | This is where routine site decisions are made, not where containment action is directed during an active breach. |
| **L2-B / Records & Database Services** | Registry access, records review, document systems, reference material. | Logical home for PASS-style records work. |
| **L2-C / Medical Bay** | Routine occupational health, initial response, observation, and controlled transfer to specialist isolation. | A medical bay should not substitute for L3/L4 quarantine or high-risk exposure treatment. |
| **L2-D / Staff Operations** | Offices, briefings, training, maintenance coordination, staff services. | Keeps ordinary work away from containment traffic. |
| **L2-E / Security Administration** | Credential operations, access authorizations, internal security coordination. | Distinct from tactical response staging. |

**Challenge to avoid:** do not make L2 one huge office floor. The medical bay, records systems, and access administration need their own protected subsectors because they have different traffic, privacy, and security requirements.

## Level 3 — Light Containment & Research

| Sector | Function | Operational boundary |
|---|---|---|
| **L3-A / Light Containment Ring** | Lower-risk containment suites and observation rooms. | Must be separated from ordinary staff movement by controlled doors. |
| **L3-B / Research & Interview Wing** | Labs, supervised testing, non-emergency interview rooms, analysis. | Routes should allow researchers to work without crossing unrelated containment corridors. |
| **L3-C / Service Spine** | Cafeteria, rest space, sanitation, staff support. | The cafeteria belongs here, but in a service corridor buffered from containment. It should never open directly into a containment ring. |
| **L3-D / Intake & Quarantine Transfer** | Controlled movement of material/personnel to research or isolation. | Receives only cleared transfers from L1 freight or L2 medical/security. |
| **L3-E / Security Checkpoint** | Principal L3→L4 access boundary. | Requires a distinct approval route; no casual through traffic. |
| **L3-F / D-Class Processing, Housing & Staging** | Controlled D-Class arrival, housing corridors, medical/psychological screening, holding, and escorted dispatch to approved testing. | Located near research logistics, but never connected as open circulation to research or containment sectors. |
| **L3-G / Applied Anomalous Engineering — SCP-914** | Scheduled, supervised work with SCP-914, material holding, observation, and approved research support. | Uses a dedicated containment vestibule and transfer route; it is near research, not open to general research traffic. |

The cafeteria is sensible on L3 because it serves research and containment staff who spend long shifts below ground. The realism condition is simple: it operates in a **segregated service spine** with access control and physical buffering, not beside cells or on a route to heavy containment.

The two new anchors make the level easier to understand without turning it into a copied game map. D-Class handling is treated as an operational custody and logistics sector, not as casual “hallways,” while SCP-914 is treated as a controlled engineering asset rather than an ordinary shared laboratory.

## Level 4 — Heavy Containment & Isolation

| Sector | Function | Operational boundary |
|---|---|---|
| **L4-A / Heavy Containment Core** | High-risk suites and enhanced containment infrastructure. | Enter only through L3-E or controlled internal routes. |
| **L4-B / Tactical Response & Recovery** | Security staging, decontamination, incident support, protective equipment. | Separated from normal staff and containment circulation. |
| **L4-C / Special Research Isolation** | Limited research functions that cannot be safely performed on L3. | No general laboratory traffic. |
| **L4-D / Deep Isolation Sector 682** | Isolated chamber for SCP-682 as a PASS facility asset. | Reached through its own controlled deep-access connector; it is not a conventional room in the L4 core. |

### SCP-682 sector constraint

The map should expose only the sector existence, its clearance ceiling, and its isolated-route status. It should not display a chamber plan, countermeasures, technical vulnerabilities, or response instructions. PASS can later show a redacted sector card at low clearance and a more detailed **administrative** access state at appropriate clearance.

## Level 5 — Deep Storage & Contingency

| Sector | Function | Operational boundary |
|---|---|---|
| **L5-A / Deep Storage Vaults** | Packaged, inert, inactive, or long-hold anomalous assets. | Low traffic; scheduled, logged movement only. |
| **L5-B / Secure Archive Cache** | Redundant physical records and controlled evidence storage. | Not a public library; records access does not equal vault access. |
| **L5-C / Critical Infrastructure** | Site-essential support systems and protected utilities. | Restricted maintenance access only. |
| **L5-D / Omega Contingency Vault** | A restricted strategic contingency asset, including the user-defined nuclear warhead. | Show only that the asset exists, its high-level custody state, and its authority requirement. No location coordinates, procedures, activation logic, or technical details. |

The warhead should never be framed as a Level 5 attraction or a normal response tool. In PASS, it is a **high-level locked contingency record** aligned to terminal-escalation governance, not a usable instruction set.

## Connector registry

The site needs more than a single elevator stack. PASS should name the connector types, not draw their mechanics.

| Connector class | Connects | Intended users | Rule |
|---|---|---|---|
| **P / Personnel Lift** | L1↔L2 and designated L2↔L3 access points. | Cleared staff. | Normal staff travel; does not open into heavy containment. |
| **F / Freight Lift** | L1 loading control↔L3 intake and designated L5 storage routes. | Cleared logistics teams. | Separate from routine staff circulation. |
| **S / Secure Transfer Shaft** | L3 security checkpoint↔L4 heavy containment. | Escorted/authorized staff and secured materials. | Controlled transition; no general movement. |
| **D / Deep Isolation Lift** | Dedicated L3/L4 controlled origin↔L4-D Sector 682. | Explicitly authorized incident/containment personnel. | Not part of the main L4 circulation loop. |
| **E / Emergency Egress Core** | All levels↔surface safe egress. | All personnel during authorised emergencies. | Egress-first, not a normal travel shortcut. |
| **M / Maintenance Route** | Critical infrastructure↔service zones. | Approved maintenance teams. | Avoids protected research and containment routes where possible. |

## Facility address standard

The sector registry needs a location language that can scale beyond a handful of named rooms. PASS should use a fully qualified internal location code in records and a compact label on any future facility schematic.

> **Full record format:** `S19-L{level}-{sector}-{subsection}`  
> **Compact map label:** `{sector}-{subsection}`

| Element | Example | Meaning |
|---|---|---|
| **Site** | `S19` | Site-19 local configuration. |
| **Level** | `L3` | The third underground operational level. |
| **Parent sector** | `08` | A two-digit sector number. Numbers may be intentionally non-sequential to leave room for later sectors. |
| **Controlled subsection** | `H` | A lettered subsection inside the parent sector. It can represent a controlled wing, secured division, or distinct operational pocket. |
| **Full code** | `S19-L3-08-H` | A unique database-readable address. |

The code tells PASS **where a controlled function is registered**, not every door, cell, office, ventilation shaft, or anomaly. Safe and Euclid records remain associated with their general containment domain unless a specific operational reason requires a named sector. Individual rooms can receive a final suffix only when the user actually needs one; for example, `S19-L3-08-H-R14` could later identify Room 14 inside the SCP-914 sector without forcing every map label to become an address list.

### Provisional anchor examples

| Facility function | Provisional code | Why it helps |
|---|---|---|
| **Applied Anomalous Engineering — SCP-914** | `S19-L3-08-H` | Lets research entries, access grants, and transfer logs point to the same controlled engineering sector. |
| **D-Class Processing, Housing & Staging** | `S19-L3-12-C` | Keeps custody, housing, screening, and escorted dispatch distinct from general research traffic. |
| **Deep Isolation Sector 682** | `S19-L4-29-D` | Makes the sector visibly isolated from the main heavy-containment core without revealing tactical detail. |
| **Omega Contingency Vault** | `S19-L5-42-O` | Records the existence of a restricted asset category without publishing procedures or technical information. |

These are **provisional registry references**, not immutable canon. You can rename or renumber them later; the important part is that every PASS record uses the same language once a sector is approved. No location code should be created merely to make a generic anomaly appear more detailed.

## What the first facility screen should show

The first PASS facility screen should be a **text-first Site-19 Sector Registry**, not a complex map. A user chooses a level and sees sector cards with function, access posture, related connectors, and a restricted/redacted state when appropriate.

| Reader clearance | Information shown |
|---|---|
| **Level 1–2** | L1/L2 general functions; L3 only as a restricted zone; L4/L5 shown as unavailable. |
| **Level 3** | L3 sectors and high-level L4 existence; no deep-isolation or contingency detail. |
| **Level 4** | L4 sector names, authorized connectors, and administrative status; no tactical procedure. |
| **Level 5** | L5 custody categories and asset-presence summaries; Omega vault remains purpose-limited even at this level. |

## Decisions required from you

Before this becomes a PASS screen, please confirm or correct these design points:

1. What is the Site-19 **surface cover**: a warehouse, industrial company, research campus, military property, or something else?
2. Should the **cafeteria** serve only L3, or be a central staff service area accessible from L2 and L3 through separate controls?
3. Do you want more named L3/L4 sectors before implementation, or should PASS start with the current functional groups and let you add locations later?
4. Should the document call the Level 5 asset an **Omega Contingency Vault**, or do you prefer a different grounded internal name?
5. Is the Site-19 facility view allowed to show different detail by reader clearance, as the rest of PASS does?

## Reference

The official SCP Wiki characterizes Site-19 as a major high-security containment location with a very large anomaly population, dedicated laboratories, and anomalous-item storage, but does not impose one fixed five-level layout. [1]

[1] [SCP Wiki — Foundation Facilities](https://scp-wiki.wikidot.com/secure-facilities-locations)
