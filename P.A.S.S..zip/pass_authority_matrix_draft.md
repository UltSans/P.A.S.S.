# PASS / Research & Security Authority Matrix

## Scope

This matrix defines **professional authority**, not a universal door ladder. Facility Access still decides whether someone may physically enter a division, zone, gate, or lift. A person needs both the right route/zone assignment and the right Research or Security Authority when the work or protected asset requires it.

## Research Authority — R1 to R5

| Level | Operational meaning | Typical permitted work | Does not grant automatically |
|---|---|---|---|
| **R1 — Research Orientation** | May participate in supervised Foundation research support and handle controlled introductory documentation. | L2 briefing; approved low-sensitivity documentation; supervised observation; non-contact research assistance. | Independent testing, research-cell control, broad LCZ access, or access to restricted outputs. |
| **R2 — Assigned Research Operations** | May perform routine assigned research work in approved L2/L3 research areas. | L3 research/analysis/interview work; approved low-risk observation; designated controlled asset procedures under supervision. | Authority to approve new tests, enter unrelated containment divisions, or use high-risk research systems. |
| **R3 — Research Lead Authority** | May lead approved L3 research work and control designated mid-level research procedures. | Direct a defined study; approve standard work inside assigned research compartments; review restricted findings for an assigned programme; supervise R1/R2 researchers. | General L4 work, terminal material, or an unrelated project/asset. |
| **R4 — Specialist Research Authority** | May direct designated high-risk or multi-division research and enter L4 research/observation work by assignment. | Specialist research; high-consequence procedure review; cross-division project leadership; restricted research-system use. | Universal HCZ access, site-wide information, or any custody release without a separate grant. |
| **R5 — Strategic Research Authority** | May govern the site’s most restricted research decisions, exceptional methodology, and terminal research records. | Site-level research approval; terminal/critical research review; exceptional project oversight; appointment of defined R4 research leads. | A physical route, armory, storage vault, or contingency action without Facility Access and other required authority. |

## Security Authority — S1 to S5

| Level | Operational meaning | Typical permitted work | Does not grant automatically |
|---|---|---|---|
| **S1 — Local Security Duty** | May operate standard assigned security posts and basic protective equipment in lower-risk site areas. | L1 personnel/perimeter posts; L2 operations control; basic duty lockers; ordinary credential screening. | L3 armory access, custody control, response equipment, or broad containment movement. |
| **S2 — Operational Security Authority** | May operate L3 security posts, custody controls, and standard response equipment. | LCZ checkpoints; D-Class escort/custody operations; L3 security rooms; standard armory issue under duty assignment. | Heavy container opening, HCZ response equipment, deep isolation access, or site-wide incident command. |
| **S3 — Restricted Security Authority** | May access designated high-security containers, L3 restricted equipment, and controlled L4 transition functions. | Heavy-container issue; enhanced armory/control rooms; heavy-gate security post; supervised response-equipment handling. | Independent L4 command, deep isolation custody, strategic vaults, or a permanent all-site pass. |
| **S4 — High-Consequence Security Authority** | May direct designated L4 response/security operations and manage high-consequence security resources. | HCZ response support; advanced restricted equipment; L4 post command; high-security transfer/custody supervision. | Omega Contingency action, unrestricted L5 custody, or research authority. |
| **S5 — Strategic Security Authority** | May authorize the site’s most restricted security actions, contingency controls, and deep custody posture under defined policy. | Site-wide high-consequence security oversight; strategic custody review; contingency security authorization; S4 appointment/review. | Bypassing records, research, clinical, or Facility Access controls without the required separate authorization. |

## Scale rules

1. **R1–R5 and S1–S5 are independent.** R4 does not imply S4, and S4 does not imply R4.
2. **Neither scale equals Site-19 level number.** An S3 container can exist in L3; an R2 research space can exist in L2; L4 may include assets needing only the specific authority appropriate to their function.
3. **Facility Access is the route decision.** R/S authority becomes relevant only after a person is permitted to reach the division, zone, or secured interface.
4. **Special permissions remain narrower.** A project, custody release, deep-isolation entry, exceptional test, or medical-anomalous issue may require a named permission even when the person has a high R/S authority.
5. **Restrictions override the matrix.** Suspended credentials, medical hold, incident limitation, escort requirements, or an explicit restriction deny ordinary use.

## Example profiles

| Profile | Research | Security | Facility Access | Meaning |
|---|---:|---:|---|---|
| Junior Researcher | R2 | S0 | L2-06, L3-01, L3-03 | May use the research route and assigned L3 research divisions; cannot open an armory or cross to L4 without assignment. |
| Senior Containment Researcher | R4 | S1 | L2-05, L3-03, L4-01, L4-04 | May conduct approved specialist research in assigned L4 observation areas; local S1 protects ordinary self-defence/post functions only. |
| LCZ Security Supervisor | R1 | S3 | L1-02, L3-01, L3-04, L3-05, L3-06 | Can manage custody/checkpoints and designated heavy containers; cannot open research cells simply through security authority. |
| MTF Response Lead | R1 | S4 | L1-05, L3-01, L4-01, L4-06 | Can lead an authorized response route into L4; research and deep-isolation access still need independent assignment. |
| Site Director | R5 | S5 | Assigned command, incident, and contingency access only | Has strategic approval authority but remains within recorded routes, audit, and separate release procedures. |

## Source boundary

Secret Laboratory’s keycards, armories, containers, checkpoints, and heavy-containment equipment informed the **idea** that access should be multi-category and asset-specific. The R/S names, five levels, roles, routes, divisions, and examples above are original PASS design choices and do not reproduce the game’s map or cards.
