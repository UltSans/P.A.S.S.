import { Tabs, useRouter } from "expo-router";
import { Platform, View } from "react-native";
import { useEffect } from "react";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { palette } from "@/components/registry-ui";
import { useSession } from "@/lib/session-store";

export default function TabLayout() {
  const router = useRouter();
  const { stage } = useSession();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 12);
  useEffect(() => {
    if (stage !== "authorized") router.replace("/" as never);
  }, [router, stage]);
  if (stage !== "authorized") return <View style={{ flex: 1, backgroundColor: palette.canvas }} />;
  return (
    <Tabs screenOptions={{
      headerShown: false,
      tabBarButton: HapticTab,
      tabBarActiveTintColor: palette.blue,
      tabBarInactiveTintColor: "#718080",
      sceneStyle: { backgroundColor: palette.canvas },
      tabBarStyle: { backgroundColor: "#111719", borderTopWidth: 1, borderTopColor: palette.line, height: 62 + bottomPadding, paddingTop: 8, paddingBottom: bottomPadding },
      tabBarLabelStyle: { fontSize: 10, fontWeight: "700" },
    }}>
      <Tabs.Screen name="index" options={{ title: "Terminal", tabBarIcon: ({ color }) => <IconSymbol name="rectangle.grid.2x2.fill" size={23} color={color} /> }} />
      <Tabs.Screen name="anomalies" options={{ title: "Anomalies", tabBarIcon: ({ color }) => <IconSymbol name="doc.text.fill" size={23} color={color} /> }} />
      <Tabs.Screen name="personnel" options={{ title: "Personnel", tabBarIcon: ({ color }) => <IconSymbol name="person.text.rectangle.fill" size={23} color={color} /> }} />
      <Tabs.Screen name="teams" options={{ title: "Teams", tabBarIcon: ({ color }) => <IconSymbol name="person.2.fill" size={23} color={color} /> }} />
    </Tabs>
  );
}
