# PASS / Site-19 — Reasoned Placement Examples

## What this answers

This document answers the four questions used to test whether the Site-19 model is becoming a real operating facility:

1. **Where could SCP-914 go, and why?**
2. **Why would SCP-500 be placed near medicine—or why would it not?**
3. **What do doors, checkpoints, and gates actually mean in PASS?**
4. **What is the Site-19 medical department, exactly?**

The answer is not “put familiar SCPs in familiar levels.” Every placement must satisfy the asset’s actual procedure, daily workflow, people required, materials route, and failure consequences.

> **Rule:** An SCP is located where its normal operation can be controlled—not where its object class, fame, or a game map makes it look familiar.

## 1. Doors, checkpoints, and gates

The SCP setting has no single mandatory Foundation-wide door taxonomy. The official wiki material establishes need-to-know, variable local clearances, and lockdown compartmentalization; the games use recognizable names such as doors, checkpoints, and gates. [1] [2] [3] [4] PASS can use the terms, but must define them locally instead of reproducing a game layout.

| PASS boundary | What it is for | What it is **not** for | Example at Site-19 |
|---|---|---|---|
| **Light Door** | Separates compatible internal workspaces that still require a routine assignment or privacy. | A level boundary or containment barrier. | Clinical consultation rooms; L2 records workrooms; an L3 laboratory office. |
| **Heavy Door** | Protects one controlled division, asset cell, or specialist work area inside an existing operating level. | A label that automatically means “Level 4.” | SCP-914 research-cell entrance; D-Class custody block; L4 specialist laboratory. |
| **Checkpoint** | Regulates repeated movement from one supervised work environment into another. It verifies a person’s credential, current assignment, and route availability. | A normal door that merely closes quickly. | L2 Administration → L3 LCZ; L3 Duty Control → dedicated research/containment corridors. |
| **Gate** | Marks a major environmental or infrastructure transition: a large compartment change, a level-transfer route, or protected surface egress. | A decoration or a fast route around normal control points. | L3 → L4 heavy-transfer gate; controlled surface egress; freight gate into deep logistics. |
| **Isolation Gate Pair** | Creates nested protection around a uniquely consequential asset or sector. | A substitute for a full containment procedure. | L4 Deep Isolation sector; rare L5 strategic custody function. |

In ordinary operation, a door or gate is evaluated through the existing PASS personnel model: active credential status, explicit restrictions, standing sector access category, local special permission if required, and the person’s present work purpose. A reader’s clearance at app launch is **database visibility**, not an employee’s physical card. The Foundation’s clearance material supports keeping global, division, and local scopes separate. [1] [2]

During a lockdown, a checkpoint or gate can become unavailable or restricted because the operating condition changes. The lockdown reference supports that high-level principle, but PASS should never expose tactical procedures or pretend that a game’s scripted unlock task is a real site rule. [3]

## 2. SCP-914 — The location follows the operating cell

The primary procedure gives much more than “Safe.” SCP-914 is held in **research cell 109-B**, continuously guarded by two personnel; every researcher entering is accompanied by at least one guard; operators need formal request and Site Command approval; and biological testing is prohibited. The multi-ton machine occupies about eighteen square metres and has separate Intake and Output booths. [5] Its experiment log additionally holds researchers responsible for outputs and reports damage or death for review. [6]

That immediately rules out several careless placements:

| Proposed location | Could it work? | Reasoned answer |
|---|---|---|
| **Ordinary L2 offices** | **No.** | The guard post, formal authorization, material staging, separate Intake/Output handling, and supervised test cell are incompatible with routine administration. “Near offices” is not a reason to put it in office circulation. |
| **L2 Applied Research Annex** | **Only as an exceptional design.** | It would need to be a physically separate L2 annex with its own Heavy Door, guard post, materials handoff, test schedule, and output-quarantine point. It cannot be a training attraction for junior researchers; observation may be scheduled, but operation remains command-approved and guarded. |
| **L3 Research and Engineering Division** | **Yes — strongest default.** | L3 has the daily research staffing, controlled materials intake, laboratories, guard coverage, and containment-aware logistics necessary for a purpose-built research cell. Its normal workflow fits a non-biological materials programme without forcing staff or freight through L2 administration. |
| **L4 HCZ** | **Only if Site-19 proves a high-consequence programme.** | The primary procedure does not itself make SCP-914 an HCZ asset. L4 would be justified only if the site’s specific output programme, not the machine’s fame, routinely produced high-risk outputs requiring HCZ isolation. Otherwise L4 adds an unjustified heavy-transfer burden. |
| **L5 Heavy Storage** | **No, under normal use.** | L5 is for rare retrieval and long-hold custody. SCP-914 needs an active research workflow, staffed operation, and material staging. |

### Recommended working placement

The defensible default is therefore **L3 — Research and Engineering Division, Research Cell 109-B**. This is not “put it in LCZ because Secret Laboratory does.” The game’s LCZ chamber is only a comparison point; the canonical procedure and work pattern independently support a contained research-sector location. [7]

The cell would need all of the following, at a deliberately high level:

| Element | Reason |
|---|---|
| **Research Cell 109-B** behind a Heavy Door | The machine is an asset with a distinct controlled space, not a laboratory instrument. |
| **Guard post and escorted test entry** | Directly follows the procedure: two guards on duty and an accompanying guard for researchers. |
| **Formal operation authorization** | A PASS special permission / linked Entry records the approved test window and responsible researcher. |
| **Controlled materials staging route** | Inputs arrive from L3 Material Intake through a scheduled route, not from general staff corridors or the cafeteria. |
| **Separate output assessment area** | Outputs are received and evaluated before release into research circulation. This does not automatically make them HCZ material. |
| **No biological-test route** | The normal cell design excludes D-Class and clinical/biological testing; an extraordinary exception cannot become a routine map feature. |

The correct answer to “could SCP-914 be L2?” is therefore: **yes, but it would need to become a real isolated research annex, and L3 is the stronger default unless Site-19 has a specific reason to make the annex work.** It should not be placed in L2 merely because junior researchers are nearby.

## 3. SCP-500 — The location follows custody and release, not medical usefulness

SCP-500 is a small, finite stock of red pills that cure disease when taken orally. The primary procedure requires cool, dry, dark storage and limits access to Level 4 personnel to prevent misapplication. Its own record documents denied personal requests, approved case-specific uses, theft, and failed synthesis attempts. [8]

This makes SCP-500’s main risk **social and custodial**: pressure to misuse an irreplaceable treatment, theft, unauthorized allocation, and unrecorded consumption. It is medically important, but it is not ordinary pharmacy stock.

| Location | Could it work? | Reasoned answer |
|---|---|---|
| **General L2 pharmacy cabinet** | **No.** | A normal clinical pharmacy needs quick, routine access for ordinary medicine. That is the opposite of scarce Level-4 custodial control. |
| **L2 Clinical Services controlled vault** | **Possible, but only with a strong policy.** | Clinical specialists are close to diagnosis, ethical review, secure treatment, and patient monitoring. A small vault could work if it has separate dual custody and case-specific release. It must not be opened as general clinical inventory. |
| **L5 Medical-Anomalous Custody Vault** | **Strongest default.** | L5’s mission is rare, logged, purpose-limited custody. It naturally supports environmental storage, strict inventory, narrow release authority, and protection from routine clinical traffic. |
| **L3 or L4 medical point** | **No as standing stock.** | These levels need clinical response and transfer capability, but are not good routine custody locations for scarce medicine. Their staff should request a controlled release, not keep the primary stock. |
| **A person’s personal medkit** | **No.** | The original document explicitly gives a denied personal-medkit request. [8] |

### Recommended working placement

The default should be **L5 — Medical-Anomalous Custody Vault**, administered jointly by a Level-4 custodian and the Clinical Services Division. L2 Clinical Services owns the patient assessment, diagnosis, ethical review, treatment room, and post-dose care; it does **not** keep the primary bottle in a routine pharmacy.

A Level-2 clinical location becomes involved only through a controlled chain:

1. A clinician identifies a serious candidate case.
2. The request is reviewed under the site’s defined authority.
3. A counted dose is released from the L5 vault through a documented custody handoff.
4. Treatment occurs in the L2 **Secure Custody Treatment Room** under the approved case record.
5. Inventory and outcome are reconciled in a linked Entry.

The site may later choose a sealed emergency dose near L2 Clinical Isolation, but that is a policy decision with a real trade-off: faster response versus a larger theft/misapplication surface. It should not be quietly assumed into the map.

## 4. What the L2 medical department actually is

If it can address physical, psychological, psychiatric, diagnostic, and staff-health needs, it is not a “medical bay.” It is the **Clinical Services Division**. Health-facility planning treats emergency, diagnostic, pharmacy, mental-health, inpatient/observation, procedure, decontamination, and support functions as interrelated but distinct units. [9]

The L2 division should be a controlled internal department, not a public hospital and not a single corridor. Its model is:

| Clinical Services unit | What it does | Boundary and routing logic |
|---|---|---|
| **Clinical Intake and Acute Care** | Triage, urgent treatment, resuscitation capability, and short observation for Site-19 personnel. | Reached from the secure L2 staff route; ordinary patients do not enter through public L1 cover offices. |
| **Diagnostics and Treatment** | Laboratory diagnostics, imaging/assessment capacity, procedures, rehabilitation, and occupational-health evaluation. | Fed by normal clinical supplies and linked to the other L2 units. |
| **Behavioural Health and Psychological Evaluation** | Counselling, psychiatric assessment, fitness-for-duty review, and post-incident support. | Privacy-separated from acute care and controlled by a Light Door. |
| **Clinical Pharmacy and Controlled Medicines** | Holds ordinary site medicines and manages routine dispensing. | Separate from anomalous medical custody. It connects administratively—but not as an open store—to SCP-500 release. |
| **Clinical Isolation Annex** | Evaluates patients whose condition may contaminate or endanger ordinary clinical circulation. | Located at the controlled edge of the department with a dedicated L3/L4 transfer route. |
| **Secure Custody Treatment Room** | Administers a scarce authorized anomalous treatment, such as a released SCP-500 dose. | The patient receives treatment here; the asset is not normally stored here. |

The isolation distinction is not decorative. Healthcare guidance separates an inner patient isolation zone from a safer outer staff zone to reduce contaminant migration. [10] PASS does not need to reproduce real medical engineering detail, but it should respect the operational lesson: **an unknown or hazardous exposure is stabilized and transferred through a controlled route, not walked through the general clinic.**

Therefore:

| Site location | Clinical role |
|---|---|
| **L2** | Owns the comprehensive Clinical Services Division: normal acute care, diagnostics, behavioural health, pharmacy, controlled treatment, and clinical isolation. |
| **L3** | Has an LCZ Clinical Response Post for first aid, initial assessment, and controlled transfer—not a second full hospital. |
| **L4** | Has decontamination and HCZ clinical isolation for stabilization before any transfer—not an ordinary outpatient clinic. |
| **L5** | Holds medical-anomalous custody such as the primary SCP-500 stock; it is not a patient-treatment department. |

## 5. What these examples prove about mapping Site-19

These two SCPs lead to opposite conclusions:

| Asset | Correct primary question | Strongest default result |
|---|---|---|
| **SCP-914** | Where can an active, guarded, command-approved, non-biological materials-testing operation safely run every day? | **L3 Research and Engineering**, in a dedicated cell. |
| **SCP-500** | Where can a scarce, socially sensitive, Level-4-controlled treatment be protected until a specific patient is approved? | **L5 Medical-Anomalous Custody**, with L2 clinical authority and treatment. |

This is the method we should use for every future SCP:

1. Read its procedures and actual constraints.
2. Identify its ordinary workflow, not just its containment class.
3. Identify its people, materials, patient/custody, and access routes.
4. Place it where those flows are defensible.
5. Add only the door, checkpoint, or gate boundary that the operating condition actually requires.

We should now discuss these conclusions—not implement them yet—and use any correction from this review to build the rest of Level 2, Level 3, Level 4, and Level 5 with the same standard.

## References

[1] [SCP Wiki — Security Clearance Levels](https://scp-wiki.wikidot.com/security-clearance-levels)  
[2] [SCP Wiki — Expanded Security Clearance Codes](https://scp-wiki.wikidot.com/expanded-security-clearance-codes)  
[3] [SCP Wiki — Lockdown Procedures](https://scp-wiki.wikidot.com/lockdown-procedures)  
[4] [SCP: Secret Laboratory Official Wiki — Door Mechanics](https://en.scpslgame.com/index.php?title=Door_Mechanics)  
[5] [SCP Wiki — SCP-914](https://scp-wiki.wikidot.com/scp-914)  
[6] [SCP Wiki — Experiment Log 914](https://scp-wiki.wikidot.com/experiment-log-914)  
[7] [SCP: Secret Laboratory Official Wiki — SCP-914](https://en.scpslgame.com/index.php/SCP-914)  
[8] [SCP Wiki — SCP-500](https://scp-wiki.wikidot.com/scp-500)  
[9] [International Health Facility Guidelines — Functional Planning Units](https://www.healthfacilityguidelines.com/FPUs)  
[10] [CDC/NIOSH — Expedient Patient Isolation Rooms](https://www.cdc.gov/niosh/healthcare/hcp/pandemic/patient-isolation-rooms.html)
