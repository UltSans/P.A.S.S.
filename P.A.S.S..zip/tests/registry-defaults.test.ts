import { describe, expect, it } from "vitest";

import { createEmptyRegistry } from "../lib/registry-defaults";

describe("fresh PASS registry", () => {
  it("contains no bundled profiles, teams, documents, projects, typefaces, or reports", () => {
    const registry = createEmptyRegistry();
    expect(registry).toEqual({ scps: [], personnel: [], entryFolders: [], personnelEntries: [], scpEntries: [], typefaces: [], teams: [], projects: [], incidents: [], scpNamedClassificationOptions: { containmentClass: [], custody: [], operationalRole: [], responsePosture: [], containmentConfiguration: [], lifecycleStatus: [], terminalEscalation: [], disruptionClass: [], riskClass: [] } });
  });

  it("returns a new registry shape for every fresh installation", () => {
    const first = createEmptyRegistry();
    const second = createEmptyRegistry();
    first.scps.push({ id: "temporary" } as any);
    expect(second.scps).toEqual([]);
  });
});
