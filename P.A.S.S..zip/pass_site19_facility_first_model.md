# PASS / Site-19 — Facility-First Operating Model

## Scope

This is a proposed operating model for **Site-19 as a real, coherent facility**. It does not begin with SCPs. It begins with the work the institution must perform every day: receive people and materials, administer staff, provide care, contain and study anomalies, support shifts, isolate high-consequence work, preserve sensitive assets, and survive an emergency.

Individual SCPs are deliberately absent from this model. A record is placed later only when its procedure proves that it must change a level, division, route, or boundary. The normal case is a dossier assignment into one of these operating divisions.

> **The test for every division is simple:** What does it do? Who works there? What comes in and out? What needs to be separated from it? If we cannot answer those questions, it does not belong in the map.

---

## Site-wide structure

| Level | Operating purpose | Daily population | Main boundary decision |
|---|---|---|---|
| **L1 — Surface** | Protect the interface between the outside world and Site-19. | Perimeter security, arrivals, vehicle control, receiving, cover-operation staff. | Has the person or material been screened before it reaches the internal facility? |
| **L2 — Administration** | Operate Site-19 as an institution and care for its workforce. | Leadership, administration, personnel/records staff, clinicians, credential staff, scheduled visitors. | Does the person have a legitimate institutional reason to enter a controlled working site? |
| **L3 — LCZ** | Run the high-volume daily work of routine containment and research. | Researchers, containment staff, LCZ security, service staff, D-Class custody personnel, approved maintenance. | Does this person have a current LCZ assignment and the correct controlled division authority? |
| **L4 — HCZ** | Isolate high-consequence custody and specialist work from ordinary LCZ operations. | HCZ specialists, decontamination staff, restricted recovery/support personnel. | Does this person have a named HCZ destination and a reason to cross the heavy boundary? |
| **L5 — Heavy Storage** | Preserve assets, records, and systems that should not participate in daily circulation. | Custodians, deep logistics teams, archive staff, protected-systems technicians. | Is this visit an approved custody, retrieval, maintenance, or governance task? |

---

## Level 1 — Surface Operations

### Mission

L1 exists to ensure that **the real Site-19 never begins at the public-facing door**. It handles the outside world without allowing outside movement to become internal movement. The surface may operate under a civilian cover, but the exact public identity remains a separate decision; the facility works whether the cover is an industrial, scientific, environmental, or logistics operation.

### Divisions

| Division | Work | Inputs and outputs | Boundary requirement |
|---|---|---|---|
| **Surface Cover and External Liaison** | Handles the legitimate public-facing operation, contracted communications, scheduled external contact, and cover-consistent paperwork. | Receives external enquiries; passes only vetted internal matters onward. | A Light Door separates cover work from secure operations. |
| **Personnel Arrival and Credential Screening** | Verifies expected staff, processes approved visitors, conducts arrival screening, and hands over escorted entrants. | Receives people from the surface; releases cleared staff to the L2 access route. | A Checkpoint prevents direct arrival-to-containment movement. |
| **Vehicle, Receiving, and Dispatch Control** | Manages deliveries, service vehicles, loading, receipt records, and initial cargo screening. | Receives freight; hands cleared material into secure logistics. | Heavy separation from staff arrivals and all personnel lifts. |
| **Perimeter and Surface Security** | Operates the perimeter, surface gates, external incident coordination, and restricted exterior access. | Receives security alerts; controls surface boundaries and supports egress. | Separate security access; not part of visitor processing. |
| **Surface Technical Support** | Maintains surface utilities, cover-facing equipment, and approved exterior service tasks. | Receives approved maintenance work orders; connects to protected internal maintenance routes. | Service movement cannot become an undocumented internal entry route. |

### L1 routes

| Route | Direction | Rule |
|---|---|---|
| **Personnel route** | Arrival → L2 Staff Access. | No passenger lift opens directly into L3, L4, or L5. |
| **Freight route** | Receiving → controlled logistics → L3 Material Intake or L5 Deep Logistics. | Freight is never mixed with office, dining, or general clinical movement. |
| **Visitor route** | Arrival → escort-controlled L2 destination only. | Visitors never self-navigate deeper levels. |
| **Egress route** | Internal emergency core → surface assembly/egress. | Emergency-only; not an ordinary shortcut. |

---

## Level 2 — Administration and Clinical Services

### Mission

L2 is the institutional core of Site-19. It provides the command, administration, records, staffing, health, and preparation required for a major site to function every day. Its operating condition is **low anomaly contact**, not zero security. It is intentionally separated from public L1 and operational L3.

### Divisions

| Division | Work | Inputs and outputs | Boundary requirement |
|---|---|---|---|
| **Site Command and Coordination** | Provides Site Director functions, senior coordination, controlled meetings, policy decisions, and incident coordination at an administrative level. | Receives reports and escalations; issues approved direction and staffing priorities. | Controlled office suite; not an HCZ response staging space. |
| **Personnel, Credentials, and Records** | Maintains personnel assignments, access changes, internal records, document routing, and PASS-style administrative systems. | Receives verified identity/assignment data; issues documented credentials and records decisions. | Records access never grants physical sector access. |
| **Security Administration** | Manages standing access categories, restrictions, duty rosters, internal security administration, and review of access changes. | Receives access requests and incidents; issues approvals or restrictions. | Separate from L1 perimeter and L4 recovery operations. |
| **Clinical Services Division** | Provides acute care, diagnostics, treatment, behavioural health, psychological assessment, occupational health, pharmacy, rehabilitation, and short observation. | Receives ordinary staff/patients and controlled transfers; returns personnel to duty, observation, restriction, or onward care. | A controlled internal clinical department, not a public hospital. |
| **Clinical Isolation and Controlled Treatment** | Assesses patients whose condition may not be safe for ordinary clinical circulation and conducts authorized restricted treatment. | Receives protected transfers from L3/L4; hands safe patients into general treatment or controlled onward care. | At the edge of Clinical Services with its own transfer route. |
| **Briefing, Assignment, and Professional Development** | Runs pre-shift briefings, policy refreshers, project orientation, qualification administration, and post-incident debriefing. | Receives scheduled staff; releases them to approved L3 or L4 duty routes. | No weapons drills or recruit security training; those belong at a separate external facility. |
| **Staff Access and Internal Communications** | Controls the handoff from L1, coordinates routine internal communications, and directs approved staff to their legitimate level. | Receives cleared arrivals; releases people only toward the level/division they are assigned. | L2’s central Checkpoint—not a free route to containment. |

### Clinical Services internal model

| Unit | Purpose | Must remain separate from |
|---|---|---|
| Clinical Intake and Acute Care | Staff triage, urgent treatment, short observation, and routing. | Public L1 cover work and hazardous incoming transfers. |
| Diagnostics and Treatment | Assessment, laboratory/imaging capacity, treatment/procedure rooms, rehabilitation, and occupational care. | D-Class custody and ordinary visitor circulation. |
| Behavioural Health and Psychological Evaluation | Confidential counselling, psychiatric assessment, fitness-for-duty review, and post-incident support. | Acute-care waiting and general administration. |
| Clinical Pharmacy and Controlled Medicines | Ordinary medical supply and controlled dispensing. | Anomalous custody stock unless there is a specific documented custody handoff. |
| Clinical Isolation Annex | Controlled assessment and care for uncertain or potentially hazardous patients. | General clinic flow. |
| Secure Custody Treatment Room | Patient-specific administration of a formally released restricted treatment. | The long-term storage location of that treatment. |

### L2 routes

| Route | Direction | Rule |
|---|---|---|
| **Staff route** | L1 Arrival → L2 Staff Access → L2 division or L3 checkpoint. | A person without a containment assignment remains on L2. |
| **Clinical transfer route** | L3/L4 response point → controlled clinical isolation → appropriate L2 care. | An unassessed exposure never passes through ordinary clinic or office circulation. |
| **L3 work route** | L2 briefing/access → L3 LCZ Checkpoint. | Only assigned staff cross; the gate is a change of operating environment. |

---

## Level 3 — Light Containment Zone

### Mission

L3 is the daily operational heart of Site-19. It contains the people and systems that must work around routine anomalies for long shifts: containment staff, researchers, security, service workers, custody personnel, maintenance teams, and approved support staff. It needs both **controlled containment** and **ordinary human support**, but those functions cannot be allowed to blend into one open corridor system.

### Divisions

| Division | Work | Inputs and outputs | Boundary requirement |
|---|---|---|---|
| **LCZ Duty Control** | Receives arriving LCZ staff, confirms assignment, tracks normal sector status, and manages shift handover. | Receives staff through the L2 checkpoint; directs them to named divisions. | It is the working boundary between L2 and L3. |
| **Light Containment Operations** | Runs routine Safe and appropriate Euclid custody, observation, scheduled checks, and controlled maintenance. | Receives authorized staff/materials; returns containment status and maintenance needs. | Heavy Doors separate each containment cluster from normal movement. |
| **Research, Interview, and Analysis** | Runs approved research, non-emergency interviews, analytical work, scheduled tests, and documentation support. | Receives approved research materials and staff; releases findings and controlled outputs. | Its access does not imply access to every containment cluster. |
| **D-Class Custody and Dispatch** | Conducts intake, screening, welfare administration, housing, holding, and escorted dispatch to approved work or tests. | Receives custody transfers; releases only escorted subjects to authorized destinations. | Its own Heavy Door and custody route; no free connection to research or staff support. |
| **Material Intake and Controlled Transfer** | Receives cleared freight, research material, controlled samples, and approved personnel transfers. | Receives L1 freight; routes material to L3 divisions or secured onward transfer. | Separate from staff dining, offices, and public-facing routes. |
| **Shift Services and Welfare** | Provides food service, sanitation, lockers, rest space, uniform/service support, and practical needs for underground shifts. | Receives staff/service supply; supports the L3 workforce. | Buffered from cells, D-Class custody, material intake, and the HCZ gate. |
| **LCZ Clinical Response** | Provides first aid, initial assessment, safe holding, and controlled transfer for L3 incidents. | Receives patients from L3; releases them to L2 Clinical Isolation or controlled L4 care. | It stabilizes; it is not a second full medical department. |
| **LCZ Maintenance and Environmental Support** | Supports approved engineering, cleaning, waste handling, utilities observation, and service continuity. | Receives work orders and supplies; maintains controlled systems without unrestricted cell access. | Uses a service route that does not substitute for staff access. |
| **HCZ Transition** | Verifies named L4 destination authority and controls the heavy transfer to L4. | Receives authorized HCZ personnel/materials; hands them to L4 Transfer Control. | Heavy Gate; no casual L3-to-L4 movement. |

### L3 internal separation

L3 must have at least four independently controlled flows: **ordinary assigned staff**, **D-Class custody**, **materials/freight**, and **clinical transfer**. Service areas support long shifts, but they are not neutral open space: access windows, division boundaries, and separate routes prevent containment work from leaking into daily life.

---

## Level 4 — Heavy Containment Zone

### Mission

L4 is not simply “more dangerous L3.” It operates under a different assumption: traffic is exceptional, destinations are named, and the environment must tolerate higher consequence from failure, exposure, or recovery work. No one enters merely because they have a high clearance level; they enter because they are assigned to a named L4 function.

### Divisions

| Division | Work | Inputs and outputs | Boundary requirement |
|---|---|---|---|
| **HCZ Transfer Control** | Receives approved arrivals from the L3 Heavy Gate, verifies the exact destination, and prevents unscheduled movement. | Receives staff/materials from L3; directs them only to an approved L4 division. | The L4 side of the heavy transfer boundary. |
| **Heavy Containment Operations** | Maintains high-consequence custody sectors, enhanced observation, and restricted operational support. | Receives assigned personnel/materials; returns custody status and support requirements. | Each cluster has restricted internal boundaries. |
| **Specialist Research Isolation** | Supports limited research that cannot safely occur in L3. | Receives named research teams/materials; releases controlled findings and assets. | No general laboratory traffic. |
| **Decontamination and Clinical Isolation** | Stabilizes high-risk exposures, supports decontamination, and controls onward clinical transfer. | Receives HCZ patients; transfers only after conditions permit. | Separate from ordinary L2 and L3 clinical movement. |
| **Recovery and Protective Support** | Holds protective equipment, restricted recovery supplies, and incident-support resources for authorized teams. | Receives authorized teams; supports controlled recovery work. | Not a general security office or ordinary armory. |
| **Deep Isolation Subdivision** | Provides a separately governed operating environment for any future asset whose procedure genuinely requires isolation beyond HCZ clusters. | Receives explicitly authorized personnel via a dedicated controlled connector. | Isolation boundary; no named asset is assigned here until separately researched and approved. |
| **HCZ Technical Support** | Maintains restricted utilities, environmental systems, and specialist equipment supporting HCZ operations. | Receives approved maintenance tasking; uses designated service routes. | Maintenance does not gain general research or containment entry. |

### L4 routes

| Route | Direction | Rule |
|---|---|---|
| **Heavy transfer** | L3 HCZ Transition → L4 Transfer Control → named division. | The only normal staff/material crossing; destination-specific. |
| **Clinical isolation transfer** | L4 incident → Decontamination/Clinical Isolation → authorized L2 route when safe. | Never through general staff or L3 welfare routes. |
| **Deep isolation connector** | Controlled L4 origin → Deep Isolation Subdivision. | Not part of ordinary HCZ circulation. |

---

## Level 5 — Heavy Storage and Protected Systems

### Mission

L5 protects what Site-19 should not routinely touch: rare-use assets, long-hold custody, physical evidence, protected records, deep technical systems, and purpose-limited contingency functions. Its restriction comes from the need for **stable custody and deliberate retrieval**, not from being underground for its own sake.

### Divisions

| Division | Work | Inputs and outputs | Boundary requirement |
|---|---|---|---|
| **Long-Hold Anomalous Storage** | Keeps packaged, inert, inactive, or rarely retrieved assets under scheduled custody. | Receives approved custody transfers; releases assets only under documented retrieval authority. | Heavy custody doors and logged movement. |
| **Medical-Anomalous Custody** | Holds scarce or exceptional medically relevant anomalous assets whose main risk is allocation, theft, or misuse. | Receives custody stock; releases a documented amount to an authorized clinical handoff. | Separate from ordinary L2 pharmacy and routine medical supply. |
| **Evidence and Physical Archive Custody** | Holds recovered material, physical evidence, restricted samples, and redundant physical records. | Receives sealed evidence/records; releases only for approved review or transfer. | Database reading does not equal physical archive access. |
| **Deep Logistics and Retrieval Control** | Plans infrequent movement, large-item handling, custodial retrieval, and scheduled deep delivery routes. | Receives approved requests; coordinates controlled transfer to/from L5. | No routine passenger movement. |
| **Critical Infrastructure** | Maintains protected technical systems, resilience functions, and low-traffic support utilities. | Receives authorized maintenance; supports the site without becoming general circulation. | Maintenance-only restricted paths. |
| **Contingency Custody** | Holds governance-level, purpose-limited assets or systems whose normal use is exceptional. | Receives only formal authority; exposes no technical or procedural detail in Facility Records. | Isolation boundary; no daily site function depends on ordinary access. |

### L5 routes

| Route | Direction | Rule |
|---|---|---|
| **Deep logistics route** | L1 Receiving / L3 Material Intake → L5 Retrieval Control → named custody division. | Every movement is planned, logged, and destination-specific. |
| **Clinical custody handoff** | L5 Medical-Anomalous Custody → controlled handoff → L2 Secure Custody Treatment. | The patient travels to treatment; the primary stock does not become ordinary clinical inventory. |
| **Protected maintenance route** | L2 service coordination → maintenance connector → Critical Infrastructure. | No facility worker uses it as a shortcut around access checkpoints. |

---

## The real Site-19 movement logic

The facility works because no single elevator chain connects every function. There are multiple vertical systems, each for a particular kind of movement:

| System | Connects | Users | Reason |
|---|---|---|---|
| **Personnel lift network** | L1 ↔ L2 and approved L2 ↔ L3 duty points. | Assigned staff. | Supports ordinary work without opening containment or storage routes. |
| **Freight/logistics network** | L1 Receiving ↔ L3 Material Intake ↔ L5 Deep Logistics. | Cleared logistics teams. | Keeps material movement separate from people. |
| **Heavy transfer network** | L3 HCZ Transition ↔ L4 Transfer Control. | Named HCZ personnel and secured materials. | Makes L4 a deliberate operating environment rather than a continuation of LCZ. |
| **Clinical transfer network** | L3/L4 response points ↔ L2 Clinical Isolation. | Controlled clinical teams/patients. | Protects ordinary treatment circulation from an unassessed exposure. |
| **Maintenance network** | L2 service control ↔ L3/L4/L5 protected systems. | Approved technicians. | Supports infrastructure without creating broad containment access. |
| **Emergency egress network** | Each level ↔ protected surface egress. | All personnel during an authorized emergency. | Exits are life-safety routes, not daily convenience routes. |

## What this model deliberately does not decide

The model does not yet set the civilian cover identity, sector codes, exact room count, map geometry, named SCP placement, or a final number of lifts. Those decisions must now be tested against this facility logic—not invented in isolation.

The next discussion should test the model level by level. If a division cannot justify its work, staff, route, and boundary, we remove or reshape it before anything enters PASS.

## References

The operating principles were informed by the researched distinction between need-to-know clearance, local/division scope, lockdown compartmentalization, official game door/gate vocabulary, and functional healthcare planning. The model itself is an original PASS configuration. [1] [2] [3] [4] [5]

[1] [SCP Wiki — Security Clearance Levels](https://scp-wiki.wikidot.com/security-clearance-levels)  
[2] [SCP Wiki — Expanded Security Clearance Codes](https://scp-wiki.wikidot.com/expanded-security-clearance-codes)  
[3] [SCP Wiki — Lockdown Procedures](https://scp-wiki.wikidot.com/lockdown-procedures)  
[4] [SCP: Secret Laboratory Official Wiki — Door Mechanics](https://en.scpslgame.com/index.php?title=Door_Mechanics)  
[5] [International Health Facility Guidelines — Functional Planning Units](https://www.healthfacilityguidelines.com/FPUs)
