# PASS / Site-19 Personnel Route Matrix

## How to read this matrix

The route is the person’s **normal operational path**, not a permanent unrestricted grant. A division assignment, active credential, local zone authorization, current work order, restriction, escort condition, and incident status remain decisive at every boundary.

| Personnel family | Normal arrival and work route | Controlled transition | Normal exclusions |
|---|---|---|---|
| **Administration & Site Leadership** | L1 Personnel Access → L2 Site Command & Administration, Personnel/Credentials/Records, or approved briefing areas. | May cross the L2 Light Gate only for a defined inspection, incident command, or assigned operational purpose. | No routine L3/L4 work, custody route, freight core, or restricted storage access simply by seniority. |
| **Research & Analysis** | L1 Personnel Access → L2 readiness/briefing → assigned L2 controlled work or L3 Research, Analysis & Interview Division. | L3 researchers may use the Heavy Gate only under a specific L4 assignment; seniority changes supervision scope, not the default route. | No custody housing, freight lift, L5 storage, or unrelated containment division access. |
| **Clinical & Behavioural Services** | L1 Personnel Access → L2 Clinical Services Division. | Uses the clinical transfer route to L3/L4 only for assigned patient care, evaluation, or protected retrieval. | No normal freight, custody, containment service-spine, or response-staging route. |
| **Containment Operations** | L1 Personnel Access → L2 readiness/operations control → L3 LCZ Entry & Operations Control → assigned containment division. | L4 work requires the Heavy Gate, a specialist assignment, and local HCZ transition authorization. | No automatic access to command, secure archives, medical custody, or other containment clusters. |
| **Security & Access Control** | Route begins at the person’s assigned post: L1 perimeter/entry, L2 operations control, L3 checkpoint/custody escort, or L4 transition/control post. | Reassignment can move a guard between posts, but each post has its own division authority. | No automatic research-cell, records, clinical, storage, or all-HCZ access merely because the person is security. |
| **MTF & Specialist Response** | L1 Air Operations or Personnel Access → designated response staging/briefing → incident-specific L3/L4 route. | Enters response divisions only under deployment, exercise, recovery, or incident authority; tactical medical staff use the clinical transfer route when needed. | No permanent all-site access, no routine D-Class/custody route, and no free use of freight/service corridors. |
| **Logistics, Maintenance & Technical Services** | L1 Vehicle & Freight or Surface Infrastructure → freight/service core → L3 Materials & Service Intake, L5 logistics, or defined maintenance division. | A work order may open a controlled service-spine route into L2/L3/L4 for a stated task and time period. | No regular personnel core, custody route, research workspace, clinical circulation, or containment access after work completion. |
| **Sanitation, Food & Shift Support** | L1 Personnel Access → L2 readiness route → L3 Shift Support or assigned service point. | Sensitive-area work requires a defined cleaning/food-service work order, local authorization, and escort if the division requires it. | No routine custody housing, active containment service spine, freight core, or L4 entry without assigned need. |
| **Custody Population / D-Class** | L1 Custody Transfer → dedicated custody core → L3 Custody Processing & D-Class Division → escorted approved destination → return through custody control. | Leaves custody housing only under an approved escort/staging record; medical transfers use the protected clinical route. | L2 staff arrival, normal elevators, cafeteria/service areas without schedule, freight routes, free L3 circulation, and all L4/L5 access. |

## The effect of rank and clearance

The matrix deliberately avoids creating a route for every title. Within one family, rank changes who may supervise, approve, lead, or request an exception. It does not remove the physical logic of the site.

| Example | What stays the same | What can change through rank or authority |
|---|---|---|
| Junior vs. senior researcher | Both use the research route and assigned research divisions. | The senior researcher may approve/lead work within their authority; neither receives unrelated HCZ access automatically. |
| Guard vs. security supervisor | Both work from assigned security posts. | The supervisor can direct a shift or approve local post changes; neither becomes a universal site pass. |
| Clinician vs. clinical lead | Both work from L2 Clinical Services and protected patient transfer. | The lead can authorize treatment decisions inside policy; it does not grant storage or research access without a separate role. |
| Department head vs. Site Director | Both normally operate from L2 command/administration. | The Director has broader accountability and emergency authority but remains subject to the defined gate/route system and audit trail. |

## Incident change of route

An incident can change a route, but it does not erase the site’s structure. PASS should describe these as controlled temporary states:

| Situation | Route change | Required control |
|---|---|---|
| **Containment incident** | MTF and assigned response personnel gain a temporary route to designated L3/L4 staging. | Incident authority, time limit, post-incident review. |
| **Clinical emergency** | A patient moves from L3/L4 through the protected clinical core to L2. | Clinical triage, transfer condition, receiving clinician. |
| **Maintenance fault** | A technical team uses a service route into a restricted division. | Work order, local clearance, escort/lockout condition where required. |
| **Evacuation** | People leave via the emergency egress network to sealed L1 exit points. | Exit route only; it does not convert into an open entrance. |

This matrix makes the Site-19 map useful to a reader: it explains why a person’s route is plausible without exposing individual contents or turning the facility into a videogame shortcut network.
