# PASS — Mobile Interface Design

## Product direction

PASS, short for **Personnel Access & Site Security**, is a fictional, local-first field registry for an SCP Foundation-style organization. It presents sensitive records as a disciplined operational system rather than a horror-themed novelty interface. The Android experience is designed for portrait use, with primary actions located in the lower half of the screen and dense but readable information hierarchy.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| **Command Dashboard** | Shows system status, record counts, clearance alerts, recently updated files, and one-handed shortcuts to create an SCP record or add personnel. |
| **Anomalies Registry** | Provides a searchable, filterable list of SCP profiles, labeled by item number, object class, status, and assigned site. A floating action opens the SCP composer. |
| **SCP Profile** | Displays a formal profile with containment class, risk designation, containment procedures, description, current research lead, and assigned research team. |
| **Personnel Directory** | Lists staff records with name, role, division, badge status, keycard level, and assignment. A selector enables quick filtering by clearance band. |
| **Personnel Credential** | Presents a realistic digital keycard with clearance level, department, authorized zones, access status, and personnel metadata. It also supports editing clearance and access zones. |
| **Research Operations** | Organizes named research teams around assigned SCPs, showing principal investigator, members, operational status, and next review date. |
| **Record Composer** | Provides structured, validated forms to create and edit SCP profiles, personnel records, and research teams. |

## Key user flows

The main command flow begins at **Command Dashboard**, where the user taps “New Record,” chooses SCP, Personnel, or Team, completes a focused form, and returns to the relevant detail view with a confirmation state. The review flow begins in a registry list, opens a detail record, and permits editing using an explicit “Update file” action. The access-control flow begins in Personnel Directory, opens a credential, changes clearance or zones, and immediately updates the displayed authorization summary. The operations flow begins in Research Operations, opens a team, then links members and a designated SCP from the locally stored records.

## Data model

| Entity | Core fields | Relationships |
|---|---|---|
| **SCP Record** | Item number, designation, object class, risk class, containment status, site, procedures, description, research lead | May be assigned to one research team and one lead researcher. |
| **Personnel Record** | Name, personnel ID, role, division, site, clearance level, access status, authorized zones | May belong to a research team and lead an SCP record. |
| **Research Team** | Team name, code, objective, operational status, lead personnel ID, member IDs, linked SCP ID, review date | Links personnel to an SCP record. |

## Visual system

The interface uses a charcoal-black base (**#111416**) with graphite surfaces (**#1A2023**), restrained off-white type (**#E9ECEB**), system-blue accents (**#6AB6FF**), alert amber (**#E4AB49**), and access-valid green (**#5ACB90**). Panels have narrow technical borders, compact upper-case labels, numerals with generous tracking, and modest status indicators. The design avoids visual clutter, excessive glitch effects, and generic dashboard cards. It should feel like a modern internal control system that happens to serve a secret research organization.

The approved launcher emblem is an original, non-textual containment motif: three brushed-metal directional forms with electric-blue circuit channels inside a technical ring. Its high-contrast charcoal, steel, and blue treatment preserves recognition at Android launcher sizes while matching the controlled database visual system.

## Interaction design

Bottom navigation carries the four primary destinations: Command, Anomalies, Personnel, and Teams. Taps receive a subtle opacity response and light haptic feedback where native support is available. Long records are displayed in optimized lists; creation forms use short sections, clear field labels, and a single fixed bottom action that remains reachable one-handed.

## Launch and access ritual

Every cold launch begins at a **universal PASS boot screen**. The approved digital containment emblem appears over a charcoal field while a restrained technical animation traces its circuit channels. The line **Personnel Access & Site Security** remains directly beneath the emblem. This universal screen never changes and establishes the system rather than the user.

After boot, the user arrives at **Identity Verification**. The centered credential form has two principal lines: a designation-and-name line, where the designation control opens the available roles (**Dr.**, **Researcher**, **Agent**, **SCP-**, **O5-**, and **Administrator**), and a clearance line offering **Level 1–5**. The previous details are saved locally and prefilled on every later launch; the user must deliberately tap **Access Registry** to start a session. Any field can be amended before access is granted.

Each successful request continues through a **clearance-specific authorization screen**. The visual system shares the same emblem but alters the access label and operational message according to the selected clearance: general personnel access for Level 1, research working access for Level 2, containment operations access for Level 3, site command access for Level 4, and oversight archive access for Level 5. The authorization screen then transfers the user to the protected registry. A later rules phase will conceal records outside the current clearance level.
